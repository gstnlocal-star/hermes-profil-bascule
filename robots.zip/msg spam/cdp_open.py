# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

URL = "https://proxya.co/dashboard/buy?type=residential&tab=generate"

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        p = None
        for q in ctx.pages:
            if not q.url.startswith("chrome://"):
                p = q
                break
        if p is None:
            p = await ctx.new_page()
        await p.goto(URL, wait_until="domcontentloaded", timeout=60000)
        await p.wait_for_timeout(6000)
        print("URL:", p.url)
        print("TITRE:", (await p.title())[:90])
        txt = (await p.inner_text("body"))[:600]
        print("DEBUT:", txt.replace("\n", " | ")[:500])
asyncio.run(main())
