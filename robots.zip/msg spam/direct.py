import asyncio, re
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                await p.goto("https://proxya.co/dashboard/buy?type=residential", wait_until="domcontentloaded")
                await p.wait_for_timeout(3000)
                c = p.locator("input[type=number]").first
                await c.fill("25"); await c.dispatch_event("input"); await p.wait_for_timeout(1500)
                # décocher pay from balance
                try:
                    cb = p.locator("input[type=checkbox]").first
                    print("checkbox coche:", await cb.is_checked())
                    await cb.uncheck(); await p.wait_for_timeout(1200)
                    print("apres decoche:", await cb.is_checked())
                except Exception as e: print("cb ERR", str(e)[:100])
                t = await p.inner_text("body")
                m = re.search(r"Pay from balance[\s\S]{0,120}", t)
                print("ZONE:", (m.group(0).replace("\n"," | ") if m else "?"))
                for bt in await p.query_selector_all("button"):
                    try:
                        x=(await bt.inner_text()).strip().replace("\n"," ")
                        if x: print("BTN:", repr(x[:60]), "disabled=", await bt.is_disabled())
                    except Exception: pass
                return
asyncio.run(main())
