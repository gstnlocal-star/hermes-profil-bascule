import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                print("URL:", p.url)
                for a in await p.query_selector_all("a"):
                    try:
                        h = await a.get_attribute("href"); t=(await a.inner_text()).strip()
                        if h and ("fund" in h.lower() or "deposit" in h.lower() or "buy" in h.lower() or "order" in h.lower()): print(repr(t[:40]), h)
                    except Exception: pass
                return
asyncio.run(main())
