import asyncio, sys
from playwright.async_api import async_playwright
URL = sys.argv[1] if len(sys.argv)>1 else None
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                if URL:
                    await p.goto(URL, wait_until="domcontentloaded")
                    await p.wait_for_timeout(3500)
                print("URL:", p.url)
                txt = await p.inner_text("body")
                print("---TEXTE---")
                print(txt[:2500])
                print("---CHAMPS---")
                for el in await p.query_selector_all("input, select, button"):
                    try:
                        t = await el.get_attribute("placeholder") or await el.get_attribute("name") or await el.get_attribute("type") or await el.inner_text()
                        vis = await el.is_visible()
                        print(repr((t or '')[:50]), "visible=",vis)
                    except Exception: pass
                return
asyncio.run(main())
