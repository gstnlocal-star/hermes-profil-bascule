# -*- coding: utf-8 -*-
import asyncio, json
from playwright.async_api import async_playwright
import lsa_mobile as L

MOT = "chauffagiste lyon"

async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][5:6]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        ua, w, h, dpr, _ = L.APPAREILS[0]
        ctx = await nav.new_context(proxy=L.pw_proxy(L.normalise_proxy(px[0])), user_agent=ua,
                                    locale="fr-FR", timezone_id="Europe/Paris",
                                    viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                    is_mobile=True, has_touch=True)
        await ctx.add_init_script(L.HIDE)
        await ctx.add_cookies(L.CONSENT_COOKIES)
        p = await ctx.new_page()
        await p.goto("https://www.google.fr/search?q=" + MOT.replace(" ", "+") + "&hl=fr&gl=fr",
                     wait_until="domcontentloaded", timeout=45000)
        await p.wait_for_timeout(4000)
        d = await p.evaluate("""() => {
          const out = [];
          document.querySelectorAll('*').forEach(el => {
            if (el.children.length) return;
            if (!/^MESSAGE$/i.test((el.innerText||'').trim())) return;
            let c = el, chain = [];
            for (let i=0;i<8 && c;i++) { c = c.parentElement; if (!c) break;
              chain.push({i, txt: (c.innerText||'').trim().slice(0,200), aria: c.getAttribute('aria-label')||'', tag: c.tagName}); }
            out.push(chain);
          });
          return out;
        }""")
        for n, chain in enumerate(d[:2]):
            print("\n=== ANNONCE", n)
            for c in chain:
                print(f"  +{c['i']} {c['tag']} aria={c['aria'][:60]!r} txt={c['txt'][:120]!r}")
        await nav.close()
asyncio.run(main())
