import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "heleket" not in p.url: continue
                for img in await p.query_selector_all("img, canvas, svg"):
                    bb = await img.bounding_box()
                    if bb and bb["width"]>120:
                        print("QR", bb)
                        await img.screenshot(path="C:/Users/googl/Desktop/msg spam/debug/qr_usdt.png")
                        print("saved")
                return
asyncio.run(main())
