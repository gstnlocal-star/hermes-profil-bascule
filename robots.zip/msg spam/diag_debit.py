# -*- coding: utf-8 -*-
"""Instrumente _traiter : nombre d'appels, durees, motifs."""
import time, tkinter as tk
import lsa_plomberie_v3 as S

root = tk.Tk(); root.withdraw()
app = S.App(root)
orig = app._traiter
stats = {"n": 0, "durees": [], "res": {}}


async def mesure(nav, mot, ville, cfg):
    t = time.time()
    stats["n"] += 1
    try:
        r = await orig(nav, mot, ville, cfg)
        stats["res"][r] = stats["res"].get(r, 0) + 1
        return r
    except Exception as e:
        stats["res"][repr(e)[:40]] = stats["res"].get(repr(e)[:40], 0) + 1
        return True
    finally:
        stats["durees"].append(round(time.time() - t, 1))


app._traiter = mesure
app._start()
t0 = time.time()
while time.time() - t0 < 90:
    root.update(); time.sleep(0.2)
app._stop()
d = stats["durees"]
print("appels:", stats["n"], "OK:", app.stats["ok"])
print("durees moy/max:", (round(sum(d)/len(d), 1) if d else 0), max(d) if d else 0)
print("retours:", stats["res"])
