import asyncio
import sys

import lsa_plomberie_v3 as L
from playwright.async_api import async_playwright


async def m():
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        print("1 lance", flush=True)
        ua, w, h, dpr = L.APPAREILS[0]
        ctx = await nav.new_context(user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                                    viewport={"width": w, "height": h},
                                    device_scale_factor=dpr, is_mobile=True, has_touch=True)
        print("2 ctx", flush=True)
        await ctx.add_init_script(L.HIDE)
        await ctx.add_cookies(L.CONSENT_COOKIES)
        print("3 cookies", flush=True)
        p = await ctx.new_page()
        print("4 page", flush=True)
        r = await p.goto("https://www.google.fr/search?q=plombier+nantes&hl=fr&gl=fr",
                         wait_until="domcontentloaded", timeout=45000)
        print("5 goto", r.status if r else None, flush=True)
        await p.wait_for_timeout(2500)
        print("6 attente", flush=True)
        a = await p.evaluate(L.JS_ANNONCES)
        print("7 annonces", len(a), flush=True)
        await nav.close()
        print("8 ferme", flush=True)


try:
    asyncio.run(m())
except BaseException:
    import traceback
    traceback.print_exc()
print("fin", flush=True)
