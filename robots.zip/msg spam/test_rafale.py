# -*- coding: utf-8 -*-
"""Mesure du nombre de requetes Google simultanees qui passent via proxies."""
import asyncio, sys
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

N = int(sys.argv[1]) if len(sys.argv) > 1 else 10
VILLES = ["metz", "nancy", "rennes", "nantes", "rouen", "le havre", "evreux", "vitre",
          "yutz", "terville", "thionville", "reze", "vertou", "coueron", "dieppe"]
RES = []


async def une(nav, n, ville, ligne):
    p = L.normalise_proxy(ligne)
    ua, w, h, dpr = L.APPAREILS[n % len(L.APPAREILS)]
    c = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                              viewport={"width": w, "height": h}, device_scale_factor=dpr,
                              is_mobile=True, has_touch=True)
    await c.add_init_script(L.HIDE); await c.add_cookies(L.CONSENT_COOKIES)
    g = await c.new_page()
    try:
        r = await g.goto(f"https://www.google.fr/search?q=plombier+{ville}&hl=fr&gl=fr",
                         wait_until="domcontentloaded", timeout=35000)
        a = await g.evaluate(L.JS_ANNONCES)
        RES.append((n, r.status, len(a)))
    except Exception as e:
        RES.append((n, "ERR", repr(e)[:40]))
    finally:
        await c.close()


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][60:60 + N]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        await asyncio.gather(*[une(nav, i, VILLES[i % len(VILLES)], l) for i, l in enumerate(px)])
        await nav.close()
    print(sorted(RES))

asyncio.run(main())
