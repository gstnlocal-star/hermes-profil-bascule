@echo off
cd /d "%~dp0"
:debut
"%~dp0.venv\Scripts\pythonw.exe" "%~dp0demarrer.py"
timeout /t 5 /nobreak >nul
goto debut
