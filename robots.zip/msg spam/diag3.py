# -*- coding: utf-8 -*-
import asyncio, tkinter as tk
import lsa_plomberie_v3 as L

async def main():
    root = tk.Tk(); root.withdraw()
    app = L.App(root)
    app.stop.clear()
    app.excl = ["societe plomberie chauffage"]
    app.pool = L.Pool([l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:5])
    L.LOG = lambda m: print("LOG:", m, flush=True)
    app._log = lambda m: print("LOG:", m, flush=True)
    async with L.async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for i in range(4):
            r = await app._traiter(nav, "plombier", "nancy", {"par": 1, "cible": 50, "dmin": 0, "dmax": 0,
                                                             "dry": False, "headless": True, "key": "", "tel": False})
            print("retour", r, "secs", app.etat.secs, "recus", app.etat.recus, flush=True)
        await nav.close()
    print("stats", app.stats)

asyncio.run(main())
