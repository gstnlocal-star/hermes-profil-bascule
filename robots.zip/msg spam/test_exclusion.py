# -*- coding: utf-8 -*-
"""Verifie que les annonces exclues sont bien filtrees, sur une vraie page Google."""
import asyncio
import sys

from playwright.async_api import async_playwright

import lsa_plomberie_v3 as L

VILLES = [("plombier", "rezé"), ("plombier", "sarreguemines"), ("plombier", "canteleu")]


async def main():
    exclusions = [L.sigle(l) for l in L.EXCLUSIONS.splitlines() if l.strip()]

    def exclu(nom):
        mots_nom = set(L.sigle(nom).split())
        for e in exclusions:
            m = set(e.split())
            if m and m <= mots_nom:
                return True
        return False

    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        ua, w, h, dpr = L.APPAREILS[0]
        ctx = await nav.new_context(user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                                    viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                    is_mobile=True, has_touch=True)
        await ctx.add_init_script(L.HIDE)
        await ctx.add_cookies(L.CONSENT_COOKIES)
        page = await ctx.new_page()
        for mot, ville in VILLES:
            url = f"https://www.google.fr/search?q={mot}+{ville.replace(' ', '+')}&hl=fr&gl=fr"
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=45000)
            except Exception as e:
                print("KO goto", ville, repr(e)[:90])
                continue
            await page.wait_for_timeout(2600)
            await L.accepter(page)
            for _ in range(3):
                await page.mouse.wheel(0, 450)
                await page.wait_for_timeout(400)
            annonces = await page.evaluate(L.JS_ANNONCES)
            print(f"--- {ville} : {len(annonces)} annonce(s)")
            for a in annonces:
                verdict = "EXCLUE" if exclu(a["nom"]) else "gardee"
                print(f"    {verdict:7} {a['nom']!r} -> {L.sigle(a['nom'])!r}")
        await nav.close()


asyncio.run(main())
