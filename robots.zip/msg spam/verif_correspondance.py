# -*- coding: utf-8 -*-
"""Verifie que le formulaire ouvert correspond bien a l'annonce visee."""
import asyncio
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

CIBLES = [("plombier", "nantes"), ("plombier", "la roche-sur-yon"), ("plombier", "saint-nazaire")]


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][400:410]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for mot, ville in CIBLES:
            p = L.normalise_proxy(px.pop())
            ua, w, h, dpr = L.APPAREILS[0]
            c = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                      viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                      is_mobile=True, has_touch=True)
            await c.add_init_script(L.HIDE); await c.add_cookies(L.CONSENT_COOKIES)
            g = await c.new_page()
            await g.goto(f"https://www.google.fr/search?q={mot}+{ville.replace(' ', '+')}&hl=fr&gl=fr",
                         wait_until="domcontentloaded", timeout=40000)
            await g.wait_for_timeout(2500)
            await g.mouse.wheel(0, 450); await g.wait_for_timeout(700)
            a = await g.evaluate(L.JS_ANNONCES)
            print(f"== {ville}: {len(a)} annonce(s)")
            for ann in a[:2]:
                f = await c.new_page()
                await f.goto("https://www.google.fr" + ann["href"], wait_until="domcontentloaded", timeout=40000)
                await f.wait_for_timeout(1500)
                titre = ""
                try:
                    titre = (await f.inner_text("body"))[:120].replace("\n", " | ")
                except Exception:
                    pass
                print(f"   annonce={ann['nom'][:28]!r} -> formulaire={titre[:80]!r}")
                await f.close()
            await c.close()
        await nav.close()

asyncio.run(main())
