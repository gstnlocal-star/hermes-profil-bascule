# -*- coding: utf-8 -*-
"""Sonde : consentement puis plusieurs requetes, detection du bloc LSA."""
import asyncio, json, sys
from pathlib import Path
from playwright.async_api import async_playwright

OUT = Path(__file__).parent / "debug"
OUT.mkdir(exist_ok=True)
UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
QUERIES = sys.argv[1:] or ["serrurier nancy", "plombier metz", "chauffagiste paris 15",
                           "depannage serrurerie lyon", "plombier urgent bordeaux"]

MARQ = ["annonces locales", "annonce locale", "google garantit", "sponsoris", "service local"]


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=[
            "--disable-blink-features=AutomationControlled", "--lang=fr-FR"])
        ctx = await b.new_context(user_agent=UA, locale="fr-FR", timezone_id="Europe/Paris",
                                  viewport={"width": 412, "height": 915}, is_mobile=True,
                                  has_touch=True, device_scale_factor=2.6)
        await ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
        await ctx.add_cookies([
            {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
            {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
             "domain": ".google.fr", "path": "/"},
            {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.com", "path": "/"},
            {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
             "domain": ".google.com", "path": "/"},
        ])
        p = await ctx.new_page()
        await p.goto("https://www.google.fr/", wait_until="domcontentloaded", timeout=45000)
        await p.wait_for_timeout(2500)
        for t in ["Tout accepter", "J'accepte", "Accept all"]:
            try:
                btn = p.get_by_role("button", name=t).first
                if await btn.count():
                    await btn.click(timeout=3000)
                    print("consentement:", t)
                    await p.wait_for_timeout(2000)
                    break
            except Exception:
                pass

        for q in QUERIES:
            print("\n===== " + q)
            try:
                await p.goto("https://www.google.fr/search?q=" + q.replace(" ", "+") +
                             "&hl=fr&gl=fr", wait_until="domcontentloaded", timeout=45000)
            except Exception as e:
                print("  goto KO", str(e)[:60]); continue
            await p.wait_for_timeout(3500)
            for y in (500, 900, 1300):
                await p.mouse.wheel(0, y); await p.wait_for_timeout(500)
            txt = (await p.inner_text("body")).lower()
            trouves = [m for m in MARQ if m in txt]
            btns = await p.evaluate("""() => {
              const o = [];
              document.querySelectorAll('a,button,div[role=button],span[role=button]').forEach(e => {
                const t = ((e.innerText||'') + ' ' + (e.getAttribute('aria-label')||'')).toLowerCase();
                if (/message|envoyer un message|demander un devis/.test(t)) {
                  const r = e.getBoundingClientRect();
                  o.push({t: ((e.innerText||'') + '|' + (e.getAttribute('aria-label')||'')).slice(0,50),
                          w: Math.round(r.width), h: Math.round(r.height)});
                }
              });
              return o;
            }""")
            print("  marqueurs:", trouves, "| boutons:", len(btns))
            for x in btns[:6]:
                print("   -", x)
            slug = q.replace(" ", "_")
            await p.screenshot(path=str(OUT / ("q_" + slug + ".png")))
            if trouves or btns:
                (OUT / ("q_" + slug + ".html")).write_text(await p.content(), encoding="utf-8")
        await b.close()

asyncio.run(main())
