# -*- coding: utf-8 -*-
"""Diagnostic : ce que Google renvoie reellement via proxy."""
import asyncio, sys
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+nancy&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:3]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(px):
            p = L.normalise_proxy(ligne)
            ok = await asyncio.to_thread(L.proxy_ok, p)
            ua, w, h, dpr = L.APPAREILS[0]
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            try:
                r = await page.goto(URL, wait_until="domcontentloaded", timeout=40000)
                print(n, "tcp_ok", ok, "http", r.status if r else None, "proxy", p.split("@")[0][:30])
                print("  titre:", (await page.title())[:70])
                txt = (await page.inner_text("body"))[:200].replace("\n", " | ")
                print("  texte:", txt)
                print("  annonces:", len(await page.evaluate(L.JS_ANNONCES)))
                await page.screenshot(path=f"debug/diag_{n}.png")
            except Exception as e:
                print(n, "ECHEC", repr(e)[:120])
            await ctx.close()
        await nav.close()

asyncio.run(main())
