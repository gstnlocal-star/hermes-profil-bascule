import asyncio, re
from playwright.async_api import async_playwright
async def lire(p):
    t = await p.inner_text("body")
    blocs=[]
    for m in re.finditer(r"Residential balance[\s\S]{0,120}", t):
        blocs.append(m.group(0).replace("\n"," | "))
    return blocs
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                await p.goto("https://proxya.co/dashboard/buy?type=residential&tab=generate", wait_until="domcontentloaded")
                await p.wait_for_timeout(3000)
                for plan in ["Pro","Premium"]:
                    try:
                        await p.locator("text="+plan).first.click(); await p.wait_for_timeout(1500)
                        print(plan, "=>", await lire(p))
                    except Exception as e: print(plan,"ERR",str(e)[:80])
                # prix par palier
                await p.goto("https://proxya.co/dashboard/buy?type=residential", wait_until="domcontentloaded")
                await p.wait_for_timeout(2500)
                champs = p.locator("input[type=number]")
                n = await champs.count()
                print("champs num:", n)
                for v in ["25","50","100"]:
                    try:
                        c = champs.first
                        await c.fill(v); await c.dispatch_event("input"); await p.wait_for_timeout(1200)
                        t = await p.inner_text("body")
                        m = re.search(r"Total[\s\S]{0,80}", t)
                        pg = re.search(r"Price/GB[\s\S]{0,40}", t)
                        print("=== ", v, "GB ===")
                        print(" total:", (m.group(0).replace("\n"," | ") if m else "?")[:100])
                        print(" pg:", (pg.group(0).replace("\n"," | ") if pg else "?")[:70])
                    except Exception as e: print(v,"ERR",str(e)[:80])
                return
asyncio.run(main())
