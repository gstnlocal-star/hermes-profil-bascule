# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        p = [q for q in b.contexts[0].pages if "proxya.co" in q.url][0]
        infos = await p.evaluate("""() => [...document.querySelectorAll('button')]
            .map((b,i) => ({i, t: (b.innerText||'').trim(), r: b.getBoundingClientRect()}))
            .filter(o => /Generate/i.test(o.t))
            .map(o => ({t: o.t, x: Math.round(o.r.x), y: Math.round(o.r.y), w: Math.round(o.r.width), h: Math.round(o.r.height)}))""")
        print(infos)
        btn = p.get_by_role("button", name="Generate Proxies").last
        await btn.scroll_into_view_if_needed()
        await btn.click()
        await p.wait_for_timeout(7000)
        txt = await p.inner_text("body")
        import re
        m = re.findall(r"premium\.proxya\.co:\d+:\S+", txt)
        print("proxies:", len(m))
        await p.screenshot(path="debug/buy3.png", full_page=True)
asyncio.run(main())
