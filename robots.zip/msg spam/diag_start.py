# -*- coding: utf-8 -*-
"""Diagnostic : demarrage via _start, 60 s d'observation, journal complet."""
import time, tkinter as tk, faulthandler
faulthandler.enable(open('debug_fatal.txt','w'))
import lsa_plomberie_v3 as S

root = tk.Tk()
root.withdraw()
app = S.App(root)
print("villes:", len(app.villes), "proxies:", len(app.t_px.get("1.0", "end").splitlines()),
      "mots:", app.t_mots.get("1.0", "end").strip().replace("\n", " / "))
app._start()
print("running:", app.running)
t0 = time.time()
import traceback
try:
    while time.time() - t0 < 40:
        root.update()
        time.sleep(0.2)
except Exception:
    print("CRASH BOUCLE"); traceback.print_exc()
print("STATS", app.stats, "file:", len(getattr(app, "file", [])))
j = app.journal.get("1.0", "end")
print("JOURNAL", len(j.splitlines()), "lignes")
print(j[:2500])
print("STATS2", app.stats)
app._stop()
