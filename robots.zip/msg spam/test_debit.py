# -*- coding: utf-8 -*-
"""Mesure de debit reel : 40 paralleles pendant 100 s, une ville."""
import time, tkinter as tk
import lsa_plomberie_v3 as S

root = tk.Tk()
root.withdraw()
app = S.App(root)
app.e_par.delete(0, "end"); app.e_par.insert(0, "40")
app.e_cible.delete(0, "end"); app.e_cible.insert(0, "20")
app.e_dmin.delete(0, "end"); app.e_dmin.insert(0, "0")
app.e_dmax.delete(0, "end"); app.e_dmax.insert(0, "1")
app.e_seuil.delete(0, "end"); app.e_seuil.insert(0, "30000")
app._construire(silencieux=True)
app.t_mots.delete("1.0", "end"); app.t_mots.insert("1.0", "plombier")
app.t_px.delete("1.0", "end")
app.t_px.insert("1.0", "\n".join(l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()))
app.v_dry.set(False); app.v_vis.set(False)
app._start()
t0 = time.time()
while time.time() - t0 < 110:
    root.update()
    time.sleep(0.2)
app._stop()
t1 = time.time()
while time.time() - t1 < 50 and app.running:
    root.update()
    time.sleep(0.3)
d = time.time() - t0
print("DUREE", round(d), "OK", app.stats["ok"], "FAIL", app.stats["fail"],
      "DEBIT", round(app.stats["ok"] / d * 60, 1), "msg/min")
print(app.journal.get("1.0", "end")[-1200:])
