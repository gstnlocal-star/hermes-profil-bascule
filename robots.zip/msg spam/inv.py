import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "heleket" not in p.url: continue
                await p.wait_for_timeout(3000)
                t = await p.inner_text("body")
                print(t[:2200])
                await p.screenshot(path="C:/tmp/heleket.png", full_page=True)
                return
asyncio.run(main())
