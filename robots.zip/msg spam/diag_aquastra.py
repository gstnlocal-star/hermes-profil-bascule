# -*- coding: utf-8 -*-
"""Diagnostic formulaire sur une annonce qui echoue (Aquastra)."""
import asyncio, re
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+rennes&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][30:40]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(px):
            p = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[0]
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            await page.goto(URL, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(3500)
            await page.mouse.wheel(0, 500)
            await page.wait_for_timeout(900)
            ann = await page.evaluate(L.JS_ANNONCES)
            print(n, [(a["i"], a["nom"][:26]) for a in ann])
            cible = next((a for a in ann if "aquastra" in L.sigle(a["nom"])), None)
            if not cible:
                await ctx.close()
                continue
            await page.locator(f'[data-lsa="{cible["i"]}"]').first.click(timeout=9000)
            form = await L.page_formulaire(ctx, 15)
            if not form:
                print("  pas de formulaire")
                await ctx.close()
                continue
            champs = await form.evaluate(
                "() => [...document.querySelectorAll('input,textarea,select')].map(e => "
                "({t: e.type || e.tagName, n: e.name, req: e.required, vis: !!(e.offsetWidth)}))")
            for c in champs:
                print("  ", c)
            btn = form.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
            print("  bouton:", await btn.count(), "disabled:", await btn.first.is_disabled() if await btn.count() else None)
            await form.screenshot(path=f"debug/aquastra_{n}.png", full_page=True)
            await ctx.close()
            break
        await nav.close()

asyncio.run(main())
