import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "heleket" not in p.url: continue
                for bt in await p.query_selector_all("button, [role=combobox], select"):
                    try:
                        t=(await bt.inner_text()).strip().replace("\n"," ")[:40]
                        print("EL:", repr(t), await bt.get_attribute("class"))
                    except Exception: pass
                print("--- selects ---")
                for s in await p.query_selector_all("select"):
                    print(await s.get_attribute("name"), [o for o in await s.eval_on_selector_all("option","els=>els.map(e=>e.value)")])
                return
asyncio.run(main())
