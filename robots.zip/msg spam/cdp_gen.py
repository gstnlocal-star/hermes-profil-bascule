# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        p = [q for q in b.contexts[0].pages if "proxya.co" in q.url][0]
        await p.bring_to_front()
        # pays
        await p.get_by_role("button", name="United States").first.click()
        await p.wait_for_timeout(1200)
        try:
            await p.get_by_role("option", name="France").first.click(timeout=5000)
        except Exception:
            await p.get_by_text("France", exact=True).first.click(timeout=5000)
        await p.wait_for_timeout(1500)
        print("pays ok")
        # session rotating
        try:
            await p.get_by_role("button", name="Rotating").first.click(timeout=4000)
            print("rotating ok")
        except Exception as e:
            print("rotating:", str(e)[:60])
        await p.wait_for_timeout(800)
        # generer
        btns = p.get_by_role("button", name="Generate Proxies")
        n = await btns.count()
        print("boutons generer:", n)
        for i in range(n):
            try:
                if await btns.nth(i).is_visible():
                    await btns.nth(i).click()
                    print("generate clique")
                    break
            except Exception:
                pass
        await p.wait_for_timeout(6000)
        txt = await p.inner_text("body")
        import re
        m = re.findall(r"premium\.proxya\.co:\d+:\S+", txt)
        print("proxies:", len(m))
        print(txt[:200].replace("\n", " | "))
        await p.screenshot(path="debug/buy2.png")
asyncio.run(main())
