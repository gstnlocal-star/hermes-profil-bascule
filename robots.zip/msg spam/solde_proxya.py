# -*- coding: utf-8 -*-
"""Lit le solde Proxya sur l'onglet ouvert via CDP."""
import asyncio
import re
from playwright.async_api import async_playwright


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url:
                    continue
                print("URL:", p.url)
                txt = await p.inner_text("body")
                for ligne in txt.splitlines():
                    l = ligne.strip()
                    if re.search(r"\$|€|balance|solde|credit|funds|remaining|GB|traffic", l, re.I) and len(l) < 90:
                        print("  >", l)
                break

asyncio.run(main())
