@echo off
cd /d "%~dp0"
".venv\Scripts\pythonw.exe" lsa_spam_v3.py
