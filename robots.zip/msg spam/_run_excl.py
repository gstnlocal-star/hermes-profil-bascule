import sys
print("start", flush=True)
try:
    exec(compile(open("test_exclusion.py", encoding="utf-8").read(), "test_exclusion.py", "exec"),
         {"__name__": "__main__", "__file__": "test_exclusion.py"})
except BaseException:
    import traceback
    traceback.print_exc()
print("fin wrapper", flush=True)
