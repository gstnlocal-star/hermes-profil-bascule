# -*- coding: utf-8 -*-
"""Dump la structure du bloc d'annonces locales Service (mobile)."""
import asyncio, json, sys
from pathlib import Path
from playwright.async_api import async_playwright

OUT = Path(__file__).parent / "debug"
OUT.mkdir(exist_ok=True)
Q = sys.argv[1] if len(sys.argv) > 1 else "plombier urgent bordeaux"
UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")

DUMP = r"""() => {
  const desc = el => {
    const a = {};
    for (const at of el.attributes || []) a[at.name] = at.value.slice(0, 90);
    return {tag: el.tagName, attrs: a};
  };
  const blocks = [];
  document.querySelectorAll('*').forEach(el => {
    const t = (el.innerText || '').trim();
    if (!/^MESSAGE$/i.test(t)) return;
    let cur = el, chain = [];
    for (let i = 0; i < 7 && cur; i++) { chain.push(desc(cur)); cur = cur.parentElement; }
    let card = el;
    for (let i = 0; i < 4 && card.parentElement; i++) card = card.parentElement;
    blocks.push({chain, card_txt: (card.innerText || '').slice(0, 400),
                 card_html: card.outerHTML.slice(0, 1800)});
  });
  const anchors = [];
  document.querySelectorAll('a[href]').forEach(a => {
    const h = a.getAttribute('href') || '';
    if (h.includes('localservices') || h.includes('messaging') || h.includes('/aclk'))
      anchors.push({href: h.slice(0, 300), txt: (a.innerText || '').slice(0, 60)});
  });
  return {blocks, anchors: anchors.slice(0, 10),
          aria: [...document.querySelectorAll('[aria-label]')].map(e => e.getAttribute('aria-label')).filter(x => /message/i.test(x)).slice(0, 10)};
}"""


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=[
            "--disable-blink-features=AutomationControlled", "--lang=fr-FR"])
        ctx = await b.new_context(user_agent=UA, locale="fr-FR", timezone_id="Europe/Paris",
                                  viewport={"width": 412, "height": 915}, is_mobile=True,
                                  has_touch=True, device_scale_factor=2.6)
        await ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
        await ctx.add_cookies([
            {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
            {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
             "domain": ".google.fr", "path": "/"},
        ])
        p = await ctx.new_page()
        await p.goto("https://www.google.fr/search?q=" + Q.replace(" ", "+") + "&hl=fr&gl=fr",
                     wait_until="domcontentloaded", timeout=45000)
        await p.wait_for_timeout(4000)
        d = await p.evaluate(DUMP)
        print("blocs:", len(d["blocks"]), "| ancres:", len(d["anchors"]), "| aria:", d["aria"])
        for i, bl in enumerate(d["blocks"][:2]):
            print("\n--- BLOC", i)
            print("CARD TXT:", bl["card_txt"][:300].replace("\n", " / "))
            for c in bl["chain"]:
                print("   ", c["tag"], json.dumps(c["attrs"], ensure_ascii=False)[:260])
            print("CARD HTML:", bl["card_html"][:900].replace("\n", " "))
        for a in d["anchors"]:
            print("ANCRE:", a["href"][:150], "|", a["txt"][:40])
        (OUT / "dump_block.json").write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        await b.close()

asyncio.run(main())
