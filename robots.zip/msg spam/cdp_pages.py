# -*- coding: utf-8 -*-
import asyncio, json
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for c in b.contexts:
            for p in c.pages:
                try:
                    print(repr(await p.title()), "|", p.url)
                except Exception as e:
                    print("KO", e)
asyncio.run(main())
