# -*- coding: utf-8 -*-
"""Compte les boutons Message par requete (mobile) — mesure de fiabilite."""
import asyncio, sys
from playwright.async_api import async_playwright

UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
QS = ["serrurier paris", "serrurier lyon", "plombier paris", "plombier lyon",
      "debouchage canalisation paris", "chauffagiste lyon", "plombier marseille",
      "serrurier marseille", "plombier urgent paris", "serrurier urgent lyon"]

JS = "() => [...document.querySelectorAll('*')].filter(e => /^MESSAGE$/i.test((e.innerText||'').trim())).length"


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=[
            "--disable-blink-features=AutomationControlled", "--lang=fr-FR"])
        ctx = await b.new_context(user_agent=UA, locale="fr-FR", timezone_id="Europe/Paris",
                                  viewport={"width": 412, "height": 915}, is_mobile=True,
                                  has_touch=True, device_scale_factor=2.6)
        await ctx.add_init_script("Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
        await ctx.add_cookies([
            {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
            {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
             "domain": ".google.fr", "path": "/"}])
        p = await ctx.new_page()
        for q in QS:
            n = -1
            for essai in range(2):
                try:
                    await p.goto("https://www.google.fr/search?q=" + q.replace(" ", "+") + "&hl=fr&gl=fr",
                                 wait_until="domcontentloaded", timeout=45000)
                    await p.wait_for_timeout(4500)
                    n = await p.evaluate(JS)
                except Exception as e:
                    print(q, "KO", str(e)[:50]); n = -2
                if n > 0:
                    break
                await p.wait_for_timeout(1200)
            print(f"{q:32s} -> {n}")
            await p.wait_for_timeout(900)
        await b.close()

asyncio.run(main())
