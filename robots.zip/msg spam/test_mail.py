#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
spam_lsa_v24.py - demandes aux fiches Google Local Services Ads.
Un lien = un proxy unique + un profil navigateur fige + une identite neuve.
Les liens ne partagent jamais la meme IP.
Consentement Google par cookies + acceptation automatique.
Captcha facultatif, confirmation stricte, captures d'ecran.
"""
import asyncio
import csv
import queue
import random
import re
import string
import threading
import time
import tkinter as tk
import unicodedata
from datetime import datetime
from tkinter import messagebox, ttk
from urllib.parse import urlparse

import requests
from playwright.async_api import async_playwright

# ================= CONFIG =================
LIENS = ""
PROXIES = ""
VILLE = "Nancy"
ENVOIS_PAR_LIEN = 1
PARALLELE = 2
PAUSE_MIN = 25
PAUSE_MAX = 45
MAILS_ALEATOIRES = True
VERIF_MAIL = False
TIMEOUT_MAIL = 60
CAPTURES = True
AUTRES_PRO = False
HEADLESS = False
TWOCAPTCHA_KEY = ""
# =========================================

TIMEOUT = 45000
CHECK_URL = "https://www.google.fr/generate_204"
BASES = ["https://api.mail.tm"]
QUARANTAINE = 120
FILTRE_POST = re.compile(r"messaging|localservices|batchexecute|/api/", re.I)

PRENOMS = ["Marie", "Julie", "Camille", "Sophie", "Laura", "Emilie", "Celine", "Nathalie",
           "Thomas", "Julien", "Nicolas", "Antoine", "Maxime", "Pierre", "Vincent", "Hugo",
           "Sarah", "Chloe", "Manon", "Claire", "Alexandre", "Guillaume", "Damien", "Lea",
           "Sandra", "Karine", "Mickael", "Sebastien", "Audrey", "Jessica", "Kevin", "Bruno"]
NOMS = ["Dupont", "Martin", "Bernard", "Petit", "Durand", "Leroy", "Moreau", "Simon", "Laurent",
        "Lefebvre", "Michel", "Garnier", "Faure", "Rousseau", "Blanc", "Guerin", "Muller",
        "Colin", "Henry", "Roussel", "Mathieu", "Clement", "Gauthier", "Perrin"]

DOMAINES_MAIL = [
    "gmail.com", "gmail.com", "gmail.com", "outlook.fr", "outlook.com",
    "hotmail.fr", "hotmail.com", "yahoo.fr", "live.fr", "orange.fr",
    "wanadoo.fr", "free.fr", "sfr.fr", "laposte.net",
]

# profils coherents : UA Chromium, plateforme, ecran, fuseau
PROFILS = [
    {"ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
     "plat": "Win32", "vp": {"width": 1366, "height": 768}, "tz": "Europe/Paris", "mob": False, "dpr": 1},
    {"ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
     "plat": "Win32", "vp": {"width": 1536, "height": 864}, "tz": "Europe/Paris", "mob": False, "dpr": 1},
    {"ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36",
     "plat": "Win32", "vp": {"width": 1920, "height": 1080}, "tz": "Europe/Paris", "mob": False, "dpr": 1},
    {"ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
     "plat": "MacIntel", "vp": {"width": 1440, "height": 900}, "tz": "Europe/Paris", "mob": False, "dpr": 2},
    {"ua": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
     "plat": "Linux x86_64", "vp": {"width": 1600, "height": 900}, "tz": "Europe/Paris", "mob": False, "dpr": 1},
    {"ua": "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
     "plat": "Linux armv8l", "vp": {"width": 412, "height": 915}, "tz": "Europe/Paris", "mob": True, "dpr": 2.6},
    {"ua": "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
     "plat": "Linux armv8l", "vp": {"width": 393, "height": 873}, "tz": "Europe/Paris", "mob": True, "dpr": 2.75},
]

PROBLEMES = [
    "j'ai une fuite sous l'evier qui commence a gonfler le meuble",
    "ma chaudiere affiche un code defaut et ne redemarre plus",
    "plus d'eau chaude depuis hier soir, le chauffe-eau ne s'allume plus",
    "le ballon d'eau chaude fuit par la trappe de visite",
    "les WC sont bouches et l'eau remonte doucement",
    "une canalisation fuit dans le placo, il y a une tache d'humidite",
    "le mitigeur de la douche fuit au niveau du raccord",
    "je veux remplacer un chauffe-eau gaz par un modele electrique",
    "l'evier de la cuisine se vide tres lentement depuis deux jours",
    "le radiateur de la salle de bain ne chauffe plus du tout",
    "ma pompe de relevage fait un bruit anormal et disjoncte",
    "il y a une odeur d'egout qui remonte dans la salle de bain",
]

QUESTIONS = [
    "Vous pouvez passer aujourd'hui ?",
    "Quel est le delai d'intervention ?",
    "Vous faites le deplacement dans la journee ?",
    "Combien coute un diagnostic ?",
    "Vous intervenez le week-end ?",
    "C'est urgent, vous pouvez venir ce soir ?",
]

SIGNATURES = [
    "Merci d'avance.\n{p} {n}",
    "Cordialement,\n{p} {n}",
    "Merci pour votre retour.\n{p}",
    "Bien a vous,\n{p} {n}",
]

NOUVEAUX = ["envoye", "envoyee", "transmis", "transmise",
            "bien recu", "recu votre", "prise en charge"]

ERREURS = ["obligatoire", "requis", "erreur", "invalide", "selectionner", "saisir"]

SELS_RELANCE = [
    'button:has-text("Envoyer un message")',
    '[role="button"]:has-text("Envoyer un message")',
    'a:has-text("Envoyer un message")',
    'button:has-text("Envoyer")',
]

CONSENT_COOKIES = [
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410",
     "domain": ".google.com", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.com", "path": "/"},
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410",
     "domain": ".google.fr", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.fr", "path": "/"},
]

CONSENT_BUTTONS = [
    'button:has-text("Tout accepter")',
    'button:has-text("Accepter tout")',
    'div[role="button"]:has-text("Tout accepter")',
    "#L2AGLb",
    'button[aria-label*="Accept"]',
    'form[action*="save"] button',
]

ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-dev-shm-usage",
    "--disable-quic",
    "--disable-http2",
    "--dns-prefetch-disable",
    "--disable-background-networking",
    "--disable-features=DnsOverHttps",
    "--window-size=1366,900",
    "--lang=fr-FR",
    "--no-first-run",
    "--no-default-browser-check",
]

LOG = lambda m: None


# ---------------------------- outils ----------------------------
def sans_accents(t):
    return "".join(c for c in unicodedata.normalize("NFD", str(t))
                   if unicodedata.category(c) != "Mn")


def normalize_proxy(raw):
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    scheme = "http"
    if "://" in raw:
        scheme, raw = raw.split("://", 1)
        scheme = scheme.lower()
        if scheme not in ("http", "https", "socks4", "socks5", "socks5h"):
            scheme = "http"
    user = pw = None
    if "@" in raw:
        cred, raw = raw.rsplit("@", 1)
        if ":" in cred:
            user, pw = cred.split(":", 1)
    parts = raw.split(":")
    if len(parts) >= 4 and user is None:
        host, port, user, pw = parts[0], parts[1], parts[2], ":".join(parts[3:])
    elif len(parts) >= 2:
        host, port = parts[0], parts[1]
    else:
        return None
    auth = f"{user}:{pw}@" if user else ""
    return f"{scheme}://{auth}{host}:{port}"


def pw_proxy(p):
    if not p:
        return None
    u = urlparse(p)
    d = {"server": f"{u.scheme}://{u.hostname}:{u.port}"}
    if u.username:
        d["username"] = u.username
        d["password"] = u.password or ""
    return d


def proxy_ok(p):
    try:
        r = requests.get(CHECK_URL, proxies={"http": p, "https": p}, timeout=15)
        return r.status_code in (200, 204)
    except Exception:
        return False


def script_furtif(profil):
    return (
        "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
        f"Object.defineProperty(navigator,'platform',{{get:()=>'{profil['plat']}'}});"
        "Object.defineProperty(navigator,'languages',{get:()=>['fr-FR','fr']});"
        "Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3]});"
        "window.chrome={runtime:{}};"
    )


async def _filtre(route):
    try:
        if route.request.resource_type in ("font", "media"):
            await route.abort()
        else:
            await route.continue_()
    except Exception:
        pass


class ProxyPool:
    """Sac melange : chaque proxy sort une fois avant tout recyclage."""

    def __init__(self, px):
        self.lock = threading.Lock()
        self.px = px[:]
        random.shuffle(self.px)
        self.sac = list(self.px)
        self.dead = set()

    def get(self):
        with self.lock:
            if not self.sac:
                self.sac = [p for p in self.px if p not in self.dead]
                random.shuffle(self.sac)
            while self.sac:
                p = self.sac.pop()
                if p in self.dead:
                    continue
                return p
            return None

    def fail(self, p):
        with self.lock:
            self.dead.add(p)


# ---------------------------- identites ----------------------------
_lock = threading.Lock()
_stop = threading.Event()
_queue = queue.Queue(maxsize=8)
_global_pool = None
_domains = {}
_cooldown = {}
_seen = set()


def _sess(proxy=None):
    s = requests.Session()
    s.headers.update({"User-Agent": "spam-lsa/24", "Accept": "application/json"})
    if proxy:
        s.proxies = {"http": proxy, "https": proxy}
    return s


def _liste(obj):
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        return obj.get("hydra:member") or []
    return []


def faux_ident(proxy=None):
    pr, no = random.choice(PRENOMS), random.choice(NOMS)
    base = f"{sans_accents(pr).lower()}.{sans_accents(no).lower()}"
    style = random.random()
    if style < 0.4:
        base += str(random.randint(10, 999))
    elif style < 0.7:
        base += str(random.randint(1960, 2004))
    addr = f"{base}@{random.choice(DOMAINES_MAIL)}"
    return {"prenom": pr, "nom": no, "adresse": addr, "pw": None,
            "tel": "06" + "".join(random.choices("0123456789", k=8)),
            "base": None, "proxy": proxy, "tok": None}


def _base_dispo():
    now = time.time()
    with _lock:
        libres = [b for b in BASES if _cooldown.get(b, 0) < now]
    return random.choice(libres) if libres else None


def _domaines(base, sess):
    with _lock:
        if _domains.get(base):
            return _domains[base]
    r = sess.get(f"{base}/domains", timeout=20)
    if r.status_code == 429:
        with _lock:
            _cooldown[base] = time.time() + QUARANTAINE
        return []
    r.raise_for_status()
    d = []
    for x in _liste(r.json()):
        if isinstance(x, str):
            d.append(x)
            continue
        if x.get("isActive") and not x.get("isPrivate"):
            d.append(x.get("domain"))
    d = [x for x in d if x]
    with _lock:
        if d:
            _domains[base] = d
    return d


def _token_sess(sess, base, addr, pw):
    try:
        r = sess.post(f"{base}/token",
                      json={"address": addr, "password": pw}, timeout=25)
        if r.status_code == 200:
            return r.json().get("token")
    except Exception:
        pass
    return None


def _token(ident):
    return _token_sess(_sess(ident.get("proxy")), ident["base"],
                       ident["adresse"], ident["pw"])


def new_identity(proxy=None):
    if MAILS_ALEATOIRES:
        return faux_ident(proxy)
    sess = _sess(proxy)
    essais = 0
    while essais < 12 and not _stop.is_set():
        base = _base_dispo()
        if not base:
            LOG("mail : bases en quarantaine, attente")
            _stop.wait(15)
            continue
        essais += 1
        try:
            ds = _domaines(base, sess)
            if not ds:
                LOG(f"mail : aucun domaine sur {base}")
                _stop.wait(5)
                continue
            pr, no = random.choice(PRENOMS), random.choice(NOMS)
            addr = (f"{sans_accents(pr).lower()}.{sans_accents(no).lower()}"
                    f"{random.randint(10000000, 99999999)}@{random.choice(ds)}")
            pw = "".join(random.choices(string.ascii_letters + string.digits, k=14))
            r = sess.post(f"{base}/accounts",
                          json={"address": addr, "password": pw}, timeout=25)
            LOG(f"mail : creation -> {r.status_code}")
            if r.status_code in (200, 201):
                with _lock:
                    if addr in _seen:
                        continue
                    _seen.add(addr)
                tok = None
                for _ in range(2):
                    tok = _token_sess(sess, base, addr, pw)
                    if tok:
                        break
                    time.sleep(4)
                return {"prenom": pr, "nom": no, "adresse": addr, "pw": pw,
                        "tel": "06" + "".join(random.choices("0123456789", k=8)),
                        "base": base, "proxy": proxy, "tok": tok}
            if r.status_code == 429:
                with _lock:
                    _cooldown[base] = time.time() + QUARANTAINE
                LOG(f"mail : 429, base en quarantaine {QUARANTAINE}s")
                _stop.wait(30)
            elif r.status_code == 422:
                LOG("mail : 422 adresse deja prise, nouvelle tentative")
                time.sleep(1)
            else:
                LOG(f"mail : HTTP {r.status_code} {r.text[:80]}")
                time.sleep(2)
        except Exception as e:
            LOG(f"mail : {type(e).__name__} {repr(e)[:90]}")
            _stop.wait(3)
    return None


def attendre_mail(ident, timeout=60):
    tok = ident.get("tok")
    if not tok:
        tok = _token(ident)
    if not tok:
        return "impossible"
    s = _sess(ident.get("proxy"))
    fin = time.time() + timeout
    while time.time() < fin and not _stop.is_set():
        try:
            r = s.get(f"{ident['base']}/messages",
                      headers={"Authorization": f"Bearer {tok}"}, timeout=20)
            if r.status_code == 401:
                tok = _token(ident)
                if not tok:
                    return "impossible"
                continue
            if r.status_code == 200:
                brut = r.json()
                total = len(_liste(brut))
                if not isinstance(brut, list):
                    total = brut.get("hydra:totalItems", total)
                if total > 0:
                    return "oui"
        except Exception:
            pass
        time.sleep(10)
    return "non"


def filler():
    while not _stop.is_set():
        if _queue.qsize() >= 6:
            _stop.wait(0.5)
            continue
        px = _global_pool.get() if _global_pool else None
        ident = new_identity(px)
        if not ident:
            if px:
                _global_pool.fail(px)
            _stop.wait(2)
            continue
        _queue.put(ident)


def message(pr, no):
    m = f"Bonjour, je m'appelle {pr} {no}, {random.choice(PROBLEMES)}."
    if VILLE and random.random() < 0.4:
        m += f" Je suis sur {VILLE}."
    if random.random() < 0.6:
        m += f" {random.choice(QUESTIONS)}"
    m += "\n\n" + random.choice(SIGNATURES).replace("{p}", pr).replace("{n}", no)
    return m


# ---------------------------- page ----------------------------
async def remplir(page, ident, msg):
    remplis = 0
    ta = page.locator("textarea").first
    await ta.wait_for(state="visible", timeout=25000)
    await ta.fill(msg[:600])
    remplis += 1

    nom = page.locator('input[placeholder="Nom"], input[aria-label="Nom"]').first
    if await nom.count():
        await nom.fill(f"{ident['prenom']} {ident['nom']}")
        remplis += 1

    em = page.locator('input[type="email"]').first
    if await em.count():
        await em.fill(ident["adresse"])
        remplis += 1

    tel = page.locator('input[type="tel"]').first
    if await tel.count():
        try:
            if (await tel.input_value()) == "":
                await tel.fill(ident["tel"])
        except Exception:
            pass

    sel = page.locator("select").first
    if await sel.count():
        try:
            if await sel.locator("option").count() > 1:
                await sel.select_option(index=1)
        except Exception:
            pass
    return remplis


async def etat(page):
    d = {"ta": 0, "txt": "", "btn_off": False}
    try:
        d["ta"] = await page.locator("textarea").count()
    except Exception:
        pass
    try:
        d["txt"] = sans_accents(await page.inner_text("body")).lower()
    except Exception:
        pass
    try:
        b = page.locator('button:has-text("Envoyer")').first
        if await b.count():
            d["btn_off"] = await b.is_disabled()
    except Exception:
        pass
    return d


async def captcha_token(page):
    try:
        return await page.evaluate("""() => {
            const el = document.querySelector('textarea[name="g-recaptcha-response"]');
            return el && el.value && el.value.length > 20 ? el.value : "";
        }""")
    except Exception:
        return ""


async def captcha_present(page):
    try:
        if await page.locator('textarea[name="g-recaptcha-response"]').count():
            return True
        if await page.locator('iframe[src*="recaptcha"]').count():
            return True
        html = await page.content()
        if "g-recaptcha" in html or "data-sitekey" in html:
            return True
    except Exception:
        pass
    return False


async def solve_2captcha(page, key):
    try:
        sitekey = None
        for f in page.frames:
            if "recaptcha/api2/anchor" in (f.url or ""):
                m = re.search(r"[?&]k=([^&]+)", f.url)
                if m:
                    sitekey = m.group(1)
                    break
        if not sitekey:
            m = re.search(r'data-sitekey="([^"]+)"', await page.content())
            if m:
                sitekey = m.group(1)
        if not sitekey:
            LOG("captcha : sitekey introuvable")
            return False
        ua = await page.evaluate("() => navigator.userAgent")
        r = (await asyncio.to_thread(requests.post, "https://2captcha.com/in.php", data={
            "key": key, "method": "userrecaptcha", "googlekey": sitekey,
            "pageurl": page.url, "userAgent": ua, "json": 1}, timeout=30)).json()
        if r.get("status") != 1:
            LOG(f"captcha : {r.get('request')}")
            return False
        rid = r["request"]
        for _ in range(60):
            await page.wait_for_timeout(2000)
            g = (await asyncio.to_thread(requests.get, "https://2captcha.com/res.php",
                 params={"key": key, "action": "get", "id": rid, "json": 1},
                 timeout=30)).json()
            if g.get("status") == 1:
                tok = g["request"]
                await page.evaluate("""(t) => {
                    const el = document.querySelector('textarea[name="g-recaptcha-response"]');
                    if (el) { el.style.display='block'; el.value=t;
                              el.dispatchEvent(new Event('input',{bubbles:true})); }
                }""", tok)
                return True
        return False
    except Exception as e:
        LOG(f"captcha : {type(e).__name__}")
        return False


async def resoudre(page, key):
    if not await captcha_present(page):
        return "pas de captcha"
    try:
        cadre = page.frame_locator('iframe[src*="recaptcha/api2/anchor"]')
        await cadre.locator("#recaptcha-anchor").click(timeout=6000)
    except Exception:
        pass
    for _ in range(16):
        if await captcha_token(page):
            return "captcha resolu (clic)"
        await page.wait_for_timeout(500)
    if key and await solve_2captcha(page, key):
        return "captcha resolu (2captcha)"
    return "captcha non resolu"


async def cliquer_envoyer(page):
    btn = page.get_by_role("button", name=re.compile("^Envoyer$", re.I))
    if not await btn.count():
        btn = page.locator('button:has-text("Envoyer")')
    if not await btn.count():
        raise RuntimeError("bouton Envoyer introuvable")
    cible = btn.first
    try:
        await cible.scroll_into_view_if_needed(timeout=4000)
    except Exception:
        pass
    await cible.click(timeout=8000)


async def autres_pros(page, key):
    try:
        cases = page.locator('input[type="checkbox"]:visible')
        n = await cases.count()
        if n == 0:
            return "0 autre propose"
        coches = 0
        for i in range(min(n, 6)):
            c = cases.nth(i)
            try:
                if not await c.is_checked():
                    await c.check(timeout=3000)
                    coches += 1
                    await page.wait_for_timeout(300)
            except Exception:
                pass
        if coches == 0:
            return "0 coche"

        cible = None
        for sel in SELS_RELANCE:
            loc = page.locator(sel)
            if await loc.count():
                cible = loc.last
                break
        if cible is None:
            return f"{coches} coche, bouton absent"

        await page.wait_for_timeout(900)
        try:
            await cible.scroll_into_view_if_needed(timeout=3000)
        except Exception:
            pass

        avant = sans_accents(await page.inner_text("body")).lower().count("envoye")
        try:
            await cible.click(timeout=6000)
        except Exception:
            await cible.click(timeout=6000, force=True)

        await page.wait_for_timeout(2500)
        if await captcha_present(page):
            LOG(f"captcha relance : {await resoudre(page, key)}")
        await page.wait_for_timeout(3500)
        apres = sans_accents(await page.inner_text("body")).lower().count("envoye")
        if apres > avant:
            return f"{coches} autres contactes"
        return f"{coches} coche, sans confirmation"
    except Exception as e:
        return f"relance : {type(e).__name__}"


async def accepter_consent(page):
    for sel in CONSENT_BUTTONS:
        try:
            b = page.locator(sel).first
            if await b.count():
                await b.click(timeout=4000)
                await page.wait_for_timeout(1500)
                LOG("consentement accepte")
                return True
        except Exception:
            continue
    LOG("consentement : aucun bouton trouve")
    return False


async def ouvrir_lsa(page, url):
    for essai in range(4):
        try:
            await page.goto(url, wait_until="commit", timeout=25000)
        except Exception as e:
            LOG(f"navigation LSA KO ({type(e).__name__})")
        if "consent" in page.url:
            LOG("page de consentement, acceptation")
            if await accepter_consent(page):
                try:
                    await page.goto(url, wait_until="commit", timeout=25000)
                except Exception as e:
                    LOG(f"retour LSA KO ({type(e).__name__})")
        try:
            await page.wait_for_selector("textarea", timeout=15000)
            return
        except Exception:
            pass
        LOG(f"url courante : {page.url[:110]}")
        if page.url.startswith("about:"):
            await page.wait_for_timeout(1500)
    raise RuntimeError("modale LSA non chargee")


async def envoyer(page, url, ident, msg, dry=False, key=""):
    await ouvrir_lsa(page, url)

    if await remplir(page, ident, msg) == 0:
        raise RuntimeError("aucun champ rempli")

    motif_cap = await resoudre(page, key)
    LOG(f"captcha : {motif_cap}")
    if dry:
        return f"dry-run, {motif_cap}"

    posts = []

    def _on_resp(r):
        try:
            if r.request.method in ("POST", "PUT") and FILTRE_POST.search(r.url):
                posts.append((r.status, r.url))
        except Exception:
            pass

    page.on("response", _on_resp)
    avant = await etat(page)
    await cliquer_envoyer(page)

    traite = "non resolu" not in motif_cap
    debut = time.time()
    vus = 0
    motif = None
    try:
        while time.time() - debut < 25:
            await page.wait_for_timeout(1000)
            apres = await etat(page)

            for st, u in posts[vus:]:
                LOG(f"POST {st} {u[:70]}")
            vus = len(posts)
            for st, u in posts:
                if st >= 400:
                    raise RuntimeError(f"POST {st} {u[:60]}")

            for w in NOUVEAUX:
                if w in apres["txt"] and w not in avant["txt"]:
                    code = posts[-1][0] if posts else "-"
                    motif = f"confirme ({w}) POST={code}, {motif_cap}"
                    break
            if motif:
                break

            if apres["ta"] == 0:
                code = posts[-1][0] if posts else "-"
                motif = f"modale fermee POST={code}, {motif_cap}"
                break

            if apres["btn_off"]:
                code = posts[-1][0] if posts else "-"
                motif = f"bouton desactive POST={code}, {motif_cap}"
                break

            if time.time() - debut > 3:
                for k in ERREURS:
                    if k in apres["txt"] and k not in avant["txt"]:
                        raise RuntimeError(f"formulaire : {k}")

            if not traite and await captcha_present(page):
                motif_cap = await resoudre(page, key)
                traite = True
                LOG(f"captcha apres envoi : {motif_cap}")
                await page.wait_for_timeout(800)
                await cliquer_envoyer(page)
                avant = apres

        if motif:
            if AUTRES_PRO:
                await page.wait_for_timeout(1500)
                motif += " | " + await autres_pros(page, key)
            return motif

        fin = await etat(page)
        for k in ERREURS:
            if k in fin["txt"]:
                raise RuntimeError(f"formulaire : {k}")
        if posts:
            return f"page modifiee sans confirmation POST={posts[-1][0]}, {motif_cap}"
        raise RuntimeError("aucun POST d'envoi detecte")
    finally:
        try:
            page.remove_listener("response", _on_resp)
        except Exception:
            pass


# ---------------------------- UI ----------------------------
class App:
    def __init__(self, root):
        global LOG
        self.root = root
        root.title("spam_lsa v24")
        root.geometry("980x940")
        self.stop_ev = threading.Event()
        self.logq = queue.Queue()
        self.lock = threading.Lock()
        self.stats = {"ok": 0, "fail": 0, "mail": 0}
        self.running = False
        self.pool = None
        self.csv = None
        self.csvw = None
        self._build()
        LOG = self._log
        self._prefill()
        root.after(150, self._drain)
        root.protocol("WM_DELETE_WINDOW", self._close)

    def _build(self):
        p = {"padx": 6, "pady": 4}
        f = ttk.Frame(self.root, padding=10)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)

        ttk.Label(f, text="Liens de fiches LSA (un par ligne) :").grid(
            row=0, column=0, sticky="nw", **p)
        self.t_liens = tk.Text(f, height=5)
        self.t_liens.grid(row=0, column=1, sticky="ew", **p)

        ttk.Label(f, text="Proxies (un par ligne) :").grid(row=1, column=0, sticky="nw", **p)
        self.t_proxies = tk.Text(f, height=6)
        self.t_proxies.grid(row=1, column=1, sticky="ew", **p)

        c = ttk.Frame(f)
        c.grid(row=2, column=0, columnspan=2, sticky="w", **p)
        ttk.Label(c, text="En parallele :").pack(side="left")
        self.e_par = ttk.Entry(c, width=5)
        self.e_par.pack(side="left", padx=5)
        ttk.Label(c, text="Envois par lien :").pack(side="left", padx=(15, 3))
        self.e_rep = ttk.Entry(c, width=5)
        self.e_rep.pack(side="left")
        ttk.Label(c, text="1 lien = 1 proxy unique + 1 profil fige").pack(
            side="left", padx=(15, 0))

        o = ttk.LabelFrame(f, text="Reglages", padding=8)
        o.grid(row=3, column=0, columnspan=2, sticky="ew", **p)
        ttk.Label(o, text="Pause min/max (s) :").grid(row=0, column=0, sticky="w")
        self.e_dmin = ttk.Entry(o, width=6)
        self.e_dmin.grid(row=0, column=1)
        self.e_dmax = ttk.Entry(o, width=6)
        self.e_dmax.grid(row=0, column=2)
        ttk.Label(o, text="Ville :").grid(row=0, column=3, padx=(15, 0))
        self.e_ville = ttk.Entry(o, width=15)
        self.e_ville.grid(row=0, column=4)

        self.v_dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(o, text="Dry-run", variable=self.v_dry).grid(
            row=1, column=0, columnspan=2, sticky="w", pady=6)
        self.v_vis = tk.BooleanVar(value=not HEADLESS)
        ttk.Checkbutton(o, text="Navigateur visible", variable=self.v_vis).grid(
            row=1, column=3, sticky="w")
        self.v_autre = tk.BooleanVar(value=AUTRES_PRO)
        ttk.Checkbutton(o, text="Contacter aussi les pros proposes",
                        variable=self.v_autre).grid(row=1, column=4, sticky="w")

        self.v_mail = tk.BooleanVar(value=MAILS_ALEATOIRES)
        ttk.Checkbutton(o, text="Mails aleatoires (gmail/outlook...)",
                        variable=self.v_mail).grid(row=2, column=0, columnspan=3, sticky="w")

        ttk.Label(o, text="Cle 2captcha :").grid(row=3, column=0, sticky="w")
        self.e_key = ttk.Entry(o)
        self.e_key.grid(row=3, column=1, columnspan=4, sticky="ew")
        o.columnconfigure(4, weight=1)

        b = ttk.Frame(f)
        b.grid(row=4, column=0, columnspan=2, sticky="ew", **p)
        self.b_start = ttk.Button(b, text="DEMARRER", command=self._start)
        self.b_start.pack(side="left")
        self.b_stop = ttk.Button(b, text="STOP", command=self._stop, state="disabled")
        self.b_stop.pack(side="left", padx=8)
        self.l_stats = ttk.Label(b, text="OK : 0 | echecs : 0 | mails : 0")
        self.l_stats.pack(side="left", padx=12)

        self.log = tk.Text(f, height=14, state="disabled", bg="#111", fg="#ddd")
        self.log.grid(row=5, column=0, columnspan=2, sticky="nsew", **p)
        f.rowconfigure(5, weight=1)

    def _prefill(self):
        self.t_liens.insert("1.0", LIENS.strip())
        self.t_proxies.insert("1.0", PROXIES.strip())
        self.e_ville.insert(0, VILLE)
        self.e_par.insert(0, str(PARALLELE))
        self.e_rep.insert(0, str(ENVOIS_PAR_LIEN))
        self.e_dmin.insert(0, str(PAUSE_MIN))
        self.e_dmax.insert(0, str(PAUSE_MAX))
        self.e_key.insert(0, TWOCAPTCHA_KEY)

    def _log(self, m):
        self.logq.put(m)

    def _drain(self):
        try:
            while True:
                m = self.logq.get_nowait()
                self.log.configure(state="normal")
                self.log.insert("end", m + "\n")
                self.log.see("end")
                self.log.configure(state="disabled")
        except queue.Empty:
            pass
        self.l_stats.configure(
            text=f"OK : {self.stats['ok']} | echecs : {self.stats['fail']} | mails : {self.stats['mail']}")
        self.root.after(150, self._drain)

    def _csvw(self, row):
        if not self.csvw:
            return
        with self.lock:
            try:
                self.csvw.writerow(row)
                self.csv.flush()
            except Exception:
                pass

    # ---------------- controle ----------------
    def _start(self):
        if self.running:
            return
        liens = [u.strip() for u in self.t_liens.get("1.0", "end").splitlines() if u.strip()]
        proxies = [p for p in (normalize_proxy(l)
                               for l in self.t_proxies.get("1.0", "end").splitlines()) if p]
        if not liens:
            messagebox.showerror("Erreur", "Renseigne au moins un lien de fiche.")
            return
        try:
            rep = max(1, int(self.e_rep.get()))
        except Exception:
            rep = 1
        try:
            cfg = {
                "par": max(1, int(self.e_par.get())),
                "dmin": max(0.0, float(self.e_dmin.get())),
                "dmax": max(0.0, float(self.e_dmax.get())),
                "dry": self.v_dry.get(),
                "headless": not self.v_vis.get(),
                "key": self.e_key.get().strip(),
            }
        except ValueError:
            messagebox.showerror("Erreur", "Valeurs numeriques invalides.")
            return
        if cfg["dmax"] < cfg["dmin"]:
            cfg["dmax"] = cfg["dmin"]

        besoin = len(liens) * rep
        if proxies and len(proxies) < besoin:
            if not messagebox.askyesno(
                    "Proxies insuffisants",
                    f"{besoin} envois pour {len(proxies)} proxies : des IP seront "
                    "reutilisees. Continuer ?"):
                return

        global AUTRES_PRO, MAILS_ALEATOIRES, VERIF_MAIL
        AUTRES_PRO = self.v_autre.get()
        MAILS_ALEATOIRES = self.v_mail.get()
        VERIF_MAIL = not MAILS_ALEATOIRES

        global _global_pool
        _stop.clear()
        while not _queue.empty():
            try:
                _queue.get_nowait()
            except queue.Empty:
                break
        self.stop_ev.clear()
        self.stats = {"ok": 0, "fail": 0, "mail": 0}
        self.pool = ProxyPool(proxies)
        _global_pool = self.pool
        self.running = True
        self.b_start.configure(state="disabled")
        self.b_stop.configure(state="normal")

        # une tache par envoi, avec profil fige par lien
        taches = []
        num = 0
        for _ in range(rep):
            for i, lien in enumerate(liens):
                taches.append((num, i, lien, PROFILS[i % len(PROFILS)]))
                num += 1

        path = f"lsa_{datetime.now():%Y%m%d_%H%M%S}.csv"
        self.csv = open(path, "w", newline="", encoding="utf-8")
        self.csvw = csv.writer(self.csv, delimiter=";")
        self.csvw.writerow(["horodatage", "statut", "lien", "mail", "prenom",
                            "proxy", "ua", "motif", "mail_recu"])

        self._log(f"Demarrage : {len(liens)} lien(s) x {rep} = {len(taches)} envois, "
                  f"parallelisme {cfg['par']}, {len(proxies)} proxies. CSV : {path}")
        self._log("Chaque lien garde son proxy et son profil navigateur.")
        threading.Thread(target=self._engine, args=(taches, cfg), daemon=True).start()

    def _stop(self):
        self.stop_ev.set()
        _stop.set()
        self._log("Arret demande")

    def _engine(self, taches, cfg):
        threading.Thread(target=filler, daemon=True).start()
        try:
            asyncio.run(self._run(taches, cfg))
        except Exception as e:
            self._log(f"Moteur arrete : {type(e).__name__} {repr(e)[:100]}")
        finally:
            _stop.set()
            self.root.after(0, self._done)

    async def _run(self, taches, cfg):
        sem = asyncio.Semaphore(cfg["par"])
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=cfg["headless"], args=ARGS)

            async def one(num, i, lien, profil):
                async with sem:
                    if self.stop_ev.is_set():
                        return
                    await self._envoyer(browser, num, i, lien, profil, cfg)
                    if not self.stop_ev.is_set():
                        await asyncio.sleep(random.uniform(cfg["dmin"], cfg["dmax"]))

            await asyncio.gather(*[one(n, i, l, p) for n, i, l, p in taches])
            await browser.close()

    async def _envoyer(self, browser, num, i, lien, profil, cfg):
        stamp = datetime.now().strftime("%H:%M:%S")
        dernier = None

        for essai in range(2):
            if self.stop_ev.is_set():
                return
            ctx = None
            page = None
            proxy = None
            ident = None
            try:
                try:
                    ident = _queue.get_nowait()
                    proxy = ident.get("proxy")
                except queue.Empty:
                    proxy = self.pool.get()
                    if proxy and not await asyncio.to_thread(proxy_ok, proxy):
                        self.pool.fail(proxy)
                        raise RuntimeError("proxy injoignable")
                    ident = await asyncio.to_thread(new_identity, proxy)
                if not ident:
                    raise RuntimeError("identite indisponible")

                with self.lock:
                    self.stats["mail"] += 1

                if VERIF_MAIL and not cfg["dry"] and not ident.get("tok"):
                    ident["tok"] = await asyncio.to_thread(_token, ident)

                ctx = await browser.new_context(
                    proxy=pw_proxy(proxy) if proxy else None,
                    user_agent=profil["ua"],
                    viewport=profil["vp"],
                    device_scale_factor=profil["dpr"],
                    is_mobile=profil["mob"],
                    has_touch=profil["mob"],
                    locale="fr-FR",
                    timezone_id=profil["tz"],
                    extra_http_headers={
                        "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7"})
                await ctx.add_init_script(script_furtif(profil))
                await ctx.add_cookies(CONSENT_COOKIES)
                page = await ctx.new_page()
                await page.route("**/*", _filtre)

                self._log(f"[{stamp}] #{num} lien {i + 1} {ident['prenom']} "
                          f"<{ident['adresse']}>")

                try:
                    await page.goto("https://www.google.fr/", wait_until="commit",
                                    timeout=20000)
                    await page.wait_for_timeout(random.randint(500, 1400))
                    await page.mouse.move(random.randint(150, 900),
                                          random.randint(120, 600))
                except Exception:
                    pass

                motif = await envoyer(page, lien, ident,
                                      message(ident["prenom"], ident["nom"]),
                                      cfg["dry"], cfg["key"])

                if CAPTURES:
                    try:
                        shot = f"ok_{datetime.now():%H%M%S}_{num}.png"
                        await page.screenshot(path=shot)
                        self._log(f"[{stamp}] #{num} capture : {shot}")
                    except Exception:
                        pass

                recu = ""
                if VERIF_MAIL and not cfg["dry"]:
                    recu = await asyncio.to_thread(attendre_mail, ident, TIMEOUT_MAIL)

                with self.lock:
                    self.stats["ok"] += 1
                self._log(f"[{stamp}] #{num} OK ({motif}) mail={recu or '-'}")
                self._csvw([datetime.now().isoformat(timespec="seconds"), "ok", lien,
                            ident["adresse"], ident["prenom"], proxy or "",
                            profil["ua"][:40], motif, recu])
                return

            except Exception as e:
                dernier = e
                if proxy and "proxy" in str(e).lower():
                    self.pool.fail(proxy)
                if page:
                    try:
                        shot = f"err_{datetime.now():%H%M%S}_{num}.png"
                        await page.screenshot(path=shot)
                        self._log(f"[{stamp}] #{num} capture : {shot}")
                    except Exception:
                        pass
                self._log(f"[{stamp}] #{num} reprise : {type(e).__name__} {repr(e)[:80]}")
                await asyncio.sleep(2 + essai * 2)
            finally:
                if ctx:
                    try:
                        await ctx.close()
                    except Exception:
                        pass

        with self.lock:
            self.stats["fail"] += 1
        self._log(f"[{stamp}] #{num} echec : {repr(dernier)[:90]}")
        self._csvw([datetime.now().isoformat(timespec="seconds"), "echec", lien,
                    "", "", "", "", repr(dernier)[:80], ""])

    def _done(self):
        self.running = False
        self.b_start.configure(state="normal")
        self.b_stop.configure(state="disabled")
        try:
            self.csv.close()
        except Exception:
            pass
        self._log(f"Termine. OK {self.stats['ok']} / echecs {self.stats['fail']} "
                  f"/ mails {self.stats['mail']}")

    def _close(self):
        self.stop_ev.set()
        _stop.set()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()