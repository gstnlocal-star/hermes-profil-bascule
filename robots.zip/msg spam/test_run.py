# -*- coding: utf-8 -*-
"""Test d'integration : lance le moteur reel en dry-run sur 2 villes, verifie etat + CSV."""
import time, tkinter as tk
import lsa_plomberie_v3 as L

DUREE = 130
L.ETAT.write_text('{"recus":{},"secs":{},"vague":1}', encoding="utf-8")

r = tk.Tk()
r.withdraw()
a = L.App(r)
a.t_mots.delete("1.0", "end")
a.t_mots.insert("1.0", "plombier")
a.t_villes.delete("1.0", "end")
a.t_villes.insert("1.0", "nancy\nmetz")
a.e_par.delete(0, "end"); a.e_par.insert(0, "4")
a.e_cible.delete(0, "end"); a.e_cible.insert(0, "3")
a.v_dry.set(True)
a._start()
fin = time.time() + DUREE
while time.time() < fin:
    r.update()
    time.sleep(0.3)
a._stop()
for _ in range(40):
    r.update()
    time.sleep(0.2)
print("OK:", a.stats["ok"], "echecs:", a.stats["fail"])
print("compteurs:", dict(a.etat.recus))
print("depassements:", [k for k, n in a.etat.recus.items() if n > 3])
r.destroy()
