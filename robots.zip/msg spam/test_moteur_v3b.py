# -*- coding: utf-8 -*-
"""Test du moteur lsa_plomberie_v3 en dry-run : file, workers, cible, exclusions."""
import asyncio, time, tkinter as tk
import lsa_plomberie_v3 as S

root = tk.Tk()
root.withdraw()
app = S.App(root)
app.t_mots.delete("1.0", "end")
app.t_mots.insert("1.0", "plombier")
app.t_excl.delete("1.0", "end")
app.t_excl.insert("1.0", "societe plomberie chauffage")
app.excl = ["societe plomberie chauffage"]
app.pool = S.Pool([l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:20])
app.stats = {"ok": 0, "fail": 0}
app.envois = []
app.fd = open("test_moteur_v3b.csv", "w", newline="", encoding="utf-8")
import csv
app.w = csv.writer(app.fd, delimiter=";")
cfg = {"par": 2, "cible": 2, "dmin": 0, "dmax": 0.3, "dry": True, "headless": True, "key": "", "tel": False}
asyncio.run(app._run([("plombier", "nancy"), ("plombier", "metz")], cfg))
print("STATS", app.stats, "recus", app.etat.recus, "secs", app.etat.secs)
print(app.journal.get("1.0", "end")[-1500:])
