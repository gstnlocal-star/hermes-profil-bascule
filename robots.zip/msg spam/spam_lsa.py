#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
spam_lsa_v10.py — demandes aux fiches Google Local Services Ads.
Async, contexte jetable, une IP par envoi, adresse e-mail aleatoire.
Drapeaux anti-HTTP/2 / QUIC + consentement Google par cookies et clic.
Champ "Envois par lien" : chaque envoi prend un proxy neuf.
"""
import asyncio
import csv
import queue
import random
import re
import socket
import threading
import time
import tkinter as tk
import unicodedata
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlparse

import requests
from playwright.async_api import async_playwright

# ================= CONFIG =================
URLS = ""
PROXIES = ""
VILLE = "Nancy"
ENVOIS_PAR_LIEN = 1
PARALLELE = 1
PROXY_MAX_USES = 1
PAUSE_MIN = 15
PAUSE_MAX = 25
HEADLESS = False
TWOCAPTCHA_KEY = ""
# =========================================

TIMEOUT = 60000

PRENOMS = ["Marie","Julie","Camille","Sophie","Laura","Emilie","Celine","Nathalie",
           "Thomas","Julien","Nicolas","Antoine","Maxime","Pierre","Vincent","Hugo",
           "Sarah","Chloe","Manon","Claire","Alexandre","Guillaume","Damien","Lea",
           "Sandra","Karine","Mickael","Sebastien","Audrey","Jessica","Kevin","Bruno"]
NOMS = ["Dupont","Martin","Bernard","Petit","Durand","Leroy","Moreau","Simon","Laurent",
        "Lefebvre","Michel","Garnier","Faure","Rousseau","Blanc","Guerin","Muller",
        "Colin","Henry","Roussel","Mathieu","Clement","Gauthier","Perrin"]

DOMAINES_MAIL = ["gmail.com", "gmail.com", "gmail.com", "outlook.fr", "outlook.com",
                 "hotmail.fr", "hotmail.com", "yahoo.fr", "live.fr", "orange.fr",
                 "wanadoo.fr", "free.fr", "sfr.fr", "laposte.net"]

PROBLEMES = [
    "j'ai une fuite sous l'evier qui commence a gonfler le meuble",
    "ma chaudiere affiche un code defaut et ne redemarre plus",
    "plus d'eau chaude depuis hier soir, le chauffe-eau ne s'allume plus",
    "le ballon d'eau chaude fuit par la trappe de visite",
    "les WC sont bouches et l'eau remonte doucement",
    "une canalisation fuit dans le placo, il y a une tache d'humidite",
    "le mitigeur de la douche fuit au niveau du raccord",
    "je veux remplacer un chauffe-eau gaz par un modele electrique",
    "la baignoire fuit au niveau de la bonde",
    "l'evacuation de l'evier est tres lente et ca sent mauvais",
]
QUESTIONS = ["vous auriez de la dispo cette semaine ?",
             "quel est le tarif d'un deplacement et d'un devis ?",
             "quel serait votre delai d'intervention ?"]
SIGNATURES = ["Merci d'avance, {p}", "Cordialement, {p} {n}", "Bien a vous, {p}"]

UA = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
]

ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-dev-shm-usage",
    "--disable-quic",
    "--disable-http2",
    "--dns-prefetch-disable",
    "--disable-background-networking",
    "--disable-features=IsolateOrigins,site-per-process,DnsOverHttps",
    "--ignore-certificate-errors",
    "--window-size=1366,900",
    "--lang=fr-FR",
    "--no-first-run",
    "--no-default-browser-check",
]

HIDE = "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"

CONSENT_COOKIES = [
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410",
     "domain": ".google.com", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.com", "path": "/"},
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410",
     "domain": ".google.fr", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.fr", "path": "/"},
]

CONSENT_BOUTONS = [
    'button:has-text("Tout accepter")',
    'button:has-text("Accepter tout")',
    'div[role="button"]:has-text("Tout accepter")',
    "#L2AGLb",
    'button[aria-label*="Tout accepter"]',
    'button[aria-label*="Accept"]',
]

LOG = lambda m: None


def sans_accents(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def normalize_proxy(raw):
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    scheme = "http"
    if "://" in raw:
        scheme, raw = raw.split("://", 1)
        scheme = scheme.lower()
        if scheme not in ("http", "https", "socks5", "socks4"):
            scheme = "http"
    user = pw = None
    if "@" in raw:
        cred, raw = raw.rsplit("@", 1)
        if ":" in cred:
            user, pw = cred.split(":", 1)
    parts = raw.split(":")
    if len(parts) >= 4 and user is None:
        host, port, user, pw = parts[0], parts[1], parts[2], ":".join(parts[3:])
    elif len(parts) >= 2:
        host, port = parts[0], parts[1]
    else:
        return None
    auth = f"{user}:{pw}@" if user else ""
    return f"{scheme}://{auth}{host}:{port}"


def pw_proxy(p):
    if not p:
        return None
    u = urlparse(p)
    d = {"server": f"{u.scheme}://{u.hostname}:{u.port}"}
    if u.username:
        d["username"] = u.username
        d["password"] = u.password or ""
    return d


def proxy_ok(p):
    u = urlparse(p)
    if not u.hostname or not u.port:
        return False
    try:
        s = socket.create_connection((u.hostname, u.port), timeout=10)
        s.close()
        return True
    except Exception:
        return False


class Pool:
    def __init__(self, px, maxuse):
        self.px = [x for x in (normalize_proxy(l) for l in px) if x]
        self.maxuse = max(1, maxuse)
        self.lock = threading.Lock()
        self.i = 0
        self.uses = {}
        self.dead = set()

    def get(self):
        with self.lock:
            if not self.px:
                return None
            n = len(self.px)
            for _ in range(n):
                p = self.px[self.i % n]
                self.i += 1
                if p in self.dead or self.uses.get(p, 0) >= self.maxuse:
                    continue
                self.uses[p] = self.uses.get(p, 0) + 1
                return p
            viv = [p for p in self.px if p not in self.dead] or self.px
            p = min(viv, key=lambda x: self.uses.get(x, 0))
            self.uses[p] = self.uses.get(p, 0) + 1
            return p

    def fail(self, p):
        if not p:
            return
        with self.lock:
            self.dead.add(p)

    def vivants(self):
        with self.lock:
            return len(self.px) - len(self.dead)


def faux_ident(proxy=None):
    pr, no = random.choice(PRENOMS), random.choice(NOMS)
    base = f"{sans_accents(pr).lower()}.{sans_accents(no).lower()}"
    style = random.random()
    if style < 0.4:
        base += str(random.randint(10, 999))
    elif style < 0.7:
        base += str(random.randint(1960, 2004))
    addr = f"{base}@{random.choice(DOMAINES_MAIL)}"
    return {"prenom": pr, "nom": no, "adresse": addr,
            "tel": "06" + "".join(random.choices("0123456789", k=8)),
            "proxy": proxy}


def message(pr, no):
    m = f"Bonjour, je m'appelle {pr} {no}, {random.choice(PROBLEMES)}."
    if VILLE and random.random() < 0.4:
        m += f" Je suis sur {VILLE}."
    if random.random() < 0.6:
        m += f" {random.choice(QUESTIONS)}"
    m += "\n\n" + random.choice(SIGNATURES).replace("{p}", pr).replace("{n}", no)
    return m


# ---- consentement ----
async def passer_consent(page, cible=None):
    if "consent" not in page.url:
        return False
    LOG("  -> consentement, acceptation")
    for sel in CONSENT_BOUTONS:
        try:
            b = page.locator(sel).first
            if not await b.count():
                continue
            try:
                await b.scroll_into_view_if_needed(timeout=3000)
            except Exception:
                pass
            await b.click(timeout=6000)
            await page.wait_for_timeout(2000)
            if cible:
                try:
                    await page.goto(cible, wait_until="commit", timeout=35000)
                except Exception:
                    pass
                await page.wait_for_timeout(800)
            return True
        except Exception:
            continue
    LOG("  -> consentement : bouton introuvable")
    return False


# ---- remplissage de la modale ----
async def remplir(page, ident, msg):
    remplis = 0
    ta = page.locator("textarea").first
    await ta.wait_for(state="visible", timeout=25000)
    await ta.fill(msg[:600])
    remplis += 1

    nom = page.locator('input[placeholder="Nom"], input[aria-label="Nom"]').first
    if await nom.count():
        await nom.fill(f"{ident['prenom']} {ident['nom']}")
        remplis += 1

    em = page.locator('input[type="email"]').first
    if await em.count():
        await em.fill(ident["adresse"])
        remplis += 1

    tel = page.locator('input[type="tel"]').first
    if await tel.count():
        try:
            if (await tel.input_value()) == "":
                await tel.fill(ident["tel"])
        except Exception:
            pass

    sel = page.locator("select").first
    if await sel.count():
        try:
            if await sel.locator("option").count() > 1:
                await sel.select_option(index=1)
        except Exception:
            pass
    return remplis


async def captcha_token(page):
    try:
        return await page.evaluate(
            "() => { const t = document.querySelector('textarea[name=\"g-recaptcha-response\"]');"
            " return t ? t.value : ''; }")
    except Exception:
        return ""


async def solve_2captcha(page, key):
    try:
        html = await page.content()
        m = re.search(r'[?&]k=([A-Za-z0-9_\-]{20,})', html) or re.search(r'data-sitekey="([^"]+)"', html)
        if not m:
            return False
        ua = await page.evaluate("navigator.userAgent")
        r = await asyncio.to_thread(lambda: requests.post(
            "https://2captcha.com/in.php",
            data={"key": key, "method": "userrecaptcha", "googlekey": m.group(1),
                  "pageurl": page.url, "userAgent": ua, "json": 1}, timeout=30).json())
        if r.get("status") != 1:
            return False
        rid = r["request"]
        for _ in range(60):
            await page.wait_for_timeout(2000)
            g = await asyncio.to_thread(lambda: requests.get(
                "https://2captcha.com/res.php",
                params={"key": key, "action": "get", "id": rid, "json": 1}, timeout=30).json())
            if g.get("status") == 1:
                tok = g["request"]
                await page.evaluate("""(t) => {
                    const el = document.querySelector('textarea[name="g-recaptcha-response"]');
                    if (el) { el.style.display='block'; el.value=t;
                              el.dispatchEvent(new Event('input',{bubbles:true})); }
                }""", tok)
                return True
        return False
    except Exception:
        return False


async def resoudre(page, key):
    try:
        cadre = page.frame_locator('iframe[src*="recaptcha/api2/anchor"]')
        await cadre.locator("#recaptcha-anchor").click(timeout=6000)
    except Exception:
        pass
    for _ in range(16):
        if await captcha_token(page):
            return "captcha resolu (clic)"
        await page.wait_for_timeout(500)
    if key and await solve_2captcha(page, key):
        return "captcha resolu (2captcha)"
    return "captcha non resolu"


async def envoyer(page, url, ident, msg, dry=False, key=""):
    LOG("  -> ouverture google.fr")
    try:
        await page.goto("https://www.google.fr/", wait_until="commit", timeout=25000)
    except Exception as e:
        LOG(f"  -> google.fr KO : {type(e).__name__} {str(e)[:80]}")
    await passer_consent(page)
    LOG(f"  -> url apres google : {page.url[:90]}")
    await page.wait_for_timeout(600)

    LOG("  -> ouverture du lien")
    try:
        await page.goto(url, wait_until="commit", timeout=35000)
    except Exception as e:
        LOG(f"  -> lien KO : {type(e).__name__} {str(e)[:80]}")
    await passer_consent(page, url)
    LOG(f"  -> url apres lien : {page.url[:90]}")

    if page.url.startswith("about:"):
        raise RuntimeError("page restee blanche")

    await page.wait_for_selector("textarea", timeout=25000)

    if await remplir(page, ident, msg) == 0:
        raise RuntimeError("aucun champ rempli")

    motif_cap = await resoudre(page, key)
    LOG(f"  -> captcha : {motif_cap}")
    if dry:
        return f"dry-run, {motif_cap}"

    btn = page.get_by_role("button", name=re.compile("Envoyer", re.I))
    if not await btn.count():
        raise RuntimeError("bouton Envoyer introuvable")
    await btn.first.click(timeout=8000)

    debut = time.time()
    while time.time() - debut < 25:
        try:
            txt = sans_accents(await page.inner_text("body")).lower()
        except Exception:
            txt = ""
        if any(k in txt for k in ("demande envoyee", "message envoye", "bien envoye",
                                  "bien ete envoyee", "prise en charge", "recu votre demande",
                                  "envoye a", "transmis")):
            return f"confirme, {motif_cap}"
        ta = page.locator("textarea").first
        if await ta.count() == 0:
            return f"modale fermee, {motif_cap}"
        await page.wait_for_timeout(700)
    raise RuntimeError(f"aucune confirmation ({motif_cap})")


# ---- UI ----
class App:
    def __init__(self, root):
        global LOG
        self.root = root
        root.title("spam_lsa v10")
        root.geometry("980x900")
        self.stop_ev = threading.Event()
        self.logq = queue.Queue()
        self.lock = threading.Lock()
        self.stats = {"ok": 0, "fail": 0}
        self.running = False
        self.pool = None
        self.csv = None
        self.csvw = None
        self.csv_lock = threading.Lock()
        self._build()
        LOG = self._log
        self._prefill()
        root.after(150, self._drain)
        root.protocol("WM_DELETE_WINDOW", self._close)

    def _build(self):
        p = {"padx": 6, "pady": 4}
        f = ttk.Frame(self.root, padding=10)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)

        ttk.Label(f, text="URLs :", font=("", 10, "bold")).grid(row=0, column=0, sticky="nw", **p)
        self.t_urls = tk.Text(f, height=6)
        self.t_urls.grid(row=0, column=1, sticky="ew", **p)

        ttk.Label(f, text="Proxies :", font=("", 10, "bold")).grid(row=1, column=0, sticky="nw", **p)
        pf = ttk.Frame(f)
        pf.grid(row=1, column=1, sticky="ew", **p)
        pf.columnconfigure(0, weight=1)
        self.t_proxies = tk.Text(pf, height=6)
        self.t_proxies.grid(row=0, column=0, sticky="ew")
        ttk.Button(pf, text="Charger .txt", command=self._load).grid(row=1, column=0, sticky="w", pady=3)

        c = ttk.Frame(f)
        c.grid(row=2, column=0, columnspan=2, sticky="w", **p)
        ttk.Label(c, text="En parallèle :").pack(side="left")
        self.e_par = ttk.Entry(c, width=5)
        self.e_par.pack(side="left", padx=5)
        ttk.Label(c, text="Envois par lien :").pack(side="left", padx=(15, 3))
        self.e_rep = ttk.Entry(c, width=6)
        self.e_rep.pack(side="left")
        ttk.Label(c, text="Proxy max/lien :").pack(side="left", padx=(15, 3))
        self.e_max = ttk.Entry(c, width=5)
        self.e_max.pack(side="left")

        o = ttk.LabelFrame(f, text="Réglages", padding=8)
        o.grid(row=3, column=0, columnspan=2, sticky="ew", **p)
        ttk.Label(o, text="Pause min/max (s) :").grid(row=0, column=0, sticky="w")
        self.e_dmin = ttk.Entry(o, width=5)
        self.e_dmin.grid(row=0, column=1)
        self.e_dmax = ttk.Entry(o, width=5)
        self.e_dmax.grid(row=0, column=2)
        ttk.Label(o, text="Ville :").grid(row=0, column=3, padx=(15, 0))
        self.e_ville = ttk.Entry(o, width=15)
        self.e_ville.grid(row=0, column=4)

        self.v_dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(o, text="Dry-run", variable=self.v_dry).grid(
            row=1, column=0, columnspan=2, sticky="w", pady=6)
        self.v_vis = tk.BooleanVar(value=not HEADLESS)
        ttk.Checkbutton(o, text="Navigateur visible", variable=self.v_vis).grid(
            row=1, column=4, sticky="w")

        ttk.Label(o, text="Clé 2captcha :").grid(row=2, column=0, sticky="w")
        self.e_key = ttk.Entry(o)
        self.e_key.grid(row=2, column=1, columnspan=6, sticky="ew")
        o.columnconfigure(4, weight=1)

        b = ttk.Frame(f)
        b.grid(row=4, column=0, columnspan=2, sticky="ew", **p)
        self.b_start = ttk.Button(b, text="DÉMARRER", command=self._start)
        self.b_start.pack(side="left")
        self.b_stop = ttk.Button(b, text="STOP", command=self._stop, state="disabled")
        self.b_stop.pack(side="left", padx=8)
        self.l_stats = ttk.Label(b, text="OK : 0 | échecs : 0")
        self.l_stats.pack(side="left", padx=12)

        self.log = tk.Text(f, height=14, state="disabled", bg="#111", fg="#ddd")
        self.log.grid(row=5, column=0, columnspan=2, sticky="nsew", **p)
        f.rowconfigure(5, weight=1)

    def _prefill(self):
        self.t_urls.insert("1.0", URLS.strip())
        self.t_proxies.insert("1.0", PROXIES.strip())
        self.e_par.insert(0, str(PARALLELE))
        self.e_rep.insert(0, str(ENVOIS_PAR_LIEN))
        self.e_max.insert(0, str(PROXY_MAX_USES))
        self.e_dmin.insert(0, str(PAUSE_MIN))
        self.e_dmax.insert(0, str(PAUSE_MAX))
        self.e_ville.insert(0, VILLE)
        self.e_key.insert(0, TWOCAPTCHA_KEY)

    def _load(self):
        pth = filedialog.askopenfilename(filetypes=[("Texte", "*.txt"), ("Tous", "*.*")])
        if not pth:
            return
        with open(pth, encoding="utf-8", errors="ignore") as fh:
            self.t_proxies.delete("1.0", "end")
            self.t_proxies.insert("1.0", fh.read())

    def _log(self, m):
        self.logq.put(m)

    def _drain(self):
        try:
            while True:
                m = self.logq.get_nowait()
                self.log.configure(state="normal")
                self.log.insert("end", m + "\n")
                self.log.see("end")
                self.log.configure(state="disabled")
        except queue.Empty:
            pass
        self.l_stats.configure(text=f"OK : {self.stats['ok']} | échecs : {self.stats['fail']}")
        self.root.after(150, self._drain)

    def _csvw(self, row):
        with self.csv_lock:
            try:
                self.csvw.writerow(row)
                self.csv.flush()
            except Exception:
                pass

    def _start(self):
        global VILLE
        if self.running:
            return
        liens = [u.strip() for u in self.t_urls.get("1.0", "end").splitlines()
                 if u.strip() and not u.startswith("#")]
        px = [l for l in self.t_proxies.get("1.0", "end").splitlines() if l.strip()]
        if not liens:
            messagebox.showerror("Erreur", "Aucune URL")
            return
        try:
            rep = max(1, int(self.e_rep.get()))
        except Exception:
            rep = 1
        urls = []
        for _ in range(rep):
            for u in liens:
                urls.append(u)
        VILLE = self.e_ville.get().strip()
        try:
            cfg = {
                "par": max(1, int(self.e_par.get())),
                "max": max(1, int(self.e_max.get())),
                "dmin": max(0.0, float(self.e_dmin.get())),
                "dmax": max(0.0, float(self.e_dmax.get())),
                "dry": self.v_dry.get(),
                "headless": not self.v_vis.get(),
                "key": self.e_key.get().strip(),
            }
        except ValueError:
            messagebox.showerror("Erreur", "Valeurs invalides")
            return
        if cfg["dmax"] < cfg["dmin"]:
            cfg["dmax"] = cfg["dmin"]

        if px and len(px) < len(urls):
            if not messagebox.askyesno(
                    "Proxies insuffisants",
                    f"{len(urls)} envois pour {len(px)} proxies : des IP seront "
                    "reutilisees. Continuer ?"):
                return

        self.stop_ev.clear()
        self.stats = {"ok": 0, "fail": 0}
        self.pool = Pool(px, cfg["max"])
        self.running = True
        self.b_start.configure(state="disabled")
        self.b_stop.configure(state="normal")

        path = f"lsa_{datetime.now():%Y%m%d_%H%M%S}.csv"
        self.csv = open(path, "w", newline="", encoding="utf-8")
        self.csvw = csv.writer(self.csv, delimiter=";")
        self.csvw.writerow(["horodatage", "statut", "url", "email", "prenom", "proxy", "motif"])
        self._log(f"Démarrage : {len(liens)} lien(s) x {rep} = {len(urls)} envois, "
                  f"{cfg['par']} en parallèle, {len(px)} proxy(s)")

        threading.Thread(target=self._engine, args=(urls, cfg), daemon=True).start()

    def _stop(self):
        self.stop_ev.set()
        self._log("Arrêt demandé")

    def _engine(self, urls, cfg):
        try:
            asyncio.run(self._run(urls, cfg))
        except Exception as e:
            self._log(f"Moteur arrêté : {type(e).__name__} {repr(e)[:100]}")
        finally:
            self.root.after(0, self._done)

    async def _run(self, urls, cfg):
        sem = asyncio.Semaphore(cfg["par"])
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=cfg["headless"], args=ARGS)

            async def one(idx, url):
                async with sem:
                    if self.stop_ev.is_set():
                        return
                    await self._envoyer(browser, idx, url, cfg)
                    if not self.stop_ev.is_set():
                        await asyncio.sleep(random.uniform(cfg["dmin"], cfg["dmax"]))

            await asyncio.gather(*[one(i, u) for i, u in enumerate(urls)])
            await browser.close()

    async def _envoyer(self, browser, idx, url, cfg):
        stamp = datetime.now().strftime("%H:%M:%S")
        dernier = None

        for essai in range(3):
            if self.stop_ev.is_set():
                return
            ctx = None
            proxy = None
            ident = None
            try:
                proxy = self.pool.get()
                if proxy and not await asyncio.to_thread(proxy_ok, proxy):
                    self.pool.fail(proxy)
                    raise RuntimeError("proxy injoignable")

                ident = faux_ident(proxy)

                ctx = await browser.new_context(
                    proxy=pw_proxy(proxy) if proxy else None,
                    user_agent=random.choice(UA), locale="fr-FR",
                    timezone_id="Europe/Paris",
                    viewport={"width": 1366, "height": 950})
                await ctx.add_init_script(HIDE)
                await ctx.add_cookies(CONSENT_COOKIES)
                page = await ctx.new_page()
                page.set_default_timeout(TIMEOUT)

                self._log(f"[{stamp}] #{idx} essai {essai+1}/3 {ident['prenom']} "
                          f"<{ident['adresse']}>")
                motif = await envoyer(page, url, ident,
                                      message(ident["prenom"], ident["nom"]),
                                      cfg["dry"], cfg["key"])

                with self.lock:
                    self.stats["ok"] += 1
                self._log(f"[{stamp}] #{idx} OK ({motif})")
                self._csvw([datetime.now().isoformat(timespec="seconds"), "ok", url,
                            ident["adresse"], ident["prenom"], proxy or "", motif])
                return

            except Exception as e:
                dernier = e
                nom = type(e).__name__
                if proxy and (nom in ("TimeoutError", "Error")
                              or "proxy" in str(e).lower()
                              or "blanche" in str(e).lower()):
                    self.pool.fail(proxy)
                self._log(f"[{stamp}] #{idx} reprise : {nom} {repr(e)[:70]}")
                await asyncio.sleep(2 + essai * 2)
            finally:
                if ctx:
                    try:
                        await ctx.close()
                    except Exception:
                        pass

        with self.lock:
            self.stats["fail"] += 1
        self._log(f"[{stamp}] #{idx} échec : {repr(dernier)[:80]}")
        self._csvw([datetime.now().isoformat(timespec="seconds"), "echec", url, "", "", "", repr(dernier)[:70]])

    def _done(self):
        self.running = False
        self.b_start.configure(state="normal")
        self.b_stop.configure(state="disabled")
        try:
            self.csv.close()
        except Exception:
            pass
        self._log(f"Terminé. OK {self.stats['ok']} / échecs {self.stats['fail']}")

    def _close(self):
        self.stop_ev.set()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()