# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        p = [q for q in ctx.pages if "proxya.co" in q.url][0]
        async with ctx.expect_page(timeout=25000) as pi:
            await p.get_by_text("Log in with Google", exact=False).first.click()
        pop = await pi.value
        await pop.wait_for_load_state("domcontentloaded", timeout=30000)
        print("POPUP:", pop.url[:120])
        await pop.wait_for_timeout(3000)
        print("TXT:", (await pop.inner_text("body"))[:400].replace("\n", " | "))
        # tenter de choisir le compte si demandé
        try:
            btns = pop.get_by_role("link", name="gstnlocal")
            if await btns.count():
                await btns.first.click()
                print("compte clique")
        except Exception as e:
            print("pas de selecteur compte", str(e)[:60])
        await p.wait_for_timeout(6000)
        print("URL FINALE:", p.url[:120])
asyncio.run(main())
