import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                await p.get_by_role("button", name="Pay $50.00").click()
                await p.wait_for_timeout(4000)
                print("URL:", p.url)
                print((await p.inner_text("body"))[:1800])
                await p.screenshot(path="C:/tmp/proxya_pay.png", full_page=True)
                return
asyncio.run(main())
