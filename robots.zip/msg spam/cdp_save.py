# -*- coding: utf-8 -*-
import asyncio, re
from playwright.async_api import async_playwright

OUT = "proxies_fr.txt"

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        p = [q for q in b.contexts[0].pages if "proxya.co" in q.url][0]
        txt = await p.inner_text("body")
        m = re.findall(r"premium\.proxya\.co:\d+:[A-Za-z0-9._:-]+", txt)
        vus, propre = set(), []
        for x in m:
            if x not in vus:
                vus.add(x)
                propre.append(x)
        with open(OUT, "w", encoding="utf-8") as f:
            f.write("\n".join(propre) + "\n")
        print("ecrits:", len(propre))
        print("exemple:", propre[0] if propre else "aucun")
        print("parts:", propre[0].split(":") if propre else "")
asyncio.run(main())
