# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

MAIL = "gstnlocal@gmail.com"

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        p = [q for q in ctx.pages if "proxya.co" in q.url][0]
        await p.bring_to_front()
        async with ctx.expect_page(timeout=25000) as pi:
            await p.get_by_text("Log in with Google", exact=False).first.click()
        pop = await pi.value
        await pop.wait_for_load_state("domcontentloaded", timeout=30000)
        await pop.wait_for_timeout(2500)
        champ = pop.locator('input[type="email"]').first
        await champ.fill(MAIL)
        await pop.wait_for_timeout(400)
        await pop.locator('#identifierNext, button:has-text("Suivant")').first.click()
        await pop.wait_for_timeout(5000)
        print("ETAPE:", pop.url[:90])
        print("TXT:", (await pop.inner_text("body"))[:400].replace("\n", " | "))
        await p.wait_for_timeout(3000)
        print("URL PROXYA:", p.url[:110])
asyncio.run(main())
