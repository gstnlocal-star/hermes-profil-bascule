#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lsa_mobile.py - spam des annonces locales Service de Google, en mobile, un proxy neuf par envoi.

Mots-cles -> recherche Google mobile -> detection du bloc "Annonces locales" ->
clic sur le bouton MESSAGE d'une annonce -> formulaire -> envoi -> confirmation -> CSV.

Chaque envoi : nouveau contexte jetable, nouveau proxy sticky (TTL 10 min), identite aleatoire.
"""
import asyncio
import csv
import queue
import random
import re
import socket
import threading
import time
import tkinter as tk
import unicodedata
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlparse

import requests
from playwright.async_api import async_playwright

# ======================= CONFIG =======================
MOTS_CLES = ""            # une ligne : "mot cle" ou "mot cle | ville"
PROXIES = ""
ZONE = ""                 # ville ou code postal de repli (facultatif)
PARALLELE = 1
ENVOIS_PAR_ANNONCE = 1
PAUSE_MIN = 8
PAUSE_MAX = 18
HEADLESS = False
TWOCAPTCHA_KEY = ""
# ======================================================

TIMEOUT = 60000
DEBUG = "debug"

PRENOMS = ["Marie", "Julie", "Camille", "Sophie", "Laura", "Emilie", "Celine", "Nathalie",
           "Thomas", "Julien", "Nicolas", "Antoine", "Maxime", "Pierre", "Vincent", "Hugo",
           "Sarah", "Chloe", "Manon", "Claire", "Alexandre", "Guillaume", "Damien", "Lea",
           "Sandra", "Karine", "Mickael", "Sebastien", "Audrey", "Jessica", "Kevin", "Bruno"]
NOMS = ["Dupont", "Martin", "Bernard", "Petit", "Durand", "Leroy", "Moreau", "Simon", "Laurent",
        "Lefebvre", "Michel", "Garnier", "Faure", "Rousseau", "Blanc", "Guerin", "Muller",
        "Colin", "Henry", "Roussel", "Mathieu", "Clement", "Gauthier", "Perrin"]
DOMAINES_MAIL = ["gmail.com", "gmail.com", "gmail.com", "outlook.fr", "outlook.com",
                 "hotmail.fr", "hotmail.com", "yahoo.fr", "live.fr", "orange.fr",
                 "wanadoo.fr", "free.fr", "sfr.fr", "laposte.net"]

PROBLEMES = [
    "j'ai une fuite sous l'evier qui commence a gonfler le meuble",
    "ma chaudiere affiche un code defaut et ne redemarre plus",
    "plus d'eau chaude depuis hier soir, le chauffe-eau ne s'allume plus",
    "le ballon d'eau chaude fuit par la trappe de visite",
    "les WC sont bouches et l'eau remonte doucement",
    "une canalisation fuit dans le placo, il y a une tache d'humidite",
    "le mitigeur de la douche fuit au niveau du raccord",
    "je veux remplacer un chauffe-eau gaz par un modele electrique",
    "la baignoire fuit au niveau de la bonde",
    "l'evacuation de l'evier est tres lente et ca sent mauvais",
]
QUESTIONS = ["vous auriez de la dispo cette semaine ?",
             "quel est le tarif d'un deplacement et d'un devis ?",
             "quel serait votre delai d'intervention ?"]
SIGNATURES = ["Merci d'avance, {p}", "Cordialement, {p} {n}", "Bien a vous, {p}"]

APPAREILS = [
    ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 412, 915, 2.6, 5),
    ("Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 360, 800, 3.0, 5),
    ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1", 390, 844, 3.0, 5),
    ("Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 384, 854, 2.8, 5),
]

ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-dev-shm-usage",
    "--disable-quic",
    "--disable-http2",
    "--dns-prefetch-disable",
    "--disable-background-networking",
    "--disable-features=IsolateOrigins,site-per-process,DnsOverHttps",
    "--lang=fr-FR",
    "--no-first-run",
    "--no-default-browser-check",
]

HIDE = "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"

CONSENT_COOKIES = [
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.fr", "path": "/"},
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.com", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.com", "path": "/"},
]

# marque les boutons MESSAGE et renvoie leur index + le nom de l'annonce
JS_ANNONCES = r"""() => {
  document.querySelectorAll('[data-lsa]').forEach(e => e.removeAttribute('data-lsa'));
  const out = [];
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length > 0) return;
    if (!/^MESSAGE$/i.test((el.innerText || '').trim())) return;
    const r = el.getBoundingClientRect();
    if (r.width < 20 || r.height < 15) return;
    let carte = el;
    for (let i = 0; i < 8 && carte.parentElement; i++) {
      carte = carte.parentElement;
      const l = (carte.innerText || '').trim().split('\n').filter(s => s.trim());
      if (l.length >= 3) break;
    }
    const brut = (carte.innerText || '').trim().split('\n').map(s => s.trim()).filter(Boolean);
    const nom = brut[0] || '';
    el.setAttribute('data-lsa', out.length);
    out.push({i: out.length, nom: nom.slice(0, 80), txt: brut.slice(0, 4).join(' / ').slice(0, 160)});
  });
  return out;
}"""


def sans_accents(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def normalise_proxy(raw):
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    scheme = "http"
    if "://" in raw:
        scheme, raw = raw.split("://", 1)
        scheme = scheme.lower() if scheme.lower() in ("http", "https", "socks5", "socks4") else "http"
    user = pw = None
    if "@" in raw:
        cred, raw = raw.rsplit("@", 1)
        if ":" in cred:
            user, pw = cred.split(":", 1)
    p = raw.split(":")
    if len(p) >= 4 and user is None:
        host, port, user, pw = p[0], p[1], p[2], ":".join(p[3:])
    elif len(p) >= 2:
        host, port = p[0], p[1]
    else:
        return None
    auth = f"{user}:{pw}@" if user else ""
    return f"{scheme}://{auth}{host}:{port}"


def pw_proxy(p):
    if not p:
        return None
    u = urlparse(p)
    d = {"server": f"{u.scheme}://{u.hostname}:{u.port}"}
    if u.username:
        d["username"] = u.username
        d["password"] = u.password or ""
    return d


def proxy_ok(p, hote="premium.proxya.co", timeout=8):
    u = urlparse(p)
    if not u.hostname or not u.port:
        return False
    try:
        s = socket.create_connection((u.hostname, u.port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False


class Pool:
    def __init__(self, lignes):
        self.px = [x for x in (normalise_proxy(l) for l in lignes) if x]
        self.lock = threading.Lock()
        self.i = 0
        self.morts = set()

    def get(self):
        with self.lock:
            if not self.px:
                return None
            for _ in range(len(self.px)):
                p = self.px[self.i % len(self.px)]
                self.i += 1
                if p not in self.morts:
                    return p
            return None

    def mort(self, p):
        if p:
            with self.lock:
                self.morts.add(p)


def identite():
    pr, no = random.choice(PRENOMS), random.choice(NOMS)
    base = f"{sans_accents(pr).lower()}.{sans_accents(no).lower()}"
    r = random.random()
    if r < 0.4:
        base += str(random.randint(10, 999))
    elif r < 0.7:
        base += str(random.randint(1960, 2004))
    return {"prenom": pr, "nom": no,
            "mail": f"{base}@{random.choice(DOMAINES_MAIL)}",
            "tel": "06" + "".join(random.choices("0123456789", k=8))}


def texte_message(pr, no, zone=""):
    m = f"Bonjour, je m'appelle {pr} {no}, {random.choice(PROBLEMES)}."
    if zone and random.random() < 0.4:
        m += f" Je suis sur {zone}."
    if random.random() < 0.6:
        m += f" {random.choice(QUESTIONS)}"
    return m + "\n\n" + random.choice(SIGNATURES).replace("{p}", pr).replace("{n}", no)


LOG = lambda m: None


async def page_formulaire(ctx, delai=15):
    fin = time.time() + delai
    while time.time() < fin:
        for p in ctx.pages:
            try:
                if await p.locator('textarea:visible, input[type="email"]:visible').count():
                    return p
            except Exception:
                pass
        await asyncio.sleep(0.4)
    return None


async def remplir(page, ident, msg):
    ta = page.locator("textarea:visible").first
    if not await ta.count():
        return 0
    await ta.fill(msg[:600])
    n = 1
    mail = page.locator('input[type="email"]:visible').first
    if await mail.count():
        await mail.fill(ident["mail"])
        n += 1
    tel = page.locator('input[type="tel"]:visible').first
    if await tel.count():
        try:
            if (await tel.input_value()) == "":
                await tel.fill(ident["tel"])
        except Exception:
            pass
    s = page.locator("select").first
    if await s.count():
        try:
            if await s.locator("option").count() > 1:
                await s.select_option(index=1)
        except Exception:
            pass
    return n


async def captcha_token(page):
    try:
        return await page.evaluate(
            "() => { const t=document.querySelector('textarea[name=\"g-recaptcha-response\"]');"
            " return t ? t.value : ''; }")
    except Exception:
        return ""


async def solve_2captcha(page, key):
    try:
        html = await page.content()
        m = re.search(r'[?&]k=([A-Za-z0-9_\-]{20,})', html) or re.search(r'data-sitekey="([^"]+)"', html)
        if not m:
            return False
        ua = await page.evaluate("navigator.userAgent")
        r = await asyncio.to_thread(lambda: requests.post(
            "https://2captcha.com/in.php",
            data={"key": key, "method": "userrecaptcha", "googlekey": m.group(1),
                  "pageurl": page.url, "userAgent": ua, "json": 1}, timeout=30).json())
        if r.get("status") != 1:
            return False
        rid = r["request"]
        for _ in range(60):
            await page.wait_for_timeout(2000)
            g = await asyncio.to_thread(lambda: requests.get(
                "https://2captcha.com/res.php",
                params={"key": key, "action": "get", "id": rid, "json": 1}, timeout=30).json())
            if g.get("status") == 1:
                await page.evaluate("""(t) => {
                    const el = document.querySelector('textarea[name="g-recaptcha-response"]');
                    if (el) { el.style.display='block'; el.value=t;
                              el.dispatchEvent(new Event('input',{bubbles:true})); }
                }""", g["request"])
                return True
        return False
    except Exception:
        return False


async def captcha(page, key):
    try:
        cadre = page.frame_locator('iframe[src*="recaptcha"]')
        case = cadre.locator("#recaptcha-anchor")
        if await case.count():
            if (await case.get_attribute("aria-checked")) != "true":
                await case.click(timeout=6000)
                await page.wait_for_timeout(1200)
    except Exception:
        pass
    for _ in range(10):
        if await captcha_token(page):
            return "captcha clic"
        await page.wait_for_timeout(500)
    if key and await solve_2captcha(page, key):
        return "captcha 2captcha"
    return "sans captcha"


async def envoyer(page, annonce, ident, msg, zone, dry=False, key=""):
    """Ouvre le formulaire de l'annonce, remplit, envoie."""
    await page.locator(f'[data-lsa="{annonce["i"]}"]').first.click(timeout=9000)
    ctx = page.context
    cible = await page_formulaire(ctx, 18)
    if not cible:
        raise RuntimeError("formulaire introuvable")

    if await remplir(cible, ident, msg) < 2:
        raise RuntimeError("champs non remplis")

    motif = await captcha(cible, key)
    if dry:
        return f"dry-run ({motif})"

    btn = cible.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
    if not await btn.count():
        raise RuntimeError("bouton Envoyer introuvable")
    await btn.first.click(timeout=8000)

    fin = time.time() + 25
    while time.time() < fin:
        try:
            t = sans_accents(await cible.inner_text("body")).lower()
        except Exception:
            t = ""
        if any(k in t for k in ("demande envoyee", "message envoye", "bien envoyee",
                                "prise en charge", "recu votre demande", "envoye a",
                                "transmis", "merci, votre demande")):
            return f"confirme ({motif})"
        if not await cible.locator("textarea").count():
            return f"modale fermee ({motif})"
        await cible.wait_for_timeout(700)
    raise RuntimeError(f"sans confirmation ({motif})")


class App:
    def __init__(self, root):
        global LOG
        self.root = root
        root.title("lsa mobile v1")
        root.geometry("1000x900")
        self.stop = threading.Event()
        self.q = queue.Queue()
        self.vus = set()
        self.lock = threading.Lock()
        self.stats = {"ok": 0, "fail": 0}
        self.running = False
        self.pool = None
        self.fd = None
        self.w = None
        self._build()
        LOG = self._log
        self._prefill()
        root.after(150, self._drain)
        root.protocol("WM_DELETE_WINDOW", self._close)

    def _build(self):
        p = {"padx": 6, "pady": 4}
        f = ttk.Frame(self.root, padding=10)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)

        ttk.Label(f, text="Mots-cles (1 par ligne, 'mot cle | ville')",
                  font=("", 10, "bold")).grid(row=0, column=0, sticky="nw", **p)
        self.t_mots = tk.Text(f, height=7)
        self.t_mots.grid(row=0, column=1, sticky="ew", **p)

        ttk.Label(f, text="Proxies", font=("", 10, "bold")).grid(row=1, column=0, sticky="nw", **p)
        pf = ttk.Frame(f)
        pf.grid(row=1, column=1, sticky="ew", **p)
        pf.columnconfigure(0, weight=1)
        self.t_px = tk.Text(pf, height=6)
        self.t_px.grid(row=0, column=0, sticky="ew")
        ttk.Button(pf, text="Charger .txt", command=self._charger).grid(row=1, column=0, sticky="w", pady=3)

        o = ttk.LabelFrame(f, text="Reglages", padding=8)
        o.grid(row=2, column=0, columnspan=2, sticky="ew", **p)
        ttk.Label(o, text="En parallele :").grid(row=0, column=0, sticky="w")
        self.e_par = ttk.Entry(o, width=5)
        self.e_par.grid(row=0, column=1)
        ttk.Label(o, text="Envois/annonce :").grid(row=0, column=2, padx=(14, 0))
        self.e_rep = ttk.Entry(o, width=5)
        self.e_rep.grid(row=0, column=3)
        ttk.Label(o, text="Pause min/max (s) :").grid(row=0, column=4, padx=(14, 0))
        self.e_dmin = ttk.Entry(o, width=5)
        self.e_dmin.grid(row=0, column=5)
        self.e_dmax = ttk.Entry(o, width=5)
        self.e_dmax.grid(row=0, column=6)
        ttk.Label(o, text="Ville de repli :").grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.e_zone = ttk.Entry(o, width=18)
        self.e_zone.grid(row=1, column=1, columnspan=2, sticky="w", pady=(6, 0))
        self.v_dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(o, text="Dry-run", variable=self.v_dry).grid(row=1, column=3, sticky="w", pady=(6, 0))
        self.v_vis = tk.BooleanVar(value=not HEADLESS)
        ttk.Checkbutton(o, text="Navigateur visible", variable=self.v_vis).grid(
            row=1, column=4, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Label(o, text="Cle 2captcha :").grid(row=2, column=0, sticky="w", pady=(6, 0))
        self.e_key = ttk.Entry(o)
        self.e_key.grid(row=2, column=1, columnspan=6, sticky="ew", pady=(6, 0))
        o.columnconfigure(6, weight=1)

        b = ttk.Frame(f)
        b.grid(row=3, column=0, columnspan=2, sticky="ew", **p)
        self.b_start = ttk.Button(b, text="DEMARRER", command=self._start)
        self.b_start.pack(side="left")
        self.b_stop = ttk.Button(b, text="STOP", command=self._stop, state="disabled")
        self.b_stop.pack(side="left", padx=8)
        self.l_st = ttk.Label(b, text="OK : 0 | echecs : 0")
        self.l_st.pack(side="left", padx=12)

        self.journal = tk.Text(f, height=16, state="disabled", bg="#111", fg="#ddd")
        self.journal.grid(row=4, column=0, columnspan=2, sticky="nsew", **p)
        f.rowconfigure(4, weight=1)

    def _prefill(self):
        self.t_mots.insert("1.0", MOTS_CLES.strip())
        self.t_px.insert("1.0", PROXIES.strip())
        self.e_par.insert(0, str(PARALLELE))
        self.e_rep.insert(0, str(ENVOIS_PAR_ANNONCE))
        self.e_dmin.insert(0, str(PAUSE_MIN))
        self.e_dmax.insert(0, str(PAUSE_MAX))
        self.e_zone.insert(0, ZONE)
        self.e_key.insert(0, TWOCAPTCHA_KEY)

    def _charger(self):
        pth = filedialog.askopenfilename(filetypes=[("Texte", "*.txt"), ("Tous", "*.*")])
        if not pth:
            return
        with open(pth, encoding="utf-8", errors="ignore") as fh:
            self.t_px.delete("1.0", "end")
            self.t_px.insert("1.0", fh.read())

    def _log(self, m):
        self.q.put(m)

    def _drain(self):
        try:
            while True:
                m = self.q.get_nowait()
                self.journal.configure(state="normal")
                self.journal.insert("end", m + "\n")
                self.journal.see("end")
                self.journal.configure(state="disabled")
        except queue.Empty:
            pass
        self.l_st.configure(text=f"OK : {self.stats['ok']} | echecs : {self.stats['fail']}")
        self.root.after(150, self._drain)

    def _ligne(self, ligne):
        with self.lock:
            try:
                self.w.writerow(ligne)
                self.fd.flush()
            except Exception:
                pass

    def _start(self):
        if self.running:
            return
        mots = [l.strip() for l in self.t_mots.get("1.0", "end").splitlines()
                if l.strip() and not l.startswith("#")]
        px = [l for l in self.t_px.get("1.0", "end").splitlines() if l.strip()]
        if not mots:
            messagebox.showerror("Erreur", "Aucun mot-cle")
            return
        try:
            cfg = {"par": max(1, int(self.e_par.get())), "rep": max(1, int(self.e_rep.get())),
                   "dmin": max(0.0, float(self.e_dmin.get())), "dmax": max(0.0, float(self.e_dmax.get())),
                   "dry": self.v_dry.get(), "headless": not self.v_vis.get(),
                   "key": self.e_key.get().strip(), "zone": self.e_zone.get().strip()}
        except ValueError:
            messagebox.showerror("Erreur", "Valeurs invalides")
            return
        if cfg["dmax"] < cfg["dmin"]:
            cfg["dmax"] = cfg["dmin"]

        taches = []
        for m in mots:
            if "|" in m:
                mot, zone = [x.strip() for x in m.split("|", 1)]
            else:
                mot, zone = m, cfg["zone"]
            taches.append((mot, zone))

        self.pool = Pool(px)
        self.stats = {"ok": 0, "fail": 0}
        self.running = True
        self.b_start.configure(state="disabled")
        self.b_stop.configure(state="normal")
        chemin = f"lsa_mobile_{datetime.now():%Y%m%d_%H%M%S}.csv"
        self.fd = open(chemin, "w", newline="", encoding="utf-8")
        self.w = csv.writer(self.fd, delimiter=";")
        self.w.writerow(["horodatage", "statut", "mot_cle", "annonce", "email", "proxy", "motif"])
        self._log(f"Demarrage : {len(taches)} mot(s)-cle(s), {len(self.pool.px)} proxy(s), "
                  f"{cfg['par']} en parallele, {cfg['rep']} envoi(s)/annonce")
        threading.Thread(target=self._moteur, args=(taches, cfg), daemon=True).start()

    def _stop(self):
        self.stop.set()
        self._log("Arret demande")

    def _moteur(self, taches, cfg):
        try:
            asyncio.run(self._run(taches, cfg))
        except Exception as e:
            self._log(f"Moteur arrete : {type(e).__name__} {repr(e)[:100]}")
        finally:
            self.root.after(0, self._fini)

    async def _run(self, taches, cfg):
        import os
        os.makedirs(DEBUG, exist_ok=True)
        sem = asyncio.Semaphore(cfg["par"])
        async with async_playwright() as pw:
            nav = await pw.chromium.launch(headless=cfg["headless"], args=ARGS)

            async def tache(i, mot, zone):
                async with sem:
                    if self.stop.is_set():
                        return
                    try:
                        await self._traiter(nav, i, mot, zone, cfg)
                    finally:
                        if not self.stop.is_set():
                            await asyncio.sleep(random.uniform(cfg["dmin"], cfg["dmax"]))

            await asyncio.gather(*[tache(i, m, z) for i, (m, z) in enumerate(taches)])
            await nav.close()

    async def _traiter(self, nav, idx, mot, zone, cfg):
        for essai in range(3):
            if self.stop.is_set():
                return
            proxy = self.pool.get() if self.pool.px else None
            ctx = None
            ident = identite()
            try:
                if proxy and not await asyncio.to_thread(proxy_ok, proxy):
                    self.pool.mort(proxy)
                    continue

                ua, w, h, dpr, doigts = random.choice(APPAREILS)
                ctx = await nav.new_context(
                    proxy=pw_proxy(proxy) if proxy else None,
                    user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                    viewport={"width": w, "height": h}, device_scale_factor=dpr,
                    is_mobile=True, has_touch=True)
                await ctx.add_init_script(HIDE)
                await ctx.add_cookies(CONSENT_COOKIES)
                page = await ctx.new_page()
                page.set_default_timeout(TIMEOUT)

                self._log(f"#{idx} '{mot}' essai {essai+1}/3 -> {ident['prenom']} <{ident['mail']}>")
                requete = mot if not zone or zone.lower() in mot.lower() else f"{mot} {zone}"
                await page.goto("https://www.google.fr/search?q=" + requete.replace(" ", "+") +
                                "&hl=fr&gl=fr", wait_until="domcontentloaded", timeout=45000)
                await page.wait_for_timeout(4000)
                await page.mouse.wheel(0, 500)
                await page.wait_for_timeout(1200)

                annonces = await page.evaluate(JS_ANNONCES)
                if not annonces:
                    await page.screenshot(path=f"{DEBUG}/serp_{idx}_{essai}.png")
                    raise RuntimeError("aucune annonce")
                self._log(f"#{idx} {len(annonces)} annonce(s) vue(s)")

                fait = 0
                for ann in annonces:
                    if self.stop.is_set() or fait >= cfg["rep"]:
                        break
                    nom = sans_accents(ann["nom"]).lower()[:60]
                    if nom and nom in self.vus:
                        continue
                    try:
                        motif = await envoyer(page, ann, ident, texte_message(ident["prenom"], ident["nom"], zone),
                                              zone, cfg["dry"], cfg["key"])
                    except Exception as e:
                        await page.screenshot(path=f"{DEBUG}/err_{idx}_{essai}_{ann['i']}.png")
                        self._log(f"#{idx} annonce '{ann['nom'][:30]}' KO : {repr(e)[:70]}")
                        try:
                            await page.goto("https://www.google.fr/search?q=" + requete.replace(" ", "+") +
                                            "&hl=fr&gl=fr", wait_until="domcontentloaded", timeout=45000)
                            await page.wait_for_timeout(3500)
                            annonces = await page.evaluate(JS_ANNONCES)
                        except Exception:
                            pass
                        continue
                    if nom:
                        self.vus.add(nom)
                    fait += 1
                    with self.lock:
                        self.stats["ok"] += 1
                    self._log(f"#{idx} OK {ann['nom'][:36]} ({motif})")
                    self._ligne([datetime.now().isoformat(timespec="seconds"), "ok", mot,
                                 ann["nom"][:60], ident["mail"], proxy or "", motif])
                if fait:
                    return
                raise RuntimeError("aucun envoi abouti")
            except Exception as e:
                self._log(f"#{idx} reprise : {type(e).__name__} {repr(e)[:70]}")
                await asyncio.sleep(2 + essai * 2)
            finally:
                if ctx:
                    try:
                        await ctx.close()
                    except Exception:
                        pass

        with self.lock:
            self.stats["fail"] += 1
        self._ligne([datetime.now().isoformat(timespec="seconds"), "echec", mot, "", ident["mail"], "", "3 essais"])

    def _fini(self):
        self.running = False
        self.b_start.configure(state="normal")
        self.b_stop.configure(state="disabled")
        try:
            self.fd.close()
        except Exception:
            pass
        self._log(f"Termine. OK {self.stats['ok']} / echecs {self.stats['fail']}")

    def _close(self):
        self.stop.set()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
