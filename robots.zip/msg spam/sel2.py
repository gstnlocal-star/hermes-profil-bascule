import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "heleket" not in p.url: continue
                await p.get_by_text("Select currency", exact=True).first.click()
                await p.wait_for_timeout(1500)
                items = await p.query_selector_all("[class*=option], li, [role=option]")
                vus=[]
                for it in items:
                    try:
                        t=(await it.inner_text()).strip().replace("\n"," ")[:30]
                        if t and t not in vus: vus.append(t)
                    except Exception: pass
                print("OPTIONS:", vus[:40])
                await p.screenshot(path="C:/tmp/heleket_list.png", full_page=True)
                return
asyncio.run(main())
