# -*- coding: utf-8 -*-
import asyncio, re, json
from playwright.async_api import async_playwright

URL = "https://proxya.co/dashboard/buy?type=residential&tab=generate"

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        p = [q for q in ctx.pages if "proxya.co" in q.url][0]
        await p.goto(URL, wait_until="domcontentloaded", timeout=60000)
        await p.wait_for_timeout(6000)
        print("URL:", p.url)
        txt = await p.inner_text("body")
        print("APERCU:", txt[:300].replace("\n", " | "))
        m = re.findall(r"premium\.proxya\.co:\d+:[^\s\"<]+", txt)
        print("TROUVES:", len(m))
        for x in m[:3]:
            print("  ", x)
        open("debug/proxies_page.txt", "w", encoding="utf-8").write(txt)
asyncio.run(main())
