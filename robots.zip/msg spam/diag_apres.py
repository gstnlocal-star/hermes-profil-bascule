# -*- coding: utf-8 -*-
"""Ce qui se passe reellement apres le clic Envoyer."""
import asyncio, re
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+nantes&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][300:306]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for ligne in px:
            p = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[0]
            c = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                      viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                      is_mobile=True, has_touch=True)
            await c.add_init_script(L.HIDE); await c.add_cookies(L.CONSENT_COOKIES)
            g = await c.new_page()
            await g.goto(URL, wait_until="domcontentloaded", timeout=40000)
            await g.wait_for_timeout(2500); await g.mouse.wheel(0, 450); await g.wait_for_timeout(700)
            a = await g.evaluate(L.JS_ANNONCES)
            if not a:
                await c.close(); continue
            ann = a[0]
            print("cible:", ann["nom"], "href:", bool(ann["href"]))
            f = await c.new_page()
            await f.goto("https://www.google.fr" + ann["href"], wait_until="domcontentloaded", timeout=40000)
            await f.wait_for_timeout(1200)
            ident = L.identite(); msg = L.texte_message(ident["prenom"], ident["nom"], "Nantes", set())
            print("remplis:", await L.remplir(f, ident, msg, False))
            await f.wait_for_timeout(500)
            print("captcha:", await L.captcha(f, ""))
            btn = f.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
            print("boutons:", await btn.count())
            await btn.first.click(timeout=8000)
            for att in (1500, 2000, 3000, 5000):
                await f.wait_for_timeout(att)
                t = (await f.inner_text("body")).replace("\n", " | ")
                print(f"  +{att}:", t[-160:])
            await f.screenshot(path="debug/apres_envoi.png", full_page=True)
            await c.close()
            break
        await nav.close()

asyncio.run(main())
