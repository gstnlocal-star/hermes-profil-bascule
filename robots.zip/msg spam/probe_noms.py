# -*- coding: utf-8 -*-
"""Probe : noms d'annonces extraits, et effet des exclusions."""
import asyncio, sys
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

REQ = [("plombier", "nancy"), ("plombier", "rouen"), ("depannage plomberie", "laval")]


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][10:20]
    excl = [L.sigle(x) for x in ("alves express", "societe plomberie chauffage")]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, (m, v) in enumerate(REQ):
            ctx = await nav.new_context(proxy=L.pw_proxy(L.normalise_proxy(px[n])),
                                        user_agent=L.APPAREILS[0][0], locale="fr-FR",
                                        viewport={"width": 412, "height": 915}, device_scale_factor=2.6,
                                        is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            p = await ctx.new_page()
            await p.goto(f"https://www.google.fr/search?q={m.replace(' ','+')}+{v}&hl=fr&gl=fr",
                         wait_until="domcontentloaded", timeout=45000)
            await p.wait_for_timeout(3500)
            await p.mouse.wheel(0, 500)
            await p.wait_for_timeout(900)
            ann = await p.evaluate(L.JS_ANNONCES)
            print(f"== {m} {v} : {len(ann)} annonce(s)")
            for a in ann:
                s = L.sigle(a["nom"])
                ko = any(e in " " + s + " " for e in excl)
                print(f"   '{a['nom']}' -> exclu={ko}")
            await p.screenshot(path=f"debug/probe_{n}.png")
            await ctx.close()
        await nav.close()

asyncio.run(main())
