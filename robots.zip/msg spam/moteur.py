# -*- coding: utf-8 -*-
"""Moteur d'envoi LSA, sans interface graphique (process separe de l'UI).

Lit config.json, ecrit journal.txt, compteurs.csv et son CSV d'envois.
"""
import asyncio
import csv
import json
import os
import random
import threading
import time
from datetime import datetime
from pathlib import Path

import lsa_plomberie_v3 as L

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"
JOURNAL = BASE / "journal.txt"
ETAT = BASE / "etat.json"
DEBUG = BASE / "debug"

MAX_ESSAIS = 4


def log(msg):
    with open(JOURNAL, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%H:%M:%S} {msg}\n")


class Etat:
    def __init__(self):
        self.lock = threading.Lock()
        self.recus = {}
        self.secs = {}
        self.bonnes = set()
        self.vague = 1
        self.charge()

    def charge(self):
        try:
            d = json.loads(ETAT.read_text(encoding="utf-8"))
            self.recus = d.get("recus", {})
            self.secs = d.get("secs", {})
            self.bonnes = set(d.get("bonnes", []))
            self.vague = d.get("vague", 1)
        except Exception:
            pass

    def sauve(self):
        with self.lock:
            d = {"recus": dict(self.recus), "secs": dict(self.secs),
                 "bonnes": list(self.bonnes), "vague": self.vague,
                 "maj": datetime.now().isoformat(timespec="seconds")}
        try:
            tmp = ETAT.with_suffix(".tmp")
            tmp.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
            tmp.replace(ETAT)
        except Exception:
            pass


class Moteur:
    def __init__(self, cfg):
        self.cfg = cfg
        self.stop = threading.Event()
        self.etat = Etat()
        self.excl = [L.sigle(x) for x in cfg.get("exclusions", []) if x.strip()]
        self.pool = L.Pool(cfg.get("proxies", []))
        self.stats = {"ok": 0, "fail": 0}
        self.envois = []
        self.cvilles = {}
        self.textes = set()
        self.lock = threading.Lock()
        self.fd = None
        self.w = None
        self.compteur = 0

    def exclu(self, nom):
        mots_nom = set(L.sigle(nom).split())
        for e in self.excl:
            mots = set(e.split())
            if mots and mots <= mots_nom:
                return True
        return False

    def ligne(self, valeurs):
        with self.lock:
            try:
                self.w.writerow(valeurs)
                self.fd.flush()
            except Exception:
                pass

    def total(self):
        with self.etat.lock:
            return sum(self.etat.recus.values())

    def publie(self):
        bord = time.time() - 60
        with self.lock:
            self.envois = [t for t in self.envois if t > bord]
            debit = len(self.envois)
            ok, ko = self.stats["ok"], self.stats["fail"]
        d = {"debit": debit, "ok": ok, "fail": ko, "total": self.total(),
             "actif": not self.stop.is_set(), "maj": datetime.now().isoformat(timespec="seconds")}
        try:
            (BASE / "compteurs.json").write_text(json.dumps(d), encoding="utf-8")
        except Exception:
            pass

    async def run(self):
        DEBUG.mkdir(exist_ok=True)
        paires = [(m, v) for v in self.cfg["villes"] for m in self.cfg["mots"]]
        random.shuffle(paires)
        log(f"Demarrage : {len(paires)} requete(s), {len(self.pool.px)} proxy(s), "
            f"{len(self.excl)} exclusion(s), {self.cfg['par']} parallele, "
            f"cible {self.cfg['cible']} msg/annonce")
        async with L.async_playwright() as pw:
            nav = await pw.chromium.launch(headless=self.cfg["headless"], args=L.ARGS)
            if len(self.etat.bonnes) < 20:
                await self.decouvrir(nav, paires)
            bonnes = {L.sigle(v) for v in self.etat.bonnes}
            prio = [p for p in paires if L.sigle(p[1]) in bonnes]
            reste = [p for p in paires if L.sigle(p[1]) not in bonnes]
            random.shuffle(prio)
            random.shuffle(reste)
            self.file = prio + reste
            file_lock = asyncio.Lock()
            sem = asyncio.Semaphore(self.cfg["par"])

            class Frein:
                """Ferme le debit des que Google repond 429, puis rouvre progressivement."""

                def __init__(self):
                    self.n = 0
                    self.until = 0.0
                    self.lock = asyncio.Lock()

                async def attendre(self):
                    while True:
                        reste = self.until - time.monotonic()
                        if reste <= 0:
                            return
                        await asyncio.sleep(min(reste, 5))

                async def hit(self):
                    async with self.lock:
                        self.n += 1
                        if self.n >= 2:
                            attente = float(min(120 * self.n, 600))
                            self.until = time.monotonic() + attente
                            log(f"429 x{self.n} : pause {int(attente)}s")

                def ok(self):
                    self.n = 0

            frein = Frein()

            async def worker(n):
                await asyncio.sleep(min(10.0, n * 0.3))
                while not self.stop.is_set():
                    async with file_lock:
                        if not self.file:
                            break
                        mot, ville = self.file.pop()
                    await frein.attendre()
                    async with sem:
                        try:
                            restant = await self.traiter(nav, mot, ville)
                            frein.ok()
                        except Exception as e:
                            log(f"tache '{mot} {ville}' KO : {repr(e)[:60]}")
                            if "rate limit" in repr(e):
                                await frein.hit()
                                await asyncio.sleep(3)
                            restant = True
                        if restant and not self.stop.is_set():
                            async with file_lock:
                                if L.sigle(ville) in self.etat.bonnes:
                                    self.file.insert(0, (mot, ville))
                                else:
                                    self.file.append((mot, ville))
                    if self.cfg["dmax"] > 0 and not self.stop.is_set():
                        await asyncio.sleep(random.uniform(self.cfg["dmin"], self.cfg["dmax"]))

            await asyncio.gather(*[worker(i) for i in range(self.cfg["par"])])
            try:
                await nav.close()
            except Exception:
                pass

    async def decouvrir(self, nav, paires):
        sem = asyncio.Semaphore(self.cfg["par"])
        log(f"Reperage des villes productives sur {len(paires)} requete(s)...")

        async def une(mot, ville):
            async with sem:
                if self.stop.is_set():
                    return
                proxy = self.pool.get() if self.pool.px else None
                ctx = None
                try:
                    ua, w, h, dpr = random.choice(L.APPAREILS)
                    ctx = await nav.new_context(proxy=L.pw_proxy(proxy) if proxy else None,
                                                user_agent=ua, locale="fr-FR",
                                                timezone_id="Europe/Paris",
                                                viewport={"width": w, "height": h},
                                                device_scale_factor=dpr, is_mobile=True,
                                                has_touch=True)
                    await ctx.add_init_script(L.HIDE)
                    await ctx.add_cookies(L.CONSENT_COOKIES)
                    page = await ctx.new_page()
                    url = ("https://www.google.fr/search?q=" +
                           (mot if ville.lower() in mot.lower() else f"{mot} {ville}").replace(" ", "+") +
                           "&hl=fr&gl=fr")
                    await page.goto(url, wait_until="domcontentloaded", timeout=40000)
                    await page.wait_for_timeout(2200)
                    await page.mouse.wheel(0, 450)
                    await page.wait_for_timeout(700)
                    if any(not self.exclu(a["nom"]) for a in await page.evaluate(L.JS_ANNONCES)):
                        self.etat.bonnes.add(ville)
                except Exception:
                    pass
                finally:
                    if ctx:
                        try:
                            await ctx.close()
                        except Exception:
                            pass

        await asyncio.gather(*[une(m, v) for m, v in paires])
        self.etat.sauve()
        log(f"Reperage termine : {len(self.etat.bonnes)} ville(s) avec annonces")

    async def traiter(self, nav, mot, ville):
        if self.stop.is_set():
            return False
        ctx = None
        proxy = self.pool.get() if self.pool.px else None
        ident = L.identite()
        try:
            ua, w, h, dpr = random.choice(L.APPAREILS)
            ctx = await nav.new_context(proxy=L.pw_proxy(proxy) if proxy else None,
                                        user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                                        viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                        is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            page.set_default_timeout(L.TIMEOUT)

            requete = mot if ville.lower() in mot.lower() else f"{mot} {ville}"
            url = "https://www.google.fr/search?q=" + requete.replace(" ", "+") + "&hl=fr&gl=fr"
            dispo = []
            for _ in range(3):
                rep = await page.goto(url, wait_until="domcontentloaded", timeout=45000)
                if rep and rep.status in (429, 503):
                    raise RuntimeError(f"rate limit Google ({rep.status})")
                await page.wait_for_timeout(2600)
                await L.accepter(page)
                for _ in range(3):
                    await page.mouse.wheel(0, 450)
                    await page.wait_for_timeout(500)
                dispo = [a for a in await page.evaluate(L.JS_ANNONCES) if not self.exclu(a["nom"])]
                if dispo:
                    break
                self.pool.mort(proxy)
                await page.wait_for_timeout(1200)

            if dispo:
                self.etat.bonnes.add(ville)
            if not dispo:
                k2 = f"{mot}|{ville}"
                with self.etat.lock:
                    self.etat.secs[k2] = self.etat.secs.get(k2, 0) + 1
                    n = self.etat.secs[k2]
                return n < 6

            cible = k = None
            for a in sorted(dispo, key=lambda x: self.etat.recus.get(L.cle(x["nom"], ville), 0)):
                kk = L.cle(a["nom"], ville)
                with self.etat.lock:
                    if self.etat.recus.get(kk, 0) >= self.cfg["cible"]:
                        continue
                    cible, k = a, kk
                    self.etat.recus[k] = self.etat.recus.get(k, 0) + 1
                break
            if not cible:
                return False

            msg = L.texte_message(ident["prenom"], ident["nom"], ville, self.textes)
            try:
                motif = await L.envoyer(page, cible, ident, msg, self.cfg["dry"],
                                        self.cfg["key"], self.cfg["tel"])
            except Exception as e:
                await page.screenshot(path=str(DEBUG / f"err_{int(time.time())}_{cible['i']}.png"))
                with self.etat.lock:
                    self.etat.recus[k] = max(0, self.etat.recus.get(k, 1) - 1)
                with self.lock:
                    self.stats["fail"] += 1
                log(f"'{cible['nom'][:28]}' {ville} KO : {repr(e)[:60]}")
                self.ligne([datetime.now().isoformat(timespec="seconds"), "echec", mot, ville,
                            cible["nom"][:60], ident["mail"], proxy or "", repr(e)[:120], msg])
                return True

            with self.lock:
                self.stats["ok"] += 1
                self.envois.append(time.time())
            log(f"OK {cible['nom'][:28]} | {ville} | {ident['mail']}")
            self.ligne([datetime.now().isoformat(timespec="seconds"), "ok", mot, ville,
                        cible["nom"][:60], ident["mail"], proxy or "", motif, msg])
            return True
        finally:
            if ctx:
                try:
                    await ctx.close()
                except Exception:
                    pass

    def demarre(self):
        chemin = BASE / f"lsa_{datetime.now():%Y%m%d_%H%M%S}.csv"
        self.fd = open(chemin, "w", newline="", encoding="utf-8")
        self.w = csv.writer(self.fd, delimiter=";")
        self.w.writerow(["horodatage", "statut", "mot_cle", "ville", "annonce", "email",
                         "proxy", "motif", "message"])
        self.fd.flush()
        asyncio.run(self.run())
        try:
            self.fd.close()
        except Exception:
            pass
        self.etat.sauve()
        self.stop.set()
        self.publie()
        log(f"Termine. OK {self.stats['ok']} / echecs {self.stats['fail']}")


def boucle_sauve(m):
    while not m.stop.is_set():
        time.sleep(15)
        m.etat.sauve()
        m.publie()


if __name__ == "__main__":
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    JOURNAL.write_text("", encoding="utf-8")
    m = Moteur(cfg)
    threading.Thread(target=boucle_sauve, args=(m,), daemon=True).start()
    m.demarre()
