# -*- coding: utf-8 -*-
"""Verifie sur une vraie page Google (via proxy) que les annonces exclues sont filtrees."""
import asyncio

from playwright.async_api import async_playwright

import lsa_plomberie_v3 as L

VILLES = [("plombier", "rezé"), ("plombier", "sarreguemines"), ("plombier", "canteleu"), ("plombier", "nantes")]

exclusions = [L.sigle(l) for l in L.EXCLUSIONS.splitlines() if l.strip()]


def exclu(nom):
    mots_nom = set(L.sigle(nom).split())
    for e in exclusions:
        m = set(e.split())
        if m and m <= mots_nom:
            return True
    return False


async def main():
    lignes = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:6]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(lignes):
            proxy = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[n % len(L.APPAREILS)]
            ctx = await nav.new_context(proxy=L.pw_proxy(proxy), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            ok = False
            for mot, ville in VILLES:
                url = f"https://www.google.fr/search?q={mot}+{ville.replace(' ', '+')}&hl=fr&gl=fr"
                try:
                    rep = await page.goto(url, wait_until="domcontentloaded", timeout=35000)
                except Exception as e:
                    print("KO goto", ville, repr(e)[:70], flush=True)
                    continue
                await page.wait_for_timeout(2600)
                await L.accepter(page)
                for _ in range(3):
                    await page.mouse.wheel(0, 450)
                    await page.wait_for_timeout(400)
                annonces = await page.evaluate(L.JS_ANNONCES)
                print(f"--- proxy {n} {ville} : HTTP {rep.status if rep else '?'} / {len(annonces)} annonce(s)", flush=True)
                for a in annonces:
                    print(f"    {'EXCLUE' if exclu(a['nom']) else 'gardee'} {a['nom']!r}", flush=True)
                if any(exclu(a["nom"]) for a in annonces):
                    ok = True
                    print("    ^ une annonce exclue est bien reconnue", flush=True)
            await ctx.close()
            if ok:
                break
        await nav.close()


asyncio.run(main())
