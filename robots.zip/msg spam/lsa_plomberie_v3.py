#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lsa_plomberie_v3.py - saturation des annonces locales Service de Google (plomberie).

Couverture par departements, communes tirees de l'API officielle geo.api.gouv.fr.
Chaque envoi : contexte jetable, proxy residentiel FR neuf, identite et email aleatoires,
texte de demande fictive different. Compteur par annonce, reprise sur etat.json, boucle infinie.

Interface complete : ciblage, exclusions, proxies, reglages, suivi.
"""
import asyncio
import csv
import json
import queue
import random
import re
import socket
import subprocess
import threading
import time
import tkinter as tk
import unicodedata
import urllib.request
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlparse

import requests
from playwright.async_api import async_playwright

BASE = Path(__file__).resolve().parent
ETAT = BASE / "etat.json"
COMMUNES = BASE / "communes.csv"
PROXIES_TXT = BASE / "proxies_fr.txt"
DEBUG = BASE / "debug"

DEPTS = {"27": "Eure", "76": "Seine-Maritime", "54": "Meurthe-et-Moselle", "57": "Moselle",
         "35": "Ille-et-Vilaine", "44": "Loire-Atlantique", "85": "Vendée"}

# ======================= REGLAGES PAR DEFAUT =======================
MOTS_CLES = "plombier"
EXCLUSIONS = "alves express\nalves express plombier\nsociete plomberie chauffage\nfibre & power\narticompagnons\nsiddi jerome\nfilprop"
SEUIL = 5000
PARALLELE = 20
CIBLE = 300
PAUSE_MIN = 0
PAUSE_MAX = 1
REMPLIR_TEL = False
VISIBLE = False
TWOCAPTCHA_KEY = ""
# ====================================================================

TIMEOUT = 60000

PRENOMS = ["Marie", "Julie", "Camille", "Sophie", "Laura", "Emilie", "Celine", "Nathalie",
           "Thomas", "Julien", "Nicolas", "Antoine", "Maxime", "Pierre", "Vincent", "Hugo",
           "Sarah", "Chloe", "Manon", "Claire", "Alexandre", "Guillaume", "Damien", "Lea",
           "Sandra", "Karine", "Mickael", "Sebastien", "Audrey", "Jessica", "Kevin", "Bruno",
           "Laurent", "Frederic", "Amelie", "Coralie", "Yann", "Stephane", "Patricia", "Didier"]
NOMS = ["Dupont", "Martin", "Bernard", "Petit", "Durand", "Leroy", "Moreau", "Simon", "Laurent",
        "Lefebvre", "Michel", "Garnier", "Faure", "Rousseau", "Blanc", "Guerin", "Muller",
        "Colin", "Henry", "Roussel", "Mathieu", "Clement", "Gauthier", "Perrin", "Chevalier",
        "Robin", "Masson", "Sanchez", "Gerard", "Nguyen", "Boyer", "Denis", "Lemaire"]
DOMAINES_MAIL = ["gmail.com", "gmail.com", "gmail.com", "outlook.fr", "outlook.com",
                 "hotmail.fr", "hotmail.com", "yahoo.fr", "live.fr", "orange.fr",
                 "wanadoo.fr", "free.fr", "sfr.fr", "laposte.net"]

PROBLEMES = [
    "j'ai une fuite sous l'evier, le meuble est en train de gonfler",
    "le siphon de la cuisine fuit depuis ce matin",
    "ma chaudiere affiche un code defaut et ne redemarre plus",
    "plus d'eau chaude depuis hier soir, le chauffe-eau ne s'allume plus",
    "le ballon d'eau chaude fuit par la trappe de visite",
    "les WC sont bouches et l'eau remonte doucement",
    "une canalisation fuit dans le placo, il y a une tache d'humidite",
    "le mitigeur de la douche fuit au niveau du raccord",
    "je veux remplacer un chauffe-eau gaz par un modele electrique",
    "la baignoire fuit au niveau de la bonde",
    "l'evacuation de l'evier est tres lente et ca sent mauvais",
    "le flotteur des toilettes ne s'arrete plus, l'eau coule sans fin",
    "j'ai de l'eau qui perle sous le lavabo de la salle de bain",
    "le radiateur du salon reste froid alors que les autres chauffent",
    "la pompe du chauffage fait un bruit de ferraille",
    "le thermostat affiche une erreur et le chauffage ne demarre plus",
    "la machine a laver deborde au niveau de l'evacuation",
    "un joint sous l'equerre du lave-vaisselle lache",
    "j'ai coupe l'arrivee d'eau, la fuite est sous le carrelage",
    "le tube d'evacuation des eaux usees est perce dans le garage",
    "la colonne d'eau fait du bruit et tremble quand on ouvre le robinet",
    "le robinet du jardin fuit et l'eau coule le long du mur",
    "le chauffe-eau fait des claquements et se met en securite",
    "la pression du circuit de chauffage tombe a zero en une nuit",
    "il y a une remontee d'egout dans la douche",
    "le WC suspendu fuit par le bas au niveau du bati",
    "un tuyau cuivre a gele et s'est fendu dans le cellier",
    "la bonde de la douche est cassee et l'eau stagne",
    "le groupe de securite du ballon fuit en continu",
    "j'ai un ecoulement d'eau sous le plancher des combles",
    "le lavabo se desolidarise du mur, les fixations ont lache",
    "l'adoucisseur deborde et l'eau part sur le sol",
    "le radiateur de la chambre fuit par le purgeur",
    "le ballon thermodynamique affiche un defaut de sonde",
    "le receveur de douche craque et l'eau passe dessous",
    "j'ai besoin de faire remplacer le flexible du mitigeur",
    "le compteur d'eau tourne alors que tout est ferme",
    "l'eau chaude met un temps fou a arriver au robinet",
    "le tuyau de la machine a laver fuit cote mur",
    "le WC est fissure et l'eau suinte par la faience",
    "les evacuations de la salle de bain refoulent",
    "le chauffe-eau electrique disjoncte des qu'on le remet",
    "la vanne d'arret est bloquee et impossible a fermer",
    "le radiateur fait de l'eau au niveau du raccord bas",
    "un filet d'eau sort du mur entre la cuisine et l'entree",
    "le broyeur de l'evier est bloque",
    "la douchette a main fuit a la jonction du flexible",
    "le ballon fuit depuis la veille et j'ai mis une bassine",
    "le sol de la cave est inonde sous l'escalier",
    "le bec du robinet de cuisine s'est detache",
    "le flotteur du WC reste bloque en position haute",
    "le chauffe-bain s'eteint en cours d'utilisation",
    "le tuyau d'alimentation du lave-vaisselle suinte",
    "la trappe de visite du ballon est legerement entrouverte",
    "l'evier se remplit d'eau sale quand la machine tourne",
    "le robinet mitigeur de la baignoire ne tient plus en position",
    "la conduite d'eau froide fait un bruit de marteau",
    "la chasse d'eau fuit en continu dans la cuvette",
    "le radiateur du couloir est tiede en haut et froid en bas",
    "un regard exterieur deborde devant la maison",
    "la pompe de relevage ne s'amorce plus",
    "le joint du raccord lave-linge est mort, ca goutte",
    "la nourrice de chauffage suinte au niveau des departs",
    "le ballon electrique est perce dans le grenier",
    "l'eau tiede remonte dans le lave-vaisselle",
    "le tuyau d'arrivee du WC goutte derriere la cuvette",
    "le mitigeur de cuisine ne delivre plus d'eau chaude",
]

COMPLEMENTS = [
    "le meuble est un modele suspendu", "c'est un appartement au 2e etage",
    "il y a un enfant en bas age a la maison", "la fuite a commence cette nuit",
    "l'eau commence a atteindre le couloir", "j'ai ferme le general mais ca suinte encore",
    "la cuisine est refaite depuis peu", "c'est une maison des annees 70",
    "le ballon a une dizaine d'annees", "les tuyaux sont apparents dans le garage",
    "la salle de bain est petite", "j'ai deja change le joint sans succes",
    "le radiateur est sous la fenetre", "l'installation est en cuivre",
    "la cave est accessible par l'exterieur", "c'est une location meublee",
    "le logement est au rez-de-chaussee", "j'ai deux enfants et plus d'eau",
    "le plancher est en carrelage ancien", "il y a de la moquette dans le salon",
]

OUVERTURES = ["Bonjour", "Bonjour,", "Bonjour a vous", "Bjr", "Salut",
              "Bonsoir", "Hello", "Bonjour, desole pour le derangement"]

QUESTIONS = ["vous pouvez passer aujourd'hui ?",
             "vous auriez de la dispo cette semaine ?",
             "quel est le tarif d'un deplacement et d'un devis ?",
             "quel serait votre delai d'intervention ?",
             "vous faites le diagnostic sur place ?",
             "c'est possible en fin de journee ?",
             "combien coute l'intervention ?",
             "vous pouvez me rappeler rapidement ?",
             "est-ce que vous prenez la carte bleue ?",
             "vous intervenez le samedi ?",
             "il me faut un devis avant, vous pouvez l'envoyer ?",
             "vous avez un creneau demain matin ?"]

SIGNATURES = ["Merci d'avance, {p}", "Cordialement, {p} {n}", "Bien a vous, {p}",
              "Merci, {p}", "Bonne journee, {p} {n}", "Merci de votre retour, {p}",
              "{p} {n}", "Merci beaucoup, {p}"]

RATURES = ["", "", "", "", "Merci de me dire rapidement.", "C'est assez pressant.",
           "Je peux vous envoyer une photo si besoin.", "Je suis joignable par mail."]

APPAREILS = [
    ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 412, 915, 2.6),
    ("Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 360, 800, 3.0),
    ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1", 390, 844, 3.0),
    ("Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 384, 854, 2.8),
]

ARGS = [
    "--no-sandbox",
    "--disable-dev-shm-usage",
    "--disable-http2",
    "--disable-quic",
    "--disable-blink-features=AutomationControlled",
    "--lang=fr-FR",
]

HIDE = "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"

CONSENT_COOKIES = [
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.fr", "path": "/"},
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.com", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.com", "path": "/"},
]

JS_ANNONCES = r"""() => {
  document.querySelectorAll('[data-lsa]').forEach(e => e.removeAttribute('data-lsa'));
  const out = [];
  const nomDe = (el) => {
    let carte = el, nom = '';
    for (let i = 0; i < 10 && carte.parentElement; i++) {
      carte = carte.parentElement;
      const prof = carte.querySelector('a[href*="/localservices/profile"]');
      if (prof) { nom = (prof.innerText || ''); break; }
    }
    if (!nom) {
      let c2 = el;
      for (let i = 0; i < 8 && c2.parentElement; i++) {
        c2 = c2.parentElement;
        const l = (c2.innerText || '').trim().split('\n').filter(x => x.trim());
        if (l.length >= 3) { nom = l[0]; break; }
      }
    }
    return nom.replace(/\s+/g, ' ').trim().split(/\s+\d[.,]\d/)[0].trim();
  };
  const pousser = (el, nom, href) => {
    if (!nom) return;
    let carte = el, txt = "";
    for (let i = 0; i < 5 && carte.parentElement; i++) {
      carte = carte.parentElement;
      txt = (carte.innerText || "").replace(/\s+/g, " ").trim();
      if (txt.length > 40) break;
    }
    el.setAttribute('data-lsa', out.length);
    out.push({i: out.length, nom: nom.slice(0, 80), href: href || '', txt: txt.slice(0, 300) || nom.slice(0, 160)});
  };
  document.querySelectorAll('a[href*="/localservices/messaging"]').forEach(a => {
    pousser(a, nomDe(a), a.getAttribute('href') || '');
  });
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length > 0) return;
    if (!/^MESSAGE$/i.test((el.innerText || '').trim())) return;
    if (el.closest('[data-lsa]')) return;
    let btn = el;
    for (let i = 0; i < 6 && btn.parentElement; i++) {
      if (btn.getAttribute('role') === 'button' || btn.tagName === 'A' || btn.tagName === 'BUTTON') break;
      btn = btn.parentElement;
    }
    let rb = btn.getBoundingClientRect(), garde = btn;
    for (let i = 0; i < 4 && (rb.width < 12 || rb.height < 8) && garde.parentElement; i++) {
      garde = garde.parentElement;
      rb = garde.getBoundingClientRect();
    }
    pousser(garde, nomDe(garde), '');
  });
  return out;
}"""

LOG = lambda m: None


def sans_accents(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def sigle(s):
    return re.sub(r"[^a-z0-9 ]", " ", sans_accents(s).lower()).strip()


def cle(nom, ville):
    return f"{sigle(nom)}|{sigle(ville)}"


def texte_message(pr, no, ville="", vus=None):
    """Compose une demande fictive, jamais deux fois la meme."""
    if ville:
        ville = "-".join(m.capitalize() for m in ville.split("-"))
    for _ in range(15):
        forme = random.choices([1, 2, 3, 4, 5], weights=[4, 3, 3, 2, 2])[0]
        ou = random.choice(OUVERTURES).rstrip(",")
        pb = random.choice(PROBLEMES)
        q = random.choice(QUESTIONS)
        sg = random.choice(SIGNATURES).replace("{p}", pr).replace("{n}", no)
        ra = random.choice(RATURES)
        lieu = f" Je suis a {ville}." if ville and random.random() < 0.75 else ""

        if forme == 1:
            m = f"{ou}, {pb}.{lieu} {q}"
        elif forme == 2:
            m = f"{ou}, je suis {pr} {no}, {pb}.{lieu} {q}"
        elif forme == 3:
            m = f"{ou}, {pb}, {random.choice(COMPLEMENTS)}.{lieu} {q} {ra} {sg}"
        elif forme == 4:
            m = f"{ou}, {pb}.{lieu} {q}"
        else:
            m = f"{ou}, {pb}, {random.choice(COMPLEMENTS)}.{lieu} {sg}"

        m = re.sub(r"\s+", " ", m).strip()
        m = re.sub(r" ([.,!?])", r"\1", m)
        m = m.replace("..", ".")
        m = re.sub(r"(?<=[.!?] )([a-zàâçéèêëîïôûùüÿ])", lambda x: x.group(1).upper(), m)
        if not vus or m not in vus:
            if vus is not None:
                vus.add(m)
                if len(vus) > 2000:
                    vus.pop()
            return m[:600]
    return m[:600]


def normalise_proxy(raw):
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    scheme = "http"
    if "://" in raw:
        scheme, raw = raw.split("://", 1)
        scheme = scheme.lower() if scheme.lower() in ("http", "https", "socks5", "socks4") else "http"
    user = pw = None
    if "@" in raw:
        cred, raw = raw.rsplit("@", 1)
        if ":" in cred:
            user, pw = cred.split(":", 1)
    p = raw.split(":")
    if len(p) >= 4 and user is None:
        host, port, user, pw = p[0], p[1], p[2], ":".join(p[3:])
    elif len(p) >= 2:
        host, port = p[0], p[1]
    else:
        return None
    auth = f"{user}:{pw}@" if user else ""
    return f"{scheme}://{auth}{host}:{port}"


def pw_proxy(p):
    if not p:
        return None
    u = urlparse(p)
    d = {"server": f"{u.scheme}://{u.hostname}:{u.port}"}
    if u.username:
        d["username"] = u.username
        d["password"] = u.password or ""
    return d


def proxy_ok(p, timeout=6):
    u = urlparse(p)
    if not u.hostname or not u.port:
        return False
    try:
        s = socket.create_connection((u.hostname, u.port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False


class Pool:
    """Distribution circulaire : un proxy different a chaque envoi, remis en jeu apres 3 echecs."""

    def __init__(self, lignes):
        self.px = [x for x in (normalise_proxy(l) for l in lignes) if x]
        self.lock = threading.Lock()
        self.i = 0
        self.echecs = {}

    def get(self):
        with self.lock:
            if not self.px:
                return None
            for _ in range(len(self.px)):
                p = self.px[self.i % len(self.px)]
                self.i += 1
                if self.echecs.get(p, 0) < 3:
                    return p
            p = self.px[self.i % len(self.px)]
            self.i += 1
            return p

    def mort(self, p):
        if p:
            with self.lock:
                self.echecs[p] = self.echecs.get(p, 0) + 1


def identite():
    pr, no = random.choice(PRENOMS), random.choice(NOMS)
    base = f"{sans_accents(pr).lower()}.{sans_accents(no).lower()}"
    r = random.random()
    if r < 0.4:
        base += str(random.randint(10, 999))
    elif r < 0.7:
        base += str(random.randint(1960, 2004))
    return {"prenom": pr, "nom": no,
            "mail": f"{base}@{random.choice(DOMAINES_MAIL)}",
            "tel": "06" + "".join(random.choices("0123456789", k=8))}


# ---------------------------------------------------------------- formulaire

async def page_formulaire(ctx, delai=15):
    fin = time.time() + delai
    while time.time() < fin:
        for p in ctx.pages:
            try:
                if await p.locator('textarea:visible, input[type="email"]:visible').count():
                    return p
            except Exception:
                pass
        await asyncio.sleep(0.4)
    return None


async def remplir(page, ident, msg, tel=False):
    ta = page.locator("textarea:visible").first
    if not await ta.count():
        return 0
    await ta.fill(msg[:600])
    n = 1
    mail = page.locator('input[type="email"]:visible').first
    if await mail.count():
        await mail.fill(ident["mail"])
        n += 1
    if tel:
        champ = page.locator('input[type="tel"]:visible').first
        if await champ.count():
            try:
                if (await champ.input_value()) == "":
                    await champ.fill(ident["tel"])
            except Exception:
                pass
    return n


async def captcha_token(page):
    try:
        return await page.evaluate(
            "() => { const t=document.querySelector('textarea[name=\"g-recaptcha-response\"]');"
            " return t ? t.value : ''; }")
    except Exception:
        return ""


async def solve_2captcha(page, key):
    try:
        html = await page.content()
        m = re.search(r'[?&]k=([A-Za-z0-9_\-]{20,})', html) or re.search(r'data-sitekey="([^"]+)"', html)
        if not m:
            return False
        ua = await page.evaluate("navigator.userAgent")
        r = await asyncio.to_thread(lambda: requests.post(
            "https://2captcha.com/in.php",
            data={"key": key, "method": "userrecaptcha", "googlekey": m.group(1),
                  "pageurl": page.url, "userAgent": ua, "json": 1}, timeout=30).json())
        if r.get("status") != 1:
            return False
        rid = r["request"]
        for _ in range(60):
            await page.wait_for_timeout(2000)
            g = await asyncio.to_thread(lambda: requests.get(
                "https://2captcha.com/res.php",
                params={"key": key, "action": "get", "id": rid, "json": 1}, timeout=30).json())
            if g.get("status") == 1:
                await page.evaluate("""(t) => {
                    const el = document.querySelector('textarea[name="g-recaptcha-response"]');
                    if (el) { el.style.display='block'; el.value=t;
                              el.dispatchEvent(new Event('input',{bubbles:true})); }
                }""", g["request"])
                return True
        return False
    except Exception:
        return False


async def captcha(page, key):
    try:
        cadre = page.frame_locator('iframe[src*="recaptcha"]')
        case = cadre.locator("#recaptcha-anchor")
        if await case.count():
            if (await case.get_attribute("aria-checked")) != "true":
                await case.click(timeout=6000)
                await page.wait_for_timeout(1000)
    except Exception:
        pass
    for _ in range(6):
        if await captcha_token(page):
            return "captcha clic"
        await page.wait_for_timeout(400)
    if key and await solve_2captcha(page, key):
        return "captcha 2captcha"
    return "sans captcha"


async def accepter(page):
    """Clique le bandeau de consentement Google s'il est present."""
    for libelle in ("Tout accepter", "J'accepte", "Accepter tout"):
        try:
            b = page.get_by_role("button", name=libelle, exact=False)
            if await b.count():
                await b.first.click(timeout=2500)
                await page.wait_for_timeout(900)
                return True
        except Exception:
            pass
    return False


async def envoyer(page, annonce, ident, msg, dry=False, key="", tel=False):
    """Ouvre le formulaire de l'annonce dans un onglet neuf, remplit, envoie, ferme."""
    cible = None
    try:
        href = annonce.get("href") if isinstance(annonce, dict) else ""
        if href:
            url = href if href.startswith("http") else "https://www.google.fr" + href
            cible = await page.context.new_page()
            await cible.goto(url, wait_until="domcontentloaded", timeout=45000)
            await cible.wait_for_timeout(1200)
        else:
            await page.bring_to_front()
            await page.locator(f'[data-lsa="{annonce["i"]}"]').first.click(timeout=9000)
            cible = await page_formulaire(page.context, 15)
            if not cible:
                raise RuntimeError("formulaire introuvable")
        if not await cible.locator('textarea:visible, input[type="email"]:visible').count():
            cible2 = await page_formulaire(page.context, 8)
            if cible2 and cible2 is not cible:
                try:
                    await cible.close()
                except Exception:
                    pass
                cible = cible2
            if not await cible.locator("textarea:visible").count():
                raise RuntimeError("formulaire introuvable")
        if await remplir(cible, ident, msg, tel) < 2:
            raise RuntimeError("champs non remplis")
        await cible.wait_for_timeout(500)
        motif = await captcha(cible, key)
        if dry:
            return f"dry-run ({motif})"
        btn = cible.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
        if not await btn.count():
            raise RuntimeError("bouton Envoyer introuvable")
        await btn.first.click(timeout=8000)
        fin = time.time() + 35
        while time.time() < fin:
            try:
                t = sans_accents(await cible.inner_text("body")).lower()
            except Exception:
                t = ""
            if any(k in t for k in ("demande envoyee", "message envoye", "bien envoyee",
                                    "prise en charge", "recu votre demande", "envoye a",
                                    "transmis", "merci, votre demande", "a envoye votre demande",
                                    "mis en relation", "verifiez vos e-mails", "verifiez vos emails",
                                    "a ete envoye", "bien recu", "merci de votre demande",
                                    "envoyer a quelques autres", "non, merci")):
                return f"confirme ({motif})"
            if not await cible.locator("textarea").count():
                return f"modale fermee ({motif})"
            await cible.wait_for_timeout(500)
        raise RuntimeError(f"sans confirmation ({motif})")
    finally:
        if cible is not None:
            try:
                await cible.close()
            except Exception:
                pass


# ---------------------------------------------------------------- moteur

class Etat:
    def __init__(self):
        self.lock = threading.Lock()
        self.recus = {}
        self.secs = {}
        self.bonnes = set()
        self.vague = 1
        self.charge()

    def charge(self):
        try:
            d = json.loads(ETAT.read_text(encoding="utf-8"))
            self.recus = d.get("recus", {})
            self.secs = d.get("secs", {})
            self.vague = d.get("vague", 1)
            self.bonnes = set(d.get("bonnes", []))
        except Exception:
            pass

    def sauve(self):
        with self.lock:
            d = {"recus": dict(self.recus), "secs": dict(self.secs), "vague": self.vague,
                 "bonnes": list(self.bonnes),
                 "maj": datetime.now().isoformat(timespec="seconds")}
        try:
            tmp = ETAT.with_suffix(".tmp")
            tmp.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
            tmp.replace(ETAT)
        except Exception:
            pass

    def total(self):
        with self.lock:
            return sum(self.recus.values())


class App:
    def __init__(self, root):
        global LOG
        self.root = root
        root.title("LSA plomberie - saturation")
        root.geometry("1500x940")
        root.minsize(1180, 760)
        self.stop = threading.Event()
        self.q = queue.Queue()
        self.textes = set()
        self.lock = threading.Lock()
        self.stats = {"ok": 0, "fail": 0}
        self.envois = []
        self.running = False
        self.pool = None
        self.fd = None
        self.w = None
        self.etat = Etat()
        self.cvilles = {}
        self.excl = []
        self.villes = []
        self.actives = 0
        self._build()
        LOG = self._log
        self._prefill()
        self._charge_villes()
        root.after(150, self._drain)
        root.after(15000, self._auto_sauve)
        root.after(10000, self._maj_tableau)
        root.protocol("WM_DELETE_WINDOW", self._close)

    # ------------------------------------------------------------- interface
    def _build(self):
        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        self._onglet_ciblage(nb)
        self._onglet_exclusions(nb)
        self._onglet_proxies(nb)
        self._onglet_reglages(nb)
        self._onglet_suivi(nb)
        nb.select(4)

    def _onglet_ciblage(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="Ciblage")
        f.columnconfigure(1, weight=1)
        f.rowconfigure(4, weight=1)

        d = ttk.LabelFrame(f, text="Départements", padding=6)
        d.grid(row=0, column=0, columnspan=2, sticky="ew", pady=4)
        self.v_dep = {}
        for i, (k, nom) in enumerate(DEPTS.items()):
            v = tk.BooleanVar(value=(k in ("44", "85")))
            self.v_dep[k] = v
            ttk.Checkbutton(d, text=f"{k} {nom}", variable=v).grid(row=0, column=i, sticky="w", padx=4)

        h = ttk.Frame(f)
        h.grid(row=1, column=0, columnspan=2, sticky="ew", pady=4)
        ttk.Label(h, text="Population mini :").pack(side="left")
        self.e_seuil = ttk.Entry(h, width=8)
        self.e_seuil.pack(side="left", padx=4)
        ttk.Button(h, text="Construire la liste", command=self._construire).pack(side="left", padx=6)
        ttk.Button(h, text="Recharger depuis geo.api.gouv.fr",
                   command=self._telecharger).pack(side="left", padx=6)
        self.l_villes = ttk.Label(h, text="0 ville", foreground="#555")
        self.l_villes.pack(side="left", padx=18)

        ttk.Label(f, text="Mots-clés (1 par ligne)", font=("", 10, "bold")).grid(
            row=2, column=0, columnspan=2, sticky="w", pady=2)
        self.t_mots = tk.Text(f, height=3)
        self.t_mots.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(20, 4))

        vf = ttk.Frame(f)
        vf.grid(row=3, column=0, columnspan=2, sticky="nsew", pady=4)
        vf.columnconfigure(0, weight=1)
        vf.rowconfigure(1, weight=1)
        ttk.Label(vf, text="Villes retenues (1 par ligne)", font=("", 10, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w")
        self.t_villes = tk.Text(vf, height=4)
        self.t_villes.grid(row=1, column=0, sticky="nsew")
        sb = ttk.Scrollbar(vf, command=self.t_villes.yview)
        sb.grid(row=1, column=1, sticky="ns")
        self.t_villes.configure(yscrollcommand=sb.set)
        ttk.Button(vf, text="Retirer la sélection de la liste",
                   command=self._retirer).grid(row=2, column=0, sticky="w", pady=3)

        lf = ttk.LabelFrame(f, text="Suivi de la couverture", padding=6)
        lf.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=(4, 8))
        lf.columnconfigure(0, weight=1)
        lf.rowconfigure(0, weight=1)
        self.tv = ttk.Treeview(lf, columns=("dep", "ville", "pop", "annonces", "recus"),
                               show="headings", height=8)
        for c, t, w, anc in (("dep", "Dep", 45, "center"), ("ville", "Ville", 330, "w"),
                             ("pop", "Population", 90, "e"), ("annonces", "Annonces", 80, "center"),
                             ("recus", "Messages", 90, "center")):
            self.tv.heading(c, text=t, anchor=anc)
            self.tv.column(c, width=w, anchor=anc, stretch=(c == "ville"))
        self.tv.tag_configure("pair", background="#f2f2f2")
        self.tv.grid(row=0, column=0, sticky="nsew")
        vs = ttk.Scrollbar(lf, command=self.tv.yview)
        vs.grid(row=0, column=1, sticky="ns")
        self.tv.configure(yscrollcommand=vs.set)

    def _onglet_exclusions(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="Exclusions")
        ttk.Label(f, text="Noms d'annonces a ne jamais spammer (1 par ligne, recherche partielle)",
                  font=("", 10, "bold")).pack(anchor="w")
        self.t_excl = tk.Text(f, height=14)
        self.t_excl.pack(fill="both", expand=True, pady=6)
        ttk.Label(f, text="La comparaison ignore accents, casse et ponctuation. "
                          "« alves express » bloque « Alves Express Plombier ».").pack(anchor="w")

    def _onglet_proxies(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="Proxies")
        ttk.Label(f, text="Un proxy par ligne, format hote:port:user:pass",
                  font=("", 10, "bold")).pack(anchor="w")
        self.t_px = tk.Text(f, height=18)
        self.t_px.pack(fill="both", expand=True, pady=6)
        b = ttk.Frame(f)
        b.pack(anchor="w")
        ttk.Button(b, text="Charger un .txt", command=self._charger).pack(side="left")
        ttk.Button(b, text="Sauver dans proxies_fr.txt", command=self._sauver_px).pack(side="left", padx=8)
        self.l_px = ttk.Label(b, text="0 proxy")
        self.l_px.pack(side="left", padx=10)
        ttk.Button(b, text="Tester le 1er proxy", command=self._test_px).pack(side="left", padx=8)
        self.v_sanspx = tk.BooleanVar(value=False)
        ttk.Checkbutton(b, text="Forcer sans proxy (IP locale)", variable=self.v_sanspx).pack(
            side="left", padx=8)
        self.t_px.bind("<KeyRelease>", lambda e: self._maj_compte())

    def _onglet_reglages(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="Réglages")
        g = ttk.Frame(f)
        g.pack(anchor="w", pady=4)
        ttk.Label(g, text="Navigateurs en parallele :").grid(row=0, column=0, sticky="w")
        self.e_par = ttk.Entry(g, width=6)
        self.e_par.grid(row=0, column=1, padx=6, pady=3)
        ttk.Label(g, text="Messages par annonce :").grid(row=1, column=0, sticky="w")
        self.e_cible = ttk.Entry(g, width=6)
        self.e_cible.grid(row=1, column=1, padx=6, pady=3)
        ttk.Label(g, text="Pause entre deux envois (s) :").grid(row=2, column=0, sticky="w")
        pf = ttk.Frame(g)
        pf.grid(row=2, column=1, sticky="w", padx=6)
        self.e_dmin = ttk.Entry(pf, width=5)
        self.e_dmin.pack(side="left")
        ttk.Label(pf, text=" a ").pack(side="left")
        self.e_dmax = ttk.Entry(pf, width=5)
        self.e_dmax.pack(side="left")
        self.v_dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(g, text="Dry-run (aucun envoi reel)", variable=self.v_dry).grid(
            row=3, column=0, columnspan=2, sticky="w", pady=4)
        self.v_vis = tk.BooleanVar(value=VISIBLE)
        ttk.Checkbutton(g, text="Afficher le navigateur", variable=self.v_vis).grid(
            row=4, column=0, columnspan=2, sticky="w", pady=4)
        self.v_tel = tk.BooleanVar(value=REMPLIR_TEL)
        ttk.Checkbutton(g, text="Remplir aussi le telephone", variable=self.v_tel).grid(
            row=5, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Label(g, text="Cle 2captcha (facultatif) :").grid(row=6, column=0, sticky="w")
        self.e_key = ttk.Entry(g, width=50)
        self.e_key.grid(row=6, column=1, sticky="w", padx=6, pady=3)

        z = ttk.LabelFrame(f, text="Compteurs", padding=8)
        z.pack(anchor="w", pady=14)
        self.l_etat = ttk.Label(z, text="0 message cumule - vague 1")
        self.l_etat.pack(anchor="w")
        ttk.Button(z, text="Remettre les compteurs a zero (nouvelle vague)",
                   command=self._raz).pack(anchor="w", pady=6)

    def _onglet_suivi(self, nb):
        f = ttk.Frame(nb, padding=10)
        nb.add(f, text="Suivi")
        b = ttk.Frame(f)
        b.pack(fill="x", pady=4)
        self.b_start = ttk.Button(b, text="DEMARRER", command=self._start)
        self.b_start.pack(side="left")
        self.b_stop = ttk.Button(b, text="STOP", command=self._stop, state="disabled")
        self.b_stop.pack(side="left", padx=8)
        self.l_st = ttk.Label(b, text="OK : 0 | echecs : 0 | 0 msg/min")
        self.l_st.pack(side="left", padx=12)
        cadre = ttk.LabelFrame(f, text="Dernieres annonces servies", padding=4)
        cadre.pack(fill="x", pady=4)
        self.l_fil = ttk.Label(cadre, text="(aucun envoi dans ce cycle)", justify="left", anchor="w",
                               font=("Consolas", 9))
        self.l_fil.pack(fill="x")
        self.journal = tk.Text(f, state="disabled", bg="#111", fg="#ddd")
        self.journal.pack(fill="both", expand=True, pady=4)

    def _prefill(self):
        self.t_mots.insert("1.0", MOTS_CLES)
        exclu_txt = EXCLUSIONS
        try:
            ancienne = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
            lignes = [sigle(l) for l in EXCLUSIONS.splitlines() if l.strip()]
            for e in ancienne.get("exclusions", []):
                if e and e not in lignes:
                    lignes.append(e)
            exclu_txt = "\n".join(lignes)
        except Exception:
            pass
        self.t_excl.insert("1.0", exclu_txt)
        self.t_px.insert("1.0", PROXIES_TXT.read_text(encoding="utf-8", errors="ignore")
                         if PROXIES_TXT.exists() else "")
        self.e_seuil.insert(0, str(SEUIL))
        self.e_par.insert(0, str(PARALLELE))
        self.e_cible.insert(0, str(CIBLE))
        self.e_dmin.insert(0, str(PAUSE_MIN))
        self.e_dmax.insert(0, str(PAUSE_MAX))
        self.e_key.insert(0, TWOCAPTCHA_KEY)
        self._maj_compte()

    def _maj_compte(self):
        n = len([l for l in self.t_px.get("1.0", "end").splitlines() if l.strip()])
        self.l_px.configure(text=f"{n} proxy")
        self.l_villes.configure(text=f"{len(self.villes)} ville(s)")

    # ------------------------------------------------------------- communes
    def _dep_coches(self):
        return [k for k, v in self.v_dep.items() if v.get()]

    def _telecharger(self):
        deps = self._dep_coches()
        if not deps:
            messagebox.showerror("Erreur", "Aucun departement coche")
            return
        self._log(f"Telechargement des communes : {', '.join(deps)}")
        rows = {}
        if COMMUNES.exists():
            try:
                for r in csv.DictReader(COMMUNES.open(encoding="utf-8"), delimiter=";"):
                    rows[(r["departement"], r["ville"], r["cp"])] = int(r["population"] or 0)
            except Exception:
                rows = {}
        for d in deps:
            try:
                u = (f"https://geo.api.gouv.fr/departements/{d}/communes"
                     "?fields=nom,code,population,codesPostaux&format=json")
                data = json.load(urllib.request.urlopen(u, timeout=40))
            except Exception as e:
                self._log(f"KO {d} : {repr(e)[:60]}")
                continue
            for c in data:
                cp = (c.get("codesPostaux") or [""])[0]
                rows[(d, c["nom"], cp)] = c.get("population") or 0
            self._log(f"{d} : {len(data)} communes recuperees")
        with COMMUNES.open("w", encoding="utf-8", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["departement", "ville", "cp", "population"])
            for (d, v, cp), pop in sorted(rows.items()):
                w.writerow([d, v, cp, pop])
        self._log(f"communes.csv : {len(rows)} communes")
        self._construire()

    def _charge_villes(self):
        self._construire(silencieux=True)

    def _construire(self, silencieux=False):
        try:
            seuil = int(self.e_seuil.get() or 0)
        except ValueError:
            seuil = 0
        deps = self._dep_coches()
        vus, garde = set(), []
        if COMMUNES.exists():
            for r in csv.DictReader(COMMUNES.open(encoding="utf-8"), delimiter=";"):
                if r["departement"] not in deps:
                    continue
                if int(r["population"] or 0) < seuil:
                    continue
                if r["ville"] in vus:
                    continue
                vus.add(r["ville"])
                garde.append((r["departement"], r["ville"], r["population"]))
        garde.sort(key=lambda x: -int(x[2]))
        self.villes = [v for _, v, _ in garde]
        self.t_villes.delete("1.0", "end")
        self.t_villes.insert("1.0", "\n".join(self.villes))
        self.tv.delete(*self.tv.get_children())
        for d, v, p in garde:
            n, a = self.cvilles.get(sigle(v), (0, 0))
            self.tv.insert("", "end", values=(d, v, p, a, n),
                           tags=("pair",) if len(self.tv.get_children()) % 2 else ())
        self._maj_compte()
        if not silencieux:
            self._log(f"Liste construite : {len(self.villes)} ville(s) au-dessus de {seuil} hab.")

    # ------------------------------------------------------------- outils
    def _retirer(self):
        if self.t_villes.tag_ranges("sel"):
            a = int(self.t_villes.index("sel.first").split(".")[0])
            b = int(self.t_villes.index("sel.last").split(".")[0])
        else:
            a = b = int(self.t_villes.index("insert").split(".")[0])
        lignes = self.t_villes.get("1.0", "end").splitlines()
        garde = [l for n, l in enumerate(lignes, 1) if l.strip() and not (a <= n <= b)]
        self.t_villes.delete("1.0", "end")
        self.t_villes.insert("1.0", "\n".join(garde))
        self._maj_compte()

    def _maj_tableau(self):
        compte = {}
        try:
            e = json.loads((BASE / "etat.json").read_text(encoding="utf-8"))
            for k, v in e.get("recus", {}).items():
                _, _, ville = k.partition("|")
                n, a = compte.get(sigle(ville), (0, 0))
                compte[sigle(ville)] = (n + v, a + 1)
        except Exception:
            with self.lock:
                compte = dict(self.cvilles)
        modif = 0
        for iid in self.tv.get_children():
            vals = self.tv.item(iid, "values")
            if len(vals) < 3:
                continue
            v = vals[1]
            n, a = compte.get(sigle(v), (0, 0))
            if str(vals[3]) != str(a) or str(vals[4]) != str(n):
                self.tv.item(iid, values=(vals[0], v, vals[2], a, n))
                modif += 1
                if modif > 60:
                    break
        try:
            fs = sorted(BASE.glob("lsa_*.csv"), key=lambda x: x.stat().st_mtime)
            if fs:
                txt = []
                for l in fs[-1].read_text(encoding="utf-8", errors="ignore").splitlines()[-7:]:
                    c = l.split(";")
                    if len(c) < 9 or c[0].startswith("horodatage"):
                        continue
                    txt.append(f"{c[0][11:16]} {'OK' if c[1] == 'ok' else 'KO'}  {c[4][:40]} | {c[3]}")
                self.l_fil.configure(text="\n".join(reversed(txt)) or "(aucun envoi dans ce cycle)")
        except Exception:
            pass
        try:
            j = (BASE / "journal.txt").read_text(encoding="utf-8", errors="ignore").splitlines()[-25:]
            self.journal.configure(state="normal")
            self.journal.delete("1.0", "end")
            self.journal.insert("end", "\n".join(j))
            self.journal.see("end")
            self.journal.configure(state="disabled")
        except Exception:
            pass
        try:
            self.root.after(4000, self._maj_tableau)
        except Exception:
            pass

    def _charger(self):
        pth = filedialog.askopenfilename(filetypes=[("Texte", "*.txt"), ("Tous", "*.*")])
        if not pth:
            return
        with open(pth, encoding="utf-8", errors="ignore") as fh:
            self.t_px.delete("1.0", "end")
            self.t_px.insert("1.0", fh.read())
        self._maj_compte()

    def _test_px(self):
        lignes = [l.strip() for l in self.t_px.get("1.0", "end").splitlines() if l.strip()]
        if not lignes:
            messagebox.showerror("Proxy", "Aucun proxy a tester")
            return
        p = normalise_proxy(lignes[0])
        u = urlparse(p)
        try:
            r = requests.get("http://example.com", timeout=20,
                             proxies={"http": p, "https": p})
            self._log(f"Test proxy {u.hostname}:{u.port} -> HTTP {r.status_code}"
                      + (" (OK)" if r.status_code == 200 else " (refuse)"))
        except Exception as e:
            self._log(f"Test proxy {u.hostname}:{u.port} -> echec {repr(e)[:80]}")

    def _sauver_px(self):
        PROXIES_TXT.write_text(self.t_px.get("1.0", "end").strip() + "\n", encoding="utf-8")
        self._log(f"proxies_fr.txt : {self.l_px.cget('text')}")

    def _raz(self):
        if not messagebox.askyesno("Confirmer", "Remettre tous les compteurs a zero ?"):
            return
        with self.etat.lock:
            self.etat.recus = {}
            self.etat.secs = {}
            self.etat.vague += 1
        self.etat.sauve()
        self._log(f"Compteurs remis a zero - vague {self.etat.vague}")
        self._construire(silencieux=True)

    def _auto_sauve(self):
        self.etat.sauve()
        self.l_etat.configure(text=f"{self.etat.total()} message(s) cumule(s) - vague {self.etat.vague}")
        self.root.after(15000, self._auto_sauve)

    def _log(self, m):
        self.q.put(m)

    def _drain(self):
        lignes = []
        try:
            for _ in range(60):
                lignes.append(f"{datetime.now():%H:%M:%S} {self.q.get_nowait()}")
        except queue.Empty:
            pass
        if lignes:
            self.journal.configure(state="normal")
            self.journal.insert("end", "\n".join(lignes) + "\n")
            if int(self.journal.index("end-1c").split(".")[0]) > 2500:
                self.journal.delete("1.0", "1200.0")
            self.journal.see("end")
            self.journal.configure(state="disabled")
        try:
            c = json.loads((BASE / "compteurs.json").read_text(encoding="utf-8"))
            self.debit_ext = c.get("debit", 0)
            self.ok_ext = c.get("ok", 0)
            self.fail_ext = c.get("fail", 0)
            self.total_ext = c.get("total", 0)
        except Exception:
            pass
        debit = getattr(self, "debit_ext", 0)
        ok = getattr(self, "ok_ext", 0)
        ko = getattr(self, "fail_ext", 0)
        total = getattr(self, "total_ext", 0)
        if (ok, ko, debit, total) != getattr(self, "_dernier_aff", None):
            self._dernier_aff = (ok, ko, debit, total)
            try:
                self.l_st.configure(text=f"OK : {ok} | echecs : {ko} | {debit} msg/min")
                self.root.title(f"LSA plomberie - saturation | {debit} msg/min | {total} cumulés")
            except Exception:
                pass
        try:
            self.root.after(400, self._drain)
        except Exception:
            pass

    def _ligne(self, ligne):
        with self.lock:
            try:
                self.w.writerow(ligne)
                self.fd.flush()
            except Exception:
                pass

    # ------------------------------------------------------------- moteur
    def _start(self):
        if self.running:
            return
        mots = [l.strip() for l in self.t_mots.get("1.0", "end").splitlines()
                if l.strip() and not l.startswith("#")]
        villes = [l.strip() for l in self.t_villes.get("1.0", "end").splitlines()
                  if l.strip() and not l.startswith("#")]
        excl = [sigle(l) for l in self.t_excl.get("1.0", "end").splitlines()
                if l.strip() and not l.startswith("#")]
        px = [l for l in self.t_px.get("1.0", "end").splitlines() if l.strip()]
        if not mots or not villes:
            messagebox.showerror("Erreur", "Il faut au moins un mot-cle et une ville")
            return
        if not px and not self.v_sanspx.get() and not messagebox.askyesno(
                "Sans proxy", "Aucun proxy utilisable. Continuer depuis l'IP locale ?"):
            return
        try:
            cfg = {"par": max(1, int(self.e_par.get())), "cible": max(1, int(self.e_cible.get())),
                   "dmin": max(0.0, float(self.e_dmin.get())), "dmax": max(0.0, float(self.e_dmax.get())),
                   "dry": self.v_dry.get(), "headless": not self.v_vis.get(),
                   "key": self.e_key.get().strip(), "tel": self.v_tel.get()}
        except ValueError:
            messagebox.showerror("Erreur", "Valeurs invalides")
            return
        if cfg["dmax"] < cfg["dmin"]:
            cfg["dmax"] = cfg["dmin"]
        self.excl = [e for e in excl if e]
        self.cvilles = {}
        for k, c in self.etat.recus.items():
            v = k.split("|")[-1]
            n, a = self.cvilles.get(v, (0, 0))
            self.cvilles[v] = (n + c, a + 1)
        if self.v_sanspx.get():
            px = []
            self._log("Mode sans proxy : envoi depuis l'IP locale")
        self.pool = Pool(px)
        self.stats = {"ok": 0, "fail": 0}
        self.envois = []
        self.running = True
        self.stop.clear()
        self.b_start.configure(state="disabled")
        self.b_stop.configure(state="normal")
        config = {"mots": mots, "villes": villes, "exclusions": excl, "proxies": px,
                  "par": cfg["par"], "cible": cfg["cible"], "dmin": cfg["dmin"],
                  "dmax": cfg["dmax"], "dry": cfg["dry"], "headless": cfg["headless"],
                  "key": cfg["key"], "tel": cfg["tel"]}
        (BASE / "config.json").write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")
        (BASE / "journal.txt").write_text("", encoding="utf-8")
        (BASE / "compteurs.json").write_text('{"debit":0,"ok":0,"fail":0,"total":0,"actif":true}',
                                             encoding="utf-8")
        self._pos_journal = 0
        py = r"C:\Users\googl\AppData\Local\Python\pythoncore-3.13-64\python.exe"
        self.proc = subprocess.Popen([py, "moteur.py"], cwd=str(BASE),
                                     creationflags=subprocess.CREATE_NO_WINDOW)
        self._log(f"Moteur lance : {len(villes)} ville(s) x {len(mots)} mot(s), "
                  f"{len(self.pool.px)} proxy(s), {len(self.excl)} exclusion(s), "
                  f"{cfg['par']} parallele, cible {cfg['cible']} msg/annonce")
        self.root.after(300, self._suivre)

    def _suivre(self):
        try:
            txt = (BASE / "journal.txt").read_text(encoding="utf-8", errors="ignore")
        except Exception:
            txt = ""
        if len(txt) > getattr(self, "_pos_journal", 0):
            for l in txt[self._pos_journal:].strip().splitlines():
                self._log(l)
            self._pos_journal = len(txt)
        try:
            c = json.loads((BASE / "compteurs.json").read_text(encoding="utf-8"))
            self.ok_ext = c.get("ok", 0)
            self.fail_ext = c.get("fail", 0)
            self.debit_ext = c.get("debit", 0)
            self.total_ext = c.get("total", 0)
        except Exception:
            pass
        p = getattr(self, "proc", None)
        if p and p.poll() is None:
            self.root.after(500, self._suivre)
        elif p:
            self.running = False
            self.b_start.configure(state="normal")
            self.b_stop.configure(state="disabled")
            self._log(f"Moteur termine (code {p.returncode})")

    def _stop(self):
        self.stop.set()
        p = getattr(self, "proc", None)
        if p and p.poll() is None:
            p.terminate()
            try:
                p.wait(timeout=8)
            except Exception:
                p.kill()
        self._log("Arret demande")

    def _superviseur(self, paires, cfg):
        """Relance le moteur s'il plante. Ne rend la main qu'au STOP."""
        while not self.stop.is_set():
            avant = self.stats["ok"]
            try:
                asyncio.run(self._run(paires, cfg))
            except Exception as e:
                self._log(f"Moteur plante ({type(e).__name__} : {repr(e)[:80]}) - relance dans 10 s")
                time.sleep(10)
                continue
            if self.stop.is_set():
                break
            with self.etat.lock:
                reste = sum(1 for n in self.etat.recus.values() if n < cfg["cible"])
                connu = bool(self.etat.recus)
            if self.stats["ok"] == avant and connu and reste == 0:
                with self.etat.lock:
                    self.etat.vague += 1
                    self.etat.recus = {}
                    self.etat.secs = {}
                self.etat.sauve()
                self._log(f"Couverture saturee : compteurs remis a zero, vague {self.etat.vague}")
            else:
                self._log(f"Passe terminee ({reste} annonce(s) non saturee(s)) - nouvelle passe")
            time.sleep(3)
        try:
            self.root.after(0, self._fini)
        except Exception:
            pass

    async def _run(self, paires, cfg):
        DEBUG.mkdir(exist_ok=True)
        sem = asyncio.Semaphore(cfg["par"])
        file_lock = asyncio.Lock()

        async with async_playwright() as pw:
            nav = await pw.chromium.launch(headless=cfg["headless"], args=ARGS, channel="chrome")
            print("DBG launch ok", flush=True)
            if len(self.etat.bonnes) < 20:
                await self._decouvrir(nav, paires, cfg)
            bonnes = {sigle(v) for v in self.etat.bonnes}
            prio = [p for p in paires if sigle(p[1]) in bonnes]
            reste = [p for p in paires if sigle(p[1]) not in bonnes]
            random.shuffle(prio)
            random.shuffle(reste)
            self.file = prio + reste
            print(f"DBG file={len(self.file)} prio={len(prio)}", flush=True)

            class Frein:
                """Ferme le debit a tous les workers des que Google repond 429."""

                def __init__(self):
                    self.n = 0
                    self.until = 0.0
                    self.lock = asyncio.Lock()

                async def attendre(self):
                    while True:
                        reste = self.until - time.monotonic()
                        if reste <= 0:
                            return
                        await asyncio.sleep(min(reste, 5))

                async def hit(self):
                    async with self.lock:
                        self.n += 1
                        if self.n >= 2:
                            attente = float(min(120 * self.n, 600))
                            self.until = time.monotonic() + attente
                            self._log(f"429 x{self.n} : pause {int(attente)}s")

                def ok(self):
                    self.n = 0

            frein = Frein()

            async def worker(n):
                print(f"DBG worker {n} demarre", flush=True)
                await asyncio.sleep(min(10.0, n * 0.3))
                while not self.stop.is_set():
                    async with file_lock:
                        if not self.file:
                            break
                        mot, ville = self.file.pop()
                    await frein.attendre()
                    async with sem:
                        print(f"DBG worker {n} tache {ville}", flush=True)
                        try:
                            restant = await self._traiter(nav, mot, ville, cfg)
                            frein.ok()
                        except Exception as e:
                            self._log(f"tache '{mot} {ville}' KO : {repr(e)[:60]}")
                            if "rate limit" in repr(e):
                                await frein.hit()
                                reste = 3.0
                            else:
                                reste = 2.0
                            await asyncio.sleep(reste)
                            restant = True
                    if restant and not self.stop.is_set():
                        async with file_lock:
                            if sigle(ville) in self.etat.bonnes:
                                self.file.insert(0, (mot, ville))
                            else:
                                self.file.append((mot, ville))
                    if cfg["dmax"] > 0 and not self.stop.is_set():
                        await asyncio.sleep(random.uniform(cfg["dmin"], cfg["dmax"]))

            print("DBG avant gather", flush=True)
            await asyncio.gather(*[worker(i) for i in range(cfg["par"])])
            print("DBG apres gather", flush=True)
            await nav.close()

    def _exclu(self, nom, txt="", href=""):
        """Vrai si l'annonce correspond a une exclusion (nom, texte de la carte ou lien profil)."""
        champs = " ".join((nom or "", txt or "", href or ""))
        mots_nom = set(sigle(champs).split())
        for e in self.excl:
            mots = set(e.split())
            if mots and mots <= mots_nom:
                return True
        return False

    async def _decouvrir(self, nav, paires, cfg):
        """Repère les villes qui affichent des annonces, sans envoyer."""
        sem = asyncio.Semaphore(cfg["par"])
        self._log(f"Reperage des villes productives sur {len(paires)} requete(s)...")

        async def une(mot, ville):
            async with sem:
                if self.stop.is_set():
                    return
                proxy = self.pool.get() if self.pool.px else None
                ctx = None
                try:
                    ua, w, h, dpr = random.choice(APPAREILS)
                    ctx = await nav.new_context(
                        proxy=pw_proxy(proxy) if proxy else None,
                        user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                        viewport={"width": w, "height": h}, device_scale_factor=dpr,
                        is_mobile=True, has_touch=True)
                    await ctx.add_init_script(HIDE)
                    await ctx.add_cookies(CONSENT_COOKIES)
                    page = await ctx.new_page()
                    url = "https://www.google.fr/search?q=" + (mot if ville.lower() in mot.lower()
                                                               else f"{mot} {ville}").replace(" ", "+") + "&hl=fr&gl=fr"
                    await page.goto(url, wait_until="domcontentloaded", timeout=40000)
                    await page.wait_for_timeout(2200)
                    await page.mouse.wheel(0, 450)
                    await page.wait_for_timeout(700)
                    annonces = await page.evaluate(JS_ANNONCES)
                    if any(not self._exclu(a["nom"], a.get("txt", ""), a.get("href", "")) for a in annonces):
                        self.etat.bonnes.add(ville)
                except Exception:
                    pass
                finally:
                    if ctx:
                        try:
                            await ctx.close()
                        except Exception:
                            pass

        await asyncio.gather(*[une(m, v) for m, v in paires])
        self.etat.sauve()
        self._log(f"Reperage termine : {len(self.etat.bonnes)} ville(s) avec annonces")

    async def _traiter(self, nav, mot, ville, cfg):
        """Un envoi = un contexte et un proxy neufs. True s'il reste du travail sur la requete."""
        if self.stop.is_set():
            return False
        ctx = None
        proxy = self.pool.get() if self.pool.px else None
        print("DBGT proxy", flush=True)
        ident = identite()
        try:
            if proxy and not await asyncio.to_thread(proxy_ok, proxy):
                self.pool.mort(proxy)
                proxy = None
            ua, w, h, dpr = random.choice(APPAREILS)
            ctx = await nav.new_context(
                proxy=pw_proxy(proxy) if proxy else None,
                user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                viewport={"width": w, "height": h}, device_scale_factor=dpr,
                is_mobile=True, has_touch=True)
            await ctx.add_init_script(HIDE)
            await ctx.add_cookies(CONSENT_COOKIES)
            page = await ctx.new_page()
            page.set_default_timeout(TIMEOUT)
            print("DBGT page prete", flush=True)

            requete = mot if ville.lower() in mot.lower() else f"{mot} {ville}"
            url = ("https://www.google.fr/search?q=" + requete.replace(" ", "+") + "&hl=fr&gl=fr")
            dispo = []
            for _tentative in range(3):
                rep = await page.goto(url, wait_until="domcontentloaded", timeout=45000)
                if rep and rep.status in (429, 503):
                    raise RuntimeError(f"rate limit Google ({rep.status})")
                await page.wait_for_timeout(2600)
                await accepter(page)
                for _ in range(3):
                    await page.mouse.wheel(0, 450)
                    await page.wait_for_timeout(500)
                print("DBGT goto ok", flush=True)
                annonces = await page.evaluate(JS_ANNONCES)
                dispo = [a for a in annonces if not self._exclu(a["nom"], a.get("txt", ""), a.get("href", ""))]
                print("DBGT dispo", len(dispo), flush=True)
                if dispo:
                    break
                self.pool.mort(proxy)
                await page.wait_for_timeout(1200)

            if dispo and ville not in self.etat.bonnes:
                self.etat.bonnes.add(ville)
            if not dispo:
                k2 = f"{mot}|{ville}"
                with self.etat.lock:
                    self.etat.secs[k2] = self.etat.secs.get(k2, 0) + 1
                    n = self.etat.secs[k2]
                return n < 6

            # annonce la moins servie, tant qu'elle reste sous la cible
            cible = k = None
            for a in sorted(dispo, key=lambda x: self.etat.recus.get(cle(x["nom"], ville), 0)):
                kk = cle(a["nom"], ville)
                with self.etat.lock:
                    if self.etat.recus.get(kk, 0) >= cfg["cible"]:
                        continue
                    cible, k = a, kk
                    self.etat.recus[k] = self.etat.recus.get(k, 0) + 1
                break
            if not cible:
                return False

            msg = texte_message(ident["prenom"], ident["nom"], ville, self.textes)
            try:
                motif = await envoyer(page, cible, ident, msg, cfg["dry"], cfg["key"], cfg["tel"])
            except Exception as e:
                await page.screenshot(path=str(DEBUG / f"err_{int(time.time())}_{cible['i']}.png"))
                with self.etat.lock:
                    self.etat.recus[k] = max(0, self.etat.recus.get(k, 1) - 1)
                with self.lock:
                    self.stats["fail"] += 1
                self._log(f"'{cible['nom'][:28]}' {ville} KO : {repr(e)[:60]}")
                self._ligne([datetime.now().isoformat(timespec="seconds"), "echec", mot, ville,
                             cible["nom"][:60], ident["mail"], proxy or "", repr(e)[:120], msg])
                return True

            with self.lock:
                self.stats["ok"] += 1
                self.envois.append(time.time())
                n, a = self.cvilles.get(sigle(ville), (0, 0))
                self.cvilles[sigle(ville)] = (n + 1, a)
            self._log(f"OK {cible['nom'][:28]} | {ville} | {ident['mail']}")
            self._ligne([datetime.now().isoformat(timespec="seconds"), "ok", mot, ville,
                         cible["nom"][:60], ident["mail"], proxy or "", motif, msg])
            return True
        finally:
            if ctx:
                try:
                    await ctx.close()
                except Exception:
                    pass

    def _fini(self):
        try:
            self._fini_ui()
        except Exception:
            pass

    def _fini_ui(self):
        self.running = False
        self.b_start.configure(state="normal")
        self.b_stop.configure(state="disabled")
        self.etat.sauve()
        try:
            self.fd.close()
        except Exception:
            pass
        self._log(f"Termine. OK {self.stats['ok']} / echecs {self.stats['fail']}")

    def _close(self):
        self.stop.set()
        self.etat.sauve()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
