# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+nancy&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:3]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(px):
            p = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[0]
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            await page.goto(URL, wait_until="domcontentloaded", timeout=40000)
            await page.wait_for_timeout(3000)
            print(n, "avant:", len(await page.evaluate(L.JS_ANNONCES)), page.url[:60])
            b = page.get_by_role("button", name="Tout accepter", exact=False)
            print("  boutons:", await b.count(), "dialog:", await page.locator("[role=dialog]").count())
            r = await L.accepter(page)
            await page.wait_for_timeout(1500)
            print("  apres accepter", r, ":", len(await page.evaluate(L.JS_ANNONCES)), page.url[:60])
            await ctx.close()
        await nav.close()

asyncio.run(main())
