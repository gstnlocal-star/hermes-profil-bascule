# -*- coding: utf-8 -*-
"""Sonde la SERP mobile pour reperer le bloc d'annonces locales Service."""
import asyncio, json, sys
from pathlib import Path
from playwright.async_api import async_playwright

REQ = sys.argv[1] if len(sys.argv) > 1 else "plombier nancy"
OUT = Path(__file__).parent / "debug"
OUT.mkdir(exist_ok=True)

UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")


async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.launch(headless=True, args=[
            "--disable-blink-features=AutomationControlled", "--lang=fr-FR"])
        ctx = await b.new_context(
            user_agent=UA, locale="fr-FR", timezone_id="Europe/Paris",
            viewport={"width": 412, "height": 915}, device_scale_factor=2.6,
            is_mobile=True, has_touch=True)
        await ctx.add_init_script(
            "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
        p = await ctx.new_page()
        await p.goto("https://www.google.fr/search?q=" + REQ.replace(" ", "+") +
                     "&hl=fr&gl=fr", wait_until="domcontentloaded", timeout=45000)
        await p.wait_for_timeout(4000)
        for t in ["Tout accepter", "J'accepte"]:
            try:
                b2 = p.get_by_role("button", name=t).first
                if await b2.count():
                    await b2.click(timeout=2500)
                    await p.wait_for_timeout(3500)
                    break
            except Exception:
                pass
        await p.mouse.wheel(0, 700)
        await p.wait_for_timeout(1500)
        print("URL:", p.url)
        print("TITRE:", (await p.title())[:80])
        (OUT / "serp_mobile.html").write_text(await p.content(), encoding="utf-8")
        await p.screenshot(path=str(OUT / "serp_mobile.png"), full_page=False)
        # reperage des liens de messagerie / blocs locaux
        info = await p.evaluate("""() => {
          const out = {msg_links: [], blocks: [], texts: []};
          document.querySelectorAll('a[href*="localservices"], a[href*="messaging"]').forEach(a => {
            out.msg_links.push({href: a.href.slice(0,160), txt: (a.innerText||'').slice(0,60)});
          });
          document.querySelectorAll('h1,h2,h3,cite,div[role="heading"]').forEach(h => {
            const t = (h.innerText||'').trim(); if (t) out.texts.push(t.slice(0,80));
          });
          out.texts = out.texts.slice(0,25);
          return out;
        }""")
        print(json.dumps(info, ensure_ascii=False, indent=1)[:2500])
        print("captcha:", "recaptcha" in (await p.content()).lower() or "unusual traffic" in (await p.content()).lower())
        await b.close()

asyncio.run(main())
