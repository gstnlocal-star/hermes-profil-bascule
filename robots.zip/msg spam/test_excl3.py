# -*- coding: utf-8 -*-
"""Test du nouveau matcher d'exclusion sur de vraies annonces (faux positifs compris)."""
import asyncio

from playwright.async_api import async_playwright

import lsa_plomberie_v3 as L

VILLES = [("plombier", "nantes"), ("plombier", "rezé"), ("plombier", "sarrebourg")]

excl = [L.sigle(l) for l in L.EXCLUSIONS.splitlines() if l.strip()]


def exclu(nom, txt="", href=""):
    champs = " ".join((nom or "", txt or "", href or ""))
    mots_nom = set(L.sigle(champs).split())
    for e in excl:
        m = set(e.split())
        if m and m <= mots_nom:
            return True
    return False


async def main():
    lignes = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:8]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(lignes):
            proxy = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[n % len(L.APPAREILS)]
            ctx = await nav.new_context(proxy=L.pw_proxy(proxy), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            total = 0
            for mot, ville in VILLES:
                url = f"https://www.google.fr/search?q={mot}+{ville.replace(' ', '+')}&hl=fr&gl=fr"
                try:
                    rep = await page.goto(url, wait_until="domcontentloaded", timeout=35000)
                except Exception as e:
                    print("KO", ville, repr(e)[:60], flush=True)
                    continue
                await page.wait_for_timeout(2600)
                await L.accepter(page)
                for _ in range(3):
                    await page.mouse.wheel(0, 450)
                    await page.wait_for_timeout(400)
                annonces = await page.evaluate(L.JS_ANNONCES)
                print(f"--- {ville} HTTP {rep.status if rep else '?'} : {len(annonces)} annonce(s)", flush=True)
                for a in annonces:
                    total += 1
                    v = "EXCLUE" if exclu(a["nom"], a.get("txt", ""), a.get("href", "")) else "gardee"
                    print(f"    {v} nom={a['nom']!r} txt={a.get('txt','')[:70]!r}", flush=True)
            await ctx.close()
            if total:
                break
        await nav.close()


asyncio.run(main())
