import asyncio, re
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                await p.goto("https://proxya.co/dashboard/buy?type=residential", wait_until="domcontentloaded")
                await p.wait_for_timeout(2500)
                c = p.locator("input[type=number]").first
                for v in ["5","10","25","50"]:
                    await c.fill(v); await c.dispatch_event("input"); await p.wait_for_timeout(1000)
                    btns = await p.query_selector_all("button")
                    res=[]
                    for bt in btns:
                        try:
                            t=(await bt.inner_text()).strip()
                            if re.match(r"^(Pay|\$)", t): res.append(t.replace("\n"," "))
                        except Exception: pass
                    print(v,"GB ->", res[:3])
                return
asyncio.run(main())
