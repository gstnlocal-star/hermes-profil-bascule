# -*- coding: utf-8 -*-
"""Dry-run v2 : verifie detection + formulaire + texte, sans envoyer."""
import asyncio, sys
from playwright.async_api import async_playwright
import lsa_mobile_v2 as L

MOT = sys.argv[1] if len(sys.argv) > 1 else "plombier lyon"
VILLE = sys.argv[2] if len(sys.argv) > 2 else "lyon"
EXCL = [L.sigle(x) for x in ("alves express", "societe plomberie chauffage")]


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:4]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(px):
            ua, w, h, dpr = L.APPAREILS[n % len(L.APPAREILS)]
            p = L.normalise_proxy(ligne)
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            await page.goto("https://www.google.fr/search?q=" + MOT.replace(" ", "+") + "&hl=fr&gl=fr",
                            wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(3500)
            await page.mouse.wheel(0, 500)
            await page.wait_for_timeout(900)
            ann = await page.evaluate(L.JS_ANNONCES)
            gardees = [a for a in ann if not any(e in " " + L.sigle(a["nom"]) + " " for e in EXCL)]
            print(f"[{n}] annonces={len(ann)} retenues={len(gardees)}",
                  [a["nom"][:30] for a in ann])
            if not gardees:
                await ctx.close()
                continue
            ident = L.identite()
            msg = L.texte_message(ident["prenom"], ident["nom"], VILLE, set())
            print("TEXTE:", msg)
            print("identite:", ident["prenom"], ident["nom"], ident["mail"])
            cible = None
            try:
                await page.locator(f'[data-lsa="{gardees[0]["i"]}"]').first.click(timeout=9000)
                cible = await L.page_formulaire(ctx, 15)
                if not cible:
                    print("KO: formulaire introuvable")
                    await page.screenshot(path="debug/v2_sans_form.png")
                    await ctx.close()
                    continue
                n_ch = await L.remplir(cible, ident, msg, tel=False)
                print("champs remplis:", n_ch)
                print("url form:", cible.url[:120])
                btn = cible.get_by_role("button", name=L.re.compile(r"^Envoyer$", re.I))
                nb = await btn.count()
                dis = await btn.first.is_disabled() if nb else None
                print("bouton Envoyer:", nb, "desactive:", dis)
                req = await cible.evaluate(
                    "() => [...document.querySelectorAll('[required]')].map(e => e.type || e.tagName)")
                print("champs obligatoires:", req)
                await cible.screenshot(path="debug/v2_form.png", full_page=True)
                print("RESULTAT: dry-run OK")
            except Exception as e:
                print("ECHEC:", repr(e)[:200])
                await page.screenshot(path="debug/v2_echec.png")
            finally:
                await ctx.close()
            break
        await nav.close()

asyncio.run(main())
