# -*- coding: utf-8 -*-
import asyncio, json
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        p = [q for q in b.contexts[0].pages if "proxya.co" in q.url][0]
        d = await p.evaluate(r"""() => {
          const out = {buttons: [], selects: [], inputs: [], combos: []};
          document.querySelectorAll('button').forEach(b => {
            const t = (b.innerText || '').trim().slice(0, 40);
            if (t) out.buttons.push(t);
          });
          document.querySelectorAll('select').forEach(s => out.selects.push(s.name || s.id || 'sel'));
          document.querySelectorAll('input').forEach(i => out.inputs.push({t: i.type, ph: i.placeholder, name: i.name}));
          document.querySelectorAll('[role="combobox"], [aria-haspopup]').forEach(c => {
            out.combos.push(((c.innerText || '') + '|' + (c.getAttribute('aria-label') || '')).slice(0, 60));
          });
          return out;
        }""")
        print(json.dumps(d, ensure_ascii=False, indent=1)[:1500])
        # acceptation cookies
        try:
            await p.get_by_role("button", name="Accept all").first.click(timeout=4000)
            print("cookies acceptes")
        except Exception as e:
            print("cookies:", str(e)[:50])
        await p.wait_for_timeout(1000)
asyncio.run(main())
