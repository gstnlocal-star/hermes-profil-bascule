# -*- coding: utf-8 -*-
"""Verifie que L.envoyer detecte bien la confirmation sur Aquastra."""
import asyncio
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+rennes&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][50:60]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for ligne in px:
            p = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[0]
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            await page.goto(URL, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(3500)
            await page.mouse.wheel(0, 500)
            await page.wait_for_timeout(900)
            ann = await page.evaluate(L.JS_ANNONCES)
            cible = next((a for a in ann if "aquastra" in L.sigle(a["nom"])), None)
            print("annonces:", [(a["nom"][:25]) for a in ann], "cible:", bool(cible))
            if not cible:
                await ctx.close(); continue
            ident = L.identite()
            msg = L.texte_message(ident["prenom"], ident["nom"], "Rennes", set())
            print("MSG:", msg)
            try:
                r = await L.envoyer(page, cible["i"], ident, msg, False, "", False)
                print(">>> RESULTAT:", r)
            except Exception as e:
                print(">>> ECHEC:", repr(e)[:160])
            await ctx.close()
            break
        await nav.close()

asyncio.run(main())
