# Boucle d'amélioration quotidienne — robot LSA plomberie

Objectif : faire monter le **taux de confirmation** et le **nombre de messages utiles**, baisser les échecs et les doublons.
Une seule modification par jour, jugée sur les chiffres, annulée si elle n'aide pas.

## Étape 1 — mesurer
```
cd "C:\Users\googl\Desktop\msg spam"
./.venv/Scripts/python.exe bilan.py 24
```
Lire `bilan.txt` et `historique.csv` (la veille = dernière ligne avant aujourd'hui).
Métriques de référence : `taux_confirmation_pct` (à faire monter), `doublons_mail` (à faire baisser), `rate_limit`.

## Étape 2 — diagnostiquer
« sans confirmation » = le formulaire s'ouvre mais Google ne valide pas : texte trop répétitif, mail déjà vu, proxy sale.
`rate limit Google (429)` = débit trop élevé pour l'IP. `formulaire introuvable` = sélecteur ou page qui change.
Regarder les annonces qui concentrent les échecs avant de conclure à un problème de code.

## Étape 3 — une seule amélioration
Leviers, par ordre de préférence :
1. variété des textes et des prénoms dans `lsa_plomberie_v3.py` (tableaux de messages, signatures)
2. débit et backoff : `dmin`/`dmax`, seuils du frein 429, parallélisme
3. découverte : seuil de `bonnes` villes, abandon des annonces stériles, priorisation
4. robustesse : sélecteurs de formulaire, détection de doublon de mail, retry

Interdits : toucher `.venv`, supprimer `etat.json`, vider `proxies_fr.txt`, changer le format du CSV.

## Étape 4 — appliquer proprement
```
cp moteur.py moteur.py.bak_JJHH   (ou lsa_plomberie_v3.py / config.json)
```
Patch minimal, puis :
```
./.venv/Scripts/python.exe -c "import ast;ast.parse(open('moteur.py',encoding='utf-8').read())"
```

## Étape 5 — redémarrer
```
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'cmd.exe' -and $_.CommandLine -like '*Lancer le robot*'} | Select -ExpandProperty ProcessId"
```
Tuer ces cmd avec `taskkill /F /T /PID <pid>`, puis les `pythonw` dont la ligne contient `demarrer.py` sans `--auto`, puis les `python.exe` dont la ligne contient `moteur.py` (ne pas toucher ceux de « clic ads »).
```
powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c','\"\"C:\Users\googl\Desktop\msg spam\Lancer le robot.bat\"\"' -WorkingDirectory 'C:\Users\googl\Desktop\msg spam'"
```

## Étape 6 — vérifier
Attendre 5 à 8 minutes : `compteurs.json` doit progresser en `ok`, `journal.txt` doit contenir des `OK`.
Aucun `OK`, plantage, ou taux de confirmation qui chute : restauration du `.bak`, redémarrage.

## Étape 7 — consigner
Ajouter dans `CHANGELOG.md` : date, métrique visée, hypothèse, changement exact, effet constaté.

## Étape 8 — rendre compte
6 lignes maximum : chiffres de la veille, diagnostic, changement, effet attendu, état du robot, prochain levier.

## Cas particulier proxies
Test CONNECT sur premium.proxya.co:8888 : 402 = crédit épuisé, rester en local (1 en parallèle, frein serré).
200 = crédit revenu : remettre `par` à 20, vérifier que `proxies_fr.txt` contient toujours ses 250 lignes, prévenir Eric en tête de compte rendu.
