# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        pop = [q for q in ctx.pages if "accounts.google.com" in q.url][0]
        await pop.screenshot(path="debug/popup.png")
        n_mail = await pop.locator('input[type="email"]:visible').count()
        n_pass = await pop.locator('input[type="password"]:visible').count()
        print("email visible:", n_mail, "| pass visible:", n_pass)
        for i in range(n_pass):
            v = await pop.locator('input[type="password"]:visible').nth(i).input_value()
            print("pass valeur:", repr(v))
asyncio.run(main())
