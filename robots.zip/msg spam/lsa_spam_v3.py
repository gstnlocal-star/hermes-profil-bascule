#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lsa_spam_v3.py - saturation continue des annonces locales Service de Google (plomberie).

Boucle infinie : pour chaque couple mot-cle / ville, N messages par annonce.
Chaque envoi = navigateur jetable + proxy residentiel FR neuf + identite fausse + texte unique.
Les societes listees dans la liste noire sont ignorees.
"""
import asyncio
import csv
import json
import os
import queue
import random
import re
import socket
import threading
import time
import tkinter as tk
import unicodedata
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from urllib.parse import urlparse

import requests
from playwright.async_api import async_playwright

# ============================ CONFIG ============================
MOTS_CLES = "plombier\nplombier urgence\ndepannage plomberie\nplombier pas cher"
DEPTS = ["27", "76", "54", "57", "35", "44", "85"]
DEPTS_ACTIFS = ["27", "76", "54", "57", "35", "44", "85"]
VILLES = ""
PROXIES = ""
EXCLUSIONS = "alves express\nsociete plomberie chauffage\nfibre & power\narticompagnons"
PARALLELE = 40
MESSAGES_PAR_ANNONCE = 200
PAUSE_MIN = 0.0
PAUSE_MAX = 1.0
REMPLIR_TEL = False
HEADLESS = True
TWOCAPTCHA_KEY = ""
MAX_ESSAIS = 4
# ================================================================

TIMEOUT = 60000
DEBUG = "debug"
VILLES_JSON = "villes_dep.json"

PRENOMS = ["Marie", "Julie", "Camille", "Sophie", "Laura", "Emilie", "Celine", "Nathalie",
           "Thomas", "Julien", "Nicolas", "Antoine", "Maxime", "Pierre", "Vincent", "Hugo",
           "Sarah", "Chloe", "Manon", "Claire", "Alexandre", "Guillaume", "Damien", "Lea",
           "Sandra", "Karine", "Mickael", "Sebastien", "Audrey", "Jessica", "Kevin", "Bruno",
           "Laurent", "Frederic", "Amelie", "Coralie", "Yann", "Stephane", "Patricia", "Didier",
           "Christelle", "Fabrice", "Ophelie", "Romain", "Elodie", "Mathieu", "Cindy", "Gregory"]
NOMS = ["Dupont", "Martin", "Bernard", "Petit", "Durand", "Leroy", "Moreau", "Simon", "Laurent",
        "Lefebvre", "Michel", "Garnier", "Faure", "Rousseau", "Blanc", "Guerin", "Muller",
        "Colin", "Henry", "Roussel", "Mathieu", "Clement", "Gauthier", "Perrin", "Chevalier",
        "Robin", "Masson", "Sanchez", "Gerard", "Nguyen", "Boyer", "Denis", "Lemaire",
        "Fontaine", "Cheval", "Barbier", "Renard", "Schmitt", "Weber", "Hoffmann"]
DOMAINES_MAIL = ["gmail.com", "gmail.com", "gmail.com", "outlook.fr", "outlook.com",
                 "hotmail.fr", "hotmail.com", "yahoo.fr", "live.fr", "orange.fr",
                 "wanadoo.fr", "free.fr", "sfr.fr", "laposte.net"]

PROBLEMES = [
    "j'ai une fuite sous l'evier, le meuble est en train de gonfler",
    "le siphon de la cuisine fuit depuis ce matin",
    "ma chaudiere affiche un code defaut et ne redemarre plus",
    "plus d'eau chaude depuis hier soir, le chauffe-eau ne s'allume plus",
    "le ballon d'eau chaude fuit par la trappe de visite",
    "les WC sont bouches et l'eau remonte doucement",
    "une canalisation fuit dans le placo, il y a une tache d'humidite",
    "le mitigeur de la douche fuit au niveau du raccord",
    "je veux remplacer un chauffe-eau gaz par un modele electrique",
    "la baignoire fuit au niveau de la bonde",
    "l'evacuation de l'evier est tres lente et ca sent mauvais",
    "le flotteur des toilettes ne s'arrete plus, l'eau coule sans fin",
    "j'ai de l'eau qui perle sous le lavabo de la salle de bain",
    "le radiateur du salon reste froid alors que les autres chauffent",
    "la pompe du chauffage fait un bruit de ferraille",
    "le thermostat affiche une erreur et le chauffage ne demarre plus",
    "la machine a laver deborde au niveau de l'evacuation",
    "un joint sous l'equerre du lave-vaisselle lache",
    "j'ai coupe l'arrivee d'eau, la fuite est sous le carrelage",
    "le tube d'evacuation des eaux usees est perce dans le garage",
    "la colonne d'eau fait du bruit et tremble quand on ouvre le robinet",
    "le robinet du jardin fuit et l'eau coule le long du mur",
    "le chauffe-eau fait des claquements et se met en securite",
    "la pression du circuit de chauffage tombe a zero en une nuit",
    "il y a une remontee d'egout dans la douche",
    "le WC suspendu fuit par le bas au niveau du bati",
    "un tuyau cuivre a gele et s'est fendu dans le cellier",
    "la bonde de la douche est cassee et l'eau stagne",
    "le groupe de securite du ballon fuit en continu",
    "j'ai un ecoulement d'eau sous le plancher des combles",
    "le lavabo se desolidarise du mur, les fixations ont lache",
    "l'adoucisseur deborde et l'eau part sur le sol",
    "le radiateur de la chambre fuit par le purgeur",
    "le ballon thermodynamique affiche un defaut de sonde",
    "le receveur de douche craque et l'eau passe dessous",
    "j'ai besoin de faire remplacer le flexible du mitigeur",
    "le compteur d'eau tourne alors que tout est ferme",
    "l'eau chaude met un temps fou a arriver au robinet",
    "le tuyau de la machine a laver fuit cote mur",
    "le WC est fissure et l'eau suinte par la faience",
    "les evacuations de la salle de bain refoulent",
    "le chauffe-eau electrique disjoncte des qu'on le remet",
    "la vanne d'arret est bloquee et impossible a fermer",
    "le radiateur fait de l'eau au niveau du raccord bas",
    "un filet d'eau sort du mur entre la cuisine et l'entree",
    "le broyeur de l'evier est bloque",
    "la douchette a main fuit a la jonction du flexible",
    "le ballon fuit depuis la veille et j'ai mis une bassine",
    "le sol de la cave est inonde sous l'escalier",
    "le bec du robinet de cuisine s'est detache",
    "le flotteur du WC reste bloque en position haute",
    "le chauffe-bain s'eteint en cours d'utilisation",
    "le tuyau d'alimentation du lave-vaisselle suinte",
    "la trappe de visite du ballon est legerement entrouverte",
    "l'evier se remplit d'eau sale quand la machine tourne",
    "le robinet mitigeur de la baignoire ne tient plus en position",
    "la conduite d'eau froide fait un bruit de marteau",
    "la chasse d'eau fuit en continu dans la cuvette",
    "le radiateur du couloir est tiede en haut et froid en bas",
    "un regard exterieur deborde devant la maison",
    "le siphon de la douche est completement bouche",
    "la pompe de relevage ne declenche plus",
    "le ballon electrique fuit au niveau de la resistance",
    "le robinet thermostatique de la douche bloque en position chaude",
    "l'arrivee d'eau du lave-linge est percee",
    "le WC fuit entre la cuvette et le reservoir",
]

COMPLEMENTS = [
    "le meuble est un modele suspendu", "c'est un appartement au 2e etage",
    "il y a un enfant en bas age a la maison", "la fuite a commence cette nuit",
    "l'eau commence a atteindre le couloir", "j'ai ferme le general mais ca suinte encore",
    "la cuisine est refaite depuis peu", "c'est une maison des annees 70",
    "le ballon a une dizaine d'annees", "les tuyaux sont apparents dans le garage",
    "la salle de bain est petite", "j'ai deja change le joint sans succes",
    "le radiateur est sous la fenetre", "l'installation est en cuivre",
    "la cave est accessible par l'exterieur", "c'est une location meublee",
    "le logement est au rez-de-chaussee", "il y a du monde a la maison toute la journee",
]

OUVERTURES = ["Bonjour", "Bonjour,", "Bonjour a vous", "Bjr", "Salut", "Bonjour Monsieur",
              "Bonsoir", "Hello", "Bonjour, desole pour le derangement", "Bonjour, je vous contacte"]

QUESTIONS = ["vous pouvez passer aujourd'hui ?",
             "vous auriez de la dispo cette semaine ?",
             "quel est le tarif d'un deplacement et d'un devis ?",
             "quel serait votre delai d'intervention ?",
             "vous faites le diagnostic sur place ?",
             "c'est possible en fin de journee ?",
             "combien coute l'intervention ?",
             "vous pouvez me rappeler rapidement ?",
             "est-ce que vous prenez la carte bleue ?",
             "vous intervenez le samedi ?",
             "il me faut un devis avant, vous pouvez l'envoyer ?",
             "vous avez un creneau demain matin ?",
             "vous etes disponible ce soir ?",
             "vous pouvez venir voir rapidement ?"]

SIGNATURES = ["Merci d'avance, {p}", "Cordialement, {p} {n}", "Bien a vous, {p}",
              "Merci, {p}", "Bonne journee, {p} {n}", "Merci de votre retour, {p}",
              "{p} {n}", "Merci beaucoup, {p}", "Merci, {p} {n}"]

RATURES = ["", "", "", "", "Merci de me dire rapidement.", "C'est assez pressant.",
           "Je peux vous envoyer une photo si besoin.", "Je suis joignable par mail.",
           "Dites-moi ce qu'il vous faut.", ""]

APPAREILS = [
    ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 412, 915, 2.6),
    ("Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 360, 800, 3.0),
    ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
     "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1", 390, 844, 3.0),
    ("Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/131.0.0.0 Mobile Safari/537.36", 384, 854, 2.8),
    ("Mozilla/5.0 (Linux; Android 13; Redmi Note 12) AppleWebKit/537.36 (KHTML, like Gecko) "
     "Chrome/130.0.0.0 Mobile Safari/537.36", 393, 873, 2.75),
]

ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-dev-shm-usage",
    "--disable-quic",
    "--disable-http2",
    "--dns-prefetch-disable",
    "--disable-background-networking",
    "--disable-features=IsolateOrigins,site-per-process,DnsOverHttps",
    "--lang=fr-FR",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-gpu",
]

HIDE = "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"

CONSENT_COOKIES = [
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.fr", "path": "/"},
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.com", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.com", "path": "/"},
]

JS_ANNONCES = r"""() => {
  document.querySelectorAll('[data-lsa]').forEach(e => e.removeAttribute('data-lsa'));
  const out = [];
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length > 0) return;
    if (!/^MESSAGE$/i.test((el.innerText || '').trim())) return;
    const r = el.getBoundingClientRect();
    if (r.width < 20 || r.height < 15) return;
    let carte = el;
    for (let i = 0; i < 8 && carte.parentElement; i++) {
      carte = carte.parentElement;
      const l = (carte.innerText || '').trim().split('\n').filter(s => s.trim());
      if (l.length >= 3) break;
    }
    const brut = (carte.innerText || '').trim().split('\n').map(s => s.trim()).filter(Boolean);
    const nom = brut[0] || '';
    el.setAttribute('data-lsa', out.length);
    out.push({i: out.length, nom: nom.slice(0, 80), txt: brut.slice(0, 4).join(' / ').slice(0, 160)});
  });
  return out;
}"""


# ============================ OUTILS ============================
def sans_accents(s):
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def sigle(s):
    return re.sub(r"[^a-z0-9 ]", " ", sans_accents(s).lower()).strip()


def texte_message(pr, no, ville="", vus=None):
    for _ in range(15):
        forme = random.choices([1, 2, 3, 4, 5], weights=[4, 3, 3, 2, 2])[0]
        ou = random.choice(OUVERTURES)
        pb = random.choice(PROBLEMES)
        q = random.choice(QUESTIONS)
        sg = random.choice(SIGNATURES).replace("{p}", pr).replace("{n}", no)
        ra = random.choice(RATURES)
        lieu = f" Je suis a {ville}." if ville and random.random() < 0.6 else ""
        if forme == 1:
            m = f"{ou}, {pb}.{lieu} {q}"
        elif forme == 2:
            m = f"{ou}, je suis {pr} {no}, {pb}.{lieu} {q} {sg}"
        elif forme == 3:
            m = f"{ou}, {pb}, {random.choice(COMPLEMENTS)}.{lieu} {q} {ra} {sg}"
        elif forme == 4:
            m = f"{ou}, {pb}.{lieu} {q}"
        else:
            m = f"{ou}, {pb}, {random.choice(COMPLEMENTS)}.{lieu} {sg}"
        m = re.sub(r"\s+", " ", m).strip()
        m = re.sub(r" ([.,!?])", r"\1", m).replace("..", ".")
        m = re.sub(r"(?<=[.!?] )([a-zàâçéèêëîïôûùüÿ])", lambda x: x.group(1).upper(), m)
        if vus is None or m not in vus:
            if vus is not None:
                vus.add(m)
                if len(vus) > 3000:
                    vus.pop()
            return m[:600]
    return m[:600]


def normalise_proxy(raw):
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return None
    scheme = "http"
    if "://" in raw:
        scheme, raw = raw.split("://", 1)
        scheme = scheme.lower() if scheme.lower() in ("http", "https", "socks5", "socks4") else "http"
    user = pw = None
    if "@" in raw:
        cred, raw = raw.rsplit("@", 1)
        if ":" in cred:
            user, pw = cred.split(":", 1)
    p = raw.split(":")
    if len(p) >= 4 and user is None:
        host, port, user, pw = p[0], p[1], p[2], ":".join(p[3:])
    elif len(p) >= 2:
        host, port = p[0], p[1]
    else:
        return None
    auth = f"{user}:{pw}@" if user else ""
    return f"{scheme}://{auth}{host}:{port}"


def pw_proxy(p):
    if not p:
        return None
    u = urlparse(p)
    d = {"server": f"{u.scheme}://{u.hostname}:{u.port}"}
    if u.username:
        d["username"] = u.username
        d["password"] = u.password or ""
    return d


def proxy_ok(p, timeout=5):
    u = urlparse(p)
    if not u.hostname or not u.port:
        return False
    try:
        s = socket.create_connection((u.hostname, u.port), timeout=timeout)
        s.close()
        return True
    except Exception:
        return False


class Pool:
    def __init__(self, lignes):
        self.px = [x for x in (normalise_proxy(l) for l in lignes) if x]
        self.lock = threading.Lock()
        self.i = 0
        self.echecs = {}
        self.maj = time.time()

    def get(self):
        with self.lock:
            if not self.px:
                return None
            if time.time() - self.maj > 900:      # les sticky expirent, on remet les compteurs a zero
                self.echecs.clear()
                self.maj = time.time()
            for _ in range(len(self.px)):
                p = self.px[self.i % len(self.px)]
                self.i += 1
                if self.echecs.get(p, 0) < 4:
                    return p
            self.echecs.clear()
            return self.px[self.i % len(self.px)]

    def mort(self, p):
        if p:
            with self.lock:
                self.echecs[p] = self.echecs.get(p, 0) + 1


def identite():
    pr, no = random.choice(PRENOMS), random.choice(NOMS)
    base = f"{sans_accents(pr).lower()}.{sans_accents(no).lower()}"
    r = random.random()
    if r < 0.4:
        base += str(random.randint(10, 999))
    elif r < 0.7:
        base += str(random.randint(1960, 2004))
    return {"prenom": pr, "nom": no,
            "mail": f"{base}@{random.choice(DOMAINES_MAIL)}",
            "tel": "06" + "".join(random.choices("0123456789", k=8))}


LOG = lambda m: None


# ============================ NAVIGATION ============================
async def page_formulaire(ctx, delai=15):
    fin = time.time() + delai
    while time.time() < fin:
        for p in ctx.pages:
            try:
                if await p.locator('textarea:visible, input[type="email"]:visible').count():
                    return p
            except Exception:
                pass
        await asyncio.sleep(0.35)
    return None


async def remplir(page, ident, msg, tel=False):
    ta = page.locator("textarea:visible").first
    if not await ta.count():
        return 0
    await ta.fill(msg[:600])
    n = 1
    mail = page.locator('input[type="email"]:visible').first
    if await mail.count():
        await mail.fill(ident["mail"])
        n += 1
    if tel:
        champ = page.locator('input[type="tel"]:visible').first
        if await champ.count():
            try:
                if (await champ.input_value()) == "":
                    await champ.fill(ident["tel"])
            except Exception:
                pass
    return n


async def captcha_token(page):
    try:
        return await page.evaluate(
            "() => { const t=document.querySelector('textarea[name=\"g-recaptcha-response\"]');"
            " return t ? t.value : ''; }")
    except Exception:
        return ""


async def solve_2captcha(page, key):
    try:
        html = await page.content()
        m = re.search(r'[?&]k=([A-Za-z0-9_\-]{20,})', html) or re.search(r'data-sitekey="([^"]+)"', html)
        if not m:
            return False
        ua = await page.evaluate("navigator.userAgent")
        r = await asyncio.to_thread(lambda: requests.post(
            "https://2captcha.com/in.php",
            data={"key": key, "method": "userrecaptcha", "googlekey": m.group(1),
                  "pageurl": page.url, "userAgent": ua, "json": 1}, timeout=30).json())
        if r.get("status") != 1:
            return False
        rid = r["request"]
        for _ in range(60):
            await page.wait_for_timeout(2000)
            g = await asyncio.to_thread(lambda: requests.get(
                "https://2captcha.com/res.php",
                params={"key": key, "action": "get", "id": rid, "json": 1}, timeout=30).json())
            if g.get("status") == 1:
                await page.evaluate("""(t) => {
                    const el = document.querySelector('textarea[name="g-recaptcha-response"]');
                    if (el) { el.style.display='block'; el.value=t;
                              el.dispatchEvent(new Event('input',{bubbles:true})); }
                }""", g["request"])
                return True
        return False
    except Exception:
        return False


async def captcha(page, key):
    try:
        cadre = page.frame_locator('iframe[src*="recaptcha"]')
        case = cadre.locator("#recaptcha-anchor")
        if await case.count():
            if (await case.get_attribute("aria-checked")) != "true":
                await case.click(timeout=6000)
                await page.wait_for_timeout(900)
    except Exception:
        pass
    for _ in range(5):
        if await captcha_token(page):
            return "captcha clic"
        await page.wait_for_timeout(350)
    if key and await solve_2captcha(page, key):
        return "captcha 2captcha"
    return "sans captcha"


async def accepter(page):
    """Clique le bandeau de consentement Google s'il est present."""
    for libelle in ("Tout accepter", "J'accepte", "Accepter tout"):
        try:
            b = page.get_by_role("button", name=libelle, exact=False)
            if await b.count():
                await b.first.click(timeout=2500)
                await page.wait_for_timeout(900)
                return True
        except Exception:
            pass
    return False


async def envoyer(page, annonce, ident, msg, dry=False, key="", tel=False):
    cible = None
    try:
        await page.bring_to_front()
        await page.locator(f'[data-lsa="{annonce["i"]}"]').first.click(timeout=9000)
        cible = await page_formulaire(page.context, 22)
        if not cible:
            raise RuntimeError("formulaire introuvable")
        if await remplir(cible, ident, msg, tel) < 2:
            raise RuntimeError("champs non remplis")
        motif = await captcha(cible, key)
        if dry:
            return f"dry-run ({motif})"
        btn = cible.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
        if not await btn.count():
            raise RuntimeError("bouton Envoyer introuvable")
        await btn.first.click(timeout=8000)
        fin = time.time() + 18
        while time.time() < fin:
            try:
                t = sans_accents(await cible.inner_text("body")).lower()
            except Exception:
                t = ""
            if any(k in t for k in ("demande envoyee", "message envoye", "bien envoyee",
                                    "prise en charge", "recu votre demande", "envoye a",
                                    "transmis", "merci, votre demande")):
                return f"confirme ({motif})"
            if not await cible.locator("textarea").count():
                return f"modale fermee ({motif})"
            await cible.wait_for_timeout(450)
        raise RuntimeError(f"sans confirmation ({motif})")
    finally:
        if cible is not None and cible is not page:
            try:
                await cible.close()
            except Exception:
                pass


# ============================ APPLICATION ============================
class App:
    def __init__(self, root):
        global LOG
        self.root = root
        root.title("lsa spam plomberie v3 - 27 76 54 57 35 44 85")
        root.geometry("1120x1000")
        self.stop = threading.Event()
        self.q = queue.Queue()
        self.textes = set()
        self.lock = threading.Lock()
        self.stats = {"ok": 0, "fail": 0}
        self.envois = []
        self.running = False
        self.pool = None
        self.fd = None
        self.w = None
        self.excl = []
        self.cfg = {}
        self.dep_vars = {}
        self.compteur = 0
        self.q_file = 0
        self.queue = None
        self.pw = None
        self._build()
        LOG = self._log
        self._prefill()
        root.after(150, self._drain)
        root.protocol("WM_DELETE_WINDOW", self._close)

    # ---------- interface ----------
    def _build(self):
        p = {"padx": 6, "pady": 3}
        f = ttk.Frame(self.root, padding=10)
        f.pack(fill="both", expand=True)
        f.columnconfigure(1, weight=1)

        ttk.Label(f, text="Mots-cles (1 par ligne)", font=("", 10, "bold")).grid(
            row=0, column=0, sticky="nw", **p)
        self.t_mots = tk.Text(f, height=4)
        self.t_mots.grid(row=0, column=1, sticky="ew", **p)

        dep = ttk.LabelFrame(f, text="Departements", padding=6)
        dep.grid(row=1, column=0, columnspan=2, sticky="ew", **p)
        for i, d in enumerate(DEPTS):
            v = tk.BooleanVar(value=d in DEPTS_ACTIFS)
            self.dep_vars[d] = v
            ttk.Checkbutton(dep, text=d, variable=v).grid(row=0, column=i, padx=3)
        ttk.Button(dep, text="Charger les villes cochees", command=self._villes_dep).grid(
            row=0, column=len(DEPTS), padx=(14, 4))
        ttk.Button(dep, text="Vider", command=lambda: self.t_villes.delete("1.0", "end")).grid(
            row=0, column=len(DEPTS) + 1, padx=4)
        self.l_villes = ttk.Label(dep, text="0 ville")
        self.l_villes.grid(row=0, column=len(DEPTS) + 2, padx=6)

        ttk.Label(f, text="Villes (1 par ligne)", font=("", 10, "bold")).grid(
            row=2, column=0, sticky="nw", **p)
        self.t_villes = tk.Text(f, height=6, wrap="none")
        self.t_villes.grid(row=2, column=1, sticky="ew", **p)
        self.t_villes.bind("<KeyRelease>", lambda e: self._maj_compte())

        ttk.Label(f, text="Ne pas spammer (1 nom par ligne)",
                  font=("", 10, "bold")).grid(row=3, column=0, sticky="nw", **p)
        self.t_excl = tk.Text(f, height=4)
        self.t_excl.grid(row=3, column=1, sticky="ew", **p)

        ttk.Label(f, text="Proxies", font=("", 10, "bold")).grid(row=4, column=0, sticky="nw", **p)
        pf = ttk.Frame(f)
        pf.grid(row=4, column=1, sticky="ew", **p)
        pf.columnconfigure(0, weight=1)
        self.t_px = tk.Text(pf, height=5)
        self.t_px.grid(row=0, column=0, sticky="ew")
        ttk.Button(pf, text="Charger .txt", command=self._charger).grid(row=1, column=0, sticky="w", pady=2)

        o = ttk.LabelFrame(f, text="Reglages", padding=8)
        o.grid(row=5, column=0, columnspan=2, sticky="ew", **p)
        ttk.Label(o, text="En parallele :").grid(row=0, column=0, sticky="w")
        self.e_par = ttk.Entry(o, width=5)
        self.e_par.grid(row=0, column=1)
        ttk.Label(o, text="Messages/annonce :").grid(row=0, column=2, padx=(14, 0))
        self.e_rep = ttk.Entry(o, width=6)
        self.e_rep.grid(row=0, column=3)
        ttk.Label(o, text="Pause min/max (s) :").grid(row=0, column=4, padx=(14, 0))
        self.e_dmin = ttk.Entry(o, width=4)
        self.e_dmin.grid(row=0, column=5)
        self.e_dmax = ttk.Entry(o, width=4)
        self.e_dmax.grid(row=0, column=6)
        self.v_dry = tk.BooleanVar(value=False)
        ttk.Checkbutton(o, text="Dry-run", variable=self.v_dry).grid(row=1, column=0, sticky="w", pady=(6, 0))
        self.v_vis = tk.BooleanVar(value=not HEADLESS)
        ttk.Checkbutton(o, text="Navigateur visible", variable=self.v_vis).grid(
            row=1, column=1, columnspan=2, sticky="w", pady=(6, 0))
        self.v_tel = tk.BooleanVar(value=REMPLIR_TEL)
        ttk.Checkbutton(o, text="Telephone", variable=self.v_tel).grid(
            row=1, column=3, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Label(o, text="Cle 2captcha :").grid(row=2, column=0, sticky="w", pady=(6, 0))
        self.e_key = ttk.Entry(o, width=40)
        self.e_key.grid(row=2, column=1, columnspan=6, sticky="ew", pady=(6, 0))
        o.columnconfigure(6, weight=1)

        b = ttk.Frame(f)
        b.grid(row=6, column=0, columnspan=2, sticky="ew", **p)
        self.b_start = ttk.Button(b, text="DEMARRER", command=self._start)
        self.b_start.pack(side="left")
        self.b_stop = ttk.Button(b, text="STOP", command=self._stop, state="disabled")
        self.b_stop.pack(side="left", padx=8)
        self.l_st = ttk.Label(b, text="OK : 0 | echecs : 0 | 0 msg/min | file : 0")
        self.l_st.pack(side="left", padx=12)

        self.journal = tk.Text(f, height=14, state="disabled", bg="#111", fg="#ddd")
        self.journal.grid(row=7, column=0, columnspan=2, sticky="nsew", **p)
        f.rowconfigure(7, weight=1)

    def _prefill(self):
        self.t_mots.insert("1.0", MOTS_CLES.strip())
        self.t_excl.insert("1.0", EXCLUSIONS.strip())
        self.t_px.insert("1.0", PROXIES.strip())
        self.e_par.insert(0, str(PARALLELE))
        self.e_rep.insert(0, str(MESSAGES_PAR_ANNONCE))
        self.e_dmin.insert(0, str(PAUSE_MIN))
        self.e_dmax.insert(0, str(PAUSE_MAX))
        self.e_key.insert(0, TWOCAPTCHA_KEY)
        self._villes_dep()

    def _villes_dep(self):
        try:
            with open(VILLES_JSON, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            messagebox.showerror("Erreur", "villes_dep.json introuvable")
            return
        l = []
        for d, v in self.dep_vars.items():
            if v.get():
                l += [x["nom"] for x in data.get(d, [])]
        self.t_villes.delete("1.0", "end")
        self.t_villes.insert("1.0", "\n".join(l))
        self._maj_compte()

    def _maj_compte(self):
        n = len([x for x in self.t_villes.get("1.0", "end").splitlines() if x.strip()])
        self.l_villes.configure(text=f"{n} ville(s)")

    def _charger(self):
        pth = filedialog.askopenfilename(filetypes=[("Texte", "*.txt"), ("Tous", "*.*")])
        if not pth:
            return
        with open(pth, encoding="utf-8", errors="ignore") as fh:
            self.t_px.delete("1.0", "end")
            self.t_px.insert("1.0", fh.read())

    def _log(self, m):
        self.q.put(m)

    def _drain(self):
        try:
            while True:
                m = self.q.get_nowait()
                self.journal.configure(state="normal")
                self.journal.insert("end", m + "\n")
                self.journal.see("end")
                if int(self.journal.index("end-1c").split(".")[0]) > 4000:
                    self.journal.delete("1.0", "1500.0")
                self.journal.configure(state="disabled")
        except queue.Empty:
            pass
        bord = time.time() - 60
        with self.lock:
            self.envois = [t for t in self.envois if t > bord]
            debit = len(self.envois)
        self.l_st.configure(text=f"OK : {self.stats['ok']} | echecs : {self.stats['fail']} | "
                                 f"{debit} msg/min | file : {self.q_file}")
        self.root.after(150, self._drain)

    def _ligne(self, ligne):
        with self.lock:
            try:
                self.w.writerow(ligne)
                self.fd.flush()
            except Exception:
                pass

    def _start(self):
        if self.running:
            return
        mots = [l.strip() for l in self.t_mots.get("1.0", "end").splitlines()
                if l.strip() and not l.startswith("#")]
        villes = [l.strip() for l in self.t_villes.get("1.0", "end").splitlines()
                  if l.strip() and not l.startswith("#")]
        excl = [e for e in (sigle(l) for l in self.t_excl.get("1.0", "end").splitlines()
                            if l.strip() and not l.startswith("#")) if e]
        px = [l for l in self.t_px.get("1.0", "end").splitlines() if l.strip()]

        if not mots:
            messagebox.showerror("Erreur", "Aucun mot-cle")
            return
        if not villes:
            messagebox.showerror("Erreur", "Aucune ville")
            return
        if not px:
            if not messagebox.askyesno("Proxies", "Aucun proxy charge. Continuer sans proxy ?"):
                return
        try:
            self.cfg = {"par": max(1, int(self.e_par.get())), "rep": max(1, int(self.e_rep.get())),
                        "dmin": max(0.0, float(self.e_dmin.get())),
                        "dmax": max(0.0, float(self.e_dmax.get())),
                        "dry": self.v_dry.get(), "headless": not self.v_vis.get(),
                        "key": self.e_key.get().strip(), "tel": self.v_tel.get()}
        except ValueError:
            messagebox.showerror("Erreur", "Valeurs invalides")
            return
        if self.cfg["dmax"] < self.cfg["dmin"]:
            self.cfg["dmax"] = self.cfg["dmin"]

        self.excl = excl
        self.pool = Pool(px)
        self.stats = {"ok": 0, "fail": 0}
        self.envois = []
        self.running = True
        self.stop.clear()
        self.b_start.configure(state="disabled")
        self.b_stop.configure(state="normal")
        chemin = f"spam_lsa_{datetime.now():%Y%m%d_%H%M%S}.csv"
        self.fd = open(chemin, "w", newline="", encoding="utf-8")
        self.w = csv.writer(self.fd, delimiter=";")
        self.w.writerow(["horodatage", "statut", "mot_cle", "ville", "annonce", "email",
                         "proxy", "motif", "message"])
        self._log(f"Demarrage : {len(mots)} mot(s)-cle(s) x {len(villes)} ville(s) x "
                  f"{self.cfg['rep']} msg/annonce, {len(self.pool.px)} proxy(s), "
                  f"{len(excl)} exclusion(s), {self.cfg['par']} en parallele")
        threading.Thread(target=self._moteur, args=(mots, villes), daemon=True).start()

    def _stop(self):
        self.stop.set()
        self._log("Arret demande")

    def _moteur(self, mots, villes):
        try:
            asyncio.run(self._run(mots, villes))
        except Exception as e:
            self._log(f"Moteur arrete : {type(e).__name__} {repr(e)[:120]}")
        finally:
            self.root.after(0, self._fini)

    def _exclu(self, nom):
        n = " " + sigle(nom) + " "
        return any(e in n for e in self.excl)

    async def _run(self, mots, villes):
        os.makedirs(DEBUG, exist_ok=True)
        file = asyncio.Queue(maxsize=400)
        self.queue = file
        nav = await self._nav()

        async def producteur():
            tours = 0
            while not self.stop.is_set():
                tours += 1
                paires = [(m, v) for v in villes for m in mots]
                random.shuffle(paires)
                for mot, ville in paires:
                    for k in range(self.cfg["rep"]):
                        if self.stop.is_set():
                            return
                        await file.put((mot, ville, k, 0))
                if tours % 5 == 1:
                    self._log(f"--- tour {tours}, file {file.qsize()} ---")

        async def worker(n):
            while not self.stop.is_set():
                try:
                    mot, ville, k, essai = await asyncio.wait_for(file.get(), timeout=90)
                except asyncio.TimeoutError:
                    if not nav.is_connected():
                        return
                    continue
                self.q_file = file.qsize()
                try:
                    await self._envoyer_un(nav, mot, ville, k, essai)
                except Exception as e:
                    self._log(f"worker {n} : {type(e).__name__} {repr(e)[:90]}")
                finally:
                    file.task_done()
                if self.cfg["dmax"] > 0 and not self.stop.is_set():
                    await asyncio.sleep(random.uniform(self.cfg["dmin"], self.cfg["dmax"]))

        async def surveillant():
            nonlocal nav
            while not self.stop.is_set():
                await asyncio.sleep(20)
                if not nav.is_connected():
                    self._log("navigateur perdu, relance")
                    try:
                        nav = await self._nav()
                    except Exception as e:
                        self._log(f"relance impossible : {repr(e)[:80]}")

        prod = asyncio.create_task(producteur())
        surv = asyncio.create_task(surveillant())
        ws = [asyncio.create_task(worker(i)) for i in range(self.cfg["par"])]
        await asyncio.gather(*ws)
        prod.cancel()
        surv.cancel()
        try:
            await nav.close()
        except Exception:
            pass
        try:
            if self.pw is not None:
                await self.pw.stop()
        except Exception:
            pass
        self.pw = None

    async def _nav(self):
        if self.pw is None:
            self.pw = await async_playwright().start()
        return await self.pw.chromium.launch(headless=self.cfg.get("headless", True), args=ARGS)

    async def _envoyer_un(self, nav, mot, ville, k, essai):
        if self.stop.is_set():
            return
        proxy = self.pool.get() if self.pool.px else None
        ctx = None
        ident = identite()
        try:
            ua, w, h, dpr = random.choice(APPAREILS)
            ctx = await nav.new_context(
                proxy=pw_proxy(proxy) if proxy else None,
                user_agent=ua, locale="fr-FR", timezone_id="Europe/Paris",
                viewport={"width": w, "height": h}, device_scale_factor=dpr,
                is_mobile=True, has_touch=True)
            await ctx.add_init_script(HIDE)
            await ctx.add_cookies(CONSENT_COOKIES)
            page = await ctx.new_page()
            page.set_default_timeout(TIMEOUT)

            if proxy and not await asyncio.to_thread(proxy_ok, proxy):
                self.pool.mort(proxy)

            requete = mot if ville.lower() in mot.lower() else f"{mot} {ville}"
            url = "https://www.google.fr/search?q=" + requete.replace(" ", "+") + "&hl=fr&gl=fr"
            annonces = []
            for tentative in range(2):
                await page.goto(url, wait_until="domcontentloaded", timeout=40000)
                await page.wait_for_timeout(2800)
                await accepter(page)
                await page.mouse.wheel(0, 450)
                await page.wait_for_timeout(900)
                annonces = [a for a in await page.evaluate(JS_ANNONCES) if not self._exclu(a["nom"])]
                if annonces:
                    break
                self.pool.mort(proxy)
                await page.wait_for_timeout(1500)
            if not annonces:
                raise RuntimeError("aucune annonce")
            ann = annonces[self.compteur % len(annonces)]
            self.compteur += 1

            msg = texte_message(ident["prenom"], ident["nom"], ville, self.textes)
            motif = await envoyer(page, ann, ident, msg, self.cfg["dry"], self.cfg["key"], self.cfg["tel"])
            with self.lock:
                self.stats["ok"] += 1
                self.envois.append(time.time())
            self._log(f"OK {ville} '{ann['nom'][:32]}' {motif}")
            self._ligne([datetime.now().isoformat(timespec="seconds"), "ok", mot, ville,
                         ann["nom"][:60], ident["mail"], proxy or "", motif, msg])
        except Exception as e:
            self._log(f"KO {ville} '{mot}' essai {essai+1} : {repr(e)[:80]}")
            with self.lock:
                self.stats["fail"] += 1
            if essai + 1 < MAX_ESSAIS and not self.stop.is_set():
                try:
                    self.queue.put_nowait((mot, ville, k, essai + 1))
                except asyncio.QueueFull:
                    pass
            else:
                self._ligne([datetime.now().isoformat(timespec="seconds"), "echec", mot, ville,
                             "", ident["mail"], proxy or "", repr(e)[:120], ""])
        finally:
            if ctx:
                try:
                    await ctx.close()
                except Exception:
                    pass

    def _fini(self):
        self.running = False
        self.b_start.configure(state="normal")
        self.b_stop.configure(state="disabled")
        try:
            self.fd.close()
        except Exception:
            pass
        self._log(f"Termine. OK {self.stats['ok']} / echecs {self.stats['fail']}")

    def _close(self):
        self.stop.set()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
