# -*- coding: utf-8 -*-
import asyncio, re
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        p = [q for q in b.contexts[0].pages if "proxya.co" in q.url][0]
        await p.get_by_role("button", name="Sticky", exact=True).first.click()
        await p.wait_for_timeout(1500)
        await p.get_by_role("button", name="Generate Proxies").last.scroll_into_view_if_needed()
        await p.get_by_role("button", name="Generate Proxies").last.click()
        await p.wait_for_timeout(8000)
        t = await p.inner_text("body")
        m = re.findall(r"premium\.proxya\.co:\d+:[A-Za-z0-9._:\-]+", t)
        vus, pr = set(), []
        for x in m:
            if x not in vus:
                vus.add(x); pr.append(x)
        print("brut:", len(m), "uniques:", len(pr))
        for x in pr[:4]:
            print("  ", x)
        open("proxies_fr.txt", "w", encoding="utf-8").write("\n".join(pr) + "\n")
asyncio.run(main())
