# -*- coding: utf-8 -*-
"""Envoi reel d'un message sur la 1re annonce d'un mot-cle."""
import asyncio, sys
from playwright.async_api import async_playwright
import lsa_mobile as L

MOT = sys.argv[1] if len(sys.argv) > 1 else "chauffagiste lyon"
ZONE = sys.argv[2] if len(sys.argv) > 2 else "lyon"

async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][7:12]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(px):
            ua, w, h, dpr, _ = L.APPAREILS[n % len(L.APPAREILS)]
            ctx = await nav.new_context(proxy=L.pw_proxy(L.normalise_proxy(ligne)), user_agent=ua,
                                        locale="fr-FR", timezone_id="Europe/Paris",
                                        viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                        is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            p = await ctx.new_page()
            await p.goto("https://www.google.fr/search?q=" + MOT.replace(" ", "+") + "&hl=fr&gl=fr",
                         wait_until="domcontentloaded", timeout=45000)
            await p.wait_for_timeout(4000)
            for _ in range(3):
                await p.mouse.wheel(0, 400)
                await p.wait_for_timeout(900)
            ann = await p.evaluate(L.JS_ANNONCES)
            print(f"[{n}] annonces:", len(ann), [a["nom"][:30] for a in ann])
            if not ann:
                await ctx.close()
                continue
            ident = L.identite()
            print("identite:", ident["prenom"], ident["mail"])
            try:
                motif = await L.envoyer(p, ann[0], ident, L.texte_message(ident["prenom"], ident["nom"], ZONE), ZONE)
                print("RESULTAT:", motif)
            except Exception as e:
                print("ECHEC:", repr(e)[:150])
                await p.screenshot(path="debug/echec_envoi.png")
            await ctx.close()
            break
        await nav.close()
asyncio.run(main())
