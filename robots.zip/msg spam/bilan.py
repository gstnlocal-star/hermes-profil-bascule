#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Metriques du robot LSA plomberie sur la fenetre demandee (24 h par defaut).

Sortie : bilan.json + bilan.txt dans le dossier, et une ligne dans historique.csv.
Aucune modification du code : lecture seule des CSV.
"""
import csv
import glob
import json
import os
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
FEN = float(sys.argv[1]) if len(sys.argv) > 1 else 24.0
BORD = datetime.now() - timedelta(hours=FEN)


def retenus(files):
    for f in files:
        try:
            if datetime.fromtimestamp(os.path.getmtime(f)) < BORD:
                continue
        except OSError:
            continue
        yield f


def main():
    fichiers = list(retenus(glob.glob(str(BASE / "lsa_*.csv"))))
    stat, motif, annonces, villes, heures, mails = Counter(), Counter(), Counter(), Counter(), Counter(), Counter()
    n = 0
    for f in fichiers:
        with open(f, encoding="utf-8-sig", errors="replace", newline="") as fh:
            for r in csv.reader(fh, delimiter=";"):
                if len(r) < 8 or r[0].startswith("horodatage"):
                    continue
                try:
                    t = datetime.fromisoformat(r[0])
                except ValueError:
                    continue
                if t < BORD:
                    continue
                n += 1
                stat[r[1]] += 1
                heures[t.strftime("%H")] += 1
                if r[1] == "ok":
                    annonces[r[4]] += 1
                    villes[r[3]] += 1
                    mails[r[5].lower()] += 1
                else:
                    motif[r[7][:60]] += 1
    ok = stat.get("ok", 0)
    bilan = {
        "fenetre_h": FEN,
        "tentatives": n,
        "ok": ok,
        "taux_confirmation_pct": round(100.0 * ok / n, 1) if n else 0.0,
        "echecs": stat.get("echec", 0),
        "rate_limit": motif.get("RuntimeError('rate limit Google (429)')", 0),
        "motifs": dict(motif.most_common(10)),
        "annonces": dict(annonces.most_common(15)),
        "villes_servies": len(villes),
        "mails_distincts": len(mails),
        "doublons_mail": sum(v - 1 for v in mails.values() if v > 1),
        "par_heure": {h: heures[h] for h in sorted(heures)},
        "fichiers": [os.path.basename(f) for f in fichiers],
    }

    lignes = [
        f"Bilan LSA - {datetime.now():%Y-%m-%d %H:%M} - fenetre {FEN:g} h",
        f"tentatives: {n} | confirmes: {ok} | taux: {bilan['taux_confirmation_pct']} % | echecs: {bilan['echecs']}",
        f"villes servies: {len(villes)} | mails distincts: {len(mails)} | doublons: {bilan['doublons_mail']}",
        "motifs d'echec: " + (", ".join(f"{k}={v}" for k, v in motif.most_common(8)) or "-"),
        "annonces servies: " + (", ".join(f"{k}={v}" for k, v in annonces.most_common(10)) or "-"),
        "par heure: " + (", ".join(f"{h}h={v}" for h, v in bilan["par_heure"].items()) or "-"),
    ]
    (BASE / "bilan.json").write_text(json.dumps(bilan, ensure_ascii=False, indent=1), encoding="utf-8")
    (BASE / "bilan.txt").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    with open(BASE / "historique.csv", "a", newline="", encoding="utf-8") as fh:
        csv.writer(fh, delimiter=";").writerow(
            [f"{datetime.now():%Y-%m-%d %H:%M}", f"{FEN:g}", n, ok, bilan["taux_confirmation_pct"], bilan["echecs"]])
    print("\n".join(lignes))


if __name__ == "__main__":
    main()
