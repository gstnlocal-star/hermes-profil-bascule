# -*- coding: utf-8 -*-
"""Envoi reel sur Aquastra + capture de ce qui se passe apres le clic."""
import asyncio, re, sys
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+rennes&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][40:50]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for ligne in px:
            p = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[0]
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            await page.goto(URL, wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(3500)
            await page.mouse.wheel(0, 500)
            await page.wait_for_timeout(900)
            ann = await page.evaluate(L.JS_ANNONCES)
            cible = next((a for a in ann if "aquastra" in L.sigle(a["nom"])), None)
            if not cible:
                await ctx.close(); continue
            await page.locator(f'[data-lsa="{cible["i"]}"]').first.click(timeout=9000)
            form = await L.page_formulaire(ctx, 15)
            if not form:
                await ctx.close(); continue
            ident = L.identite()
            msg = L.texte_message(ident["prenom"], ident["nom"], "Rennes", set())
            print("MSG:", msg)
            print("remplis:", await L.remplir(form, ident, msg, False))
            print("captcha:", await L.captcha(form, ""))
            btn = form.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
            await btn.first.click(timeout=8000)
            for attente in (3000, 3000, 6000, 8000):
                await page.wait_for_timeout(attente)
                txt = await form.inner_text("body")
                print("--- apres", attente, "url:", form.url[:80])
                print("   TEXTE:", L.sans_accents(txt)[-400:].replace("\n", " | "))
            await form.screenshot(path="debug/aquastra_apres.png", full_page=True)
            await ctx.close()
            break
        await nav.close()

asyncio.run(main())
