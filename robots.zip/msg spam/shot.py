import asyncio, sys, os
from playwright.async_api import async_playwright
OUT = os.path.abspath(sys.argv[1] if len(sys.argv)>1 else "shot.png")
URL = sys.argv[2] if len(sys.argv)>2 else None
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                if URL:
                    await p.goto(URL, wait_until="domcontentloaded"); await p.wait_for_timeout(3500)
                await p.set_viewport_size({"width":1440,"height":1000})
                await p.screenshot(path=OUT, full_page=True)
                print("OK", OUT)
                return
asyncio.run(main())
