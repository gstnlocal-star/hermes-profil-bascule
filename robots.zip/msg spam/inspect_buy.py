import asyncio, re
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                print("URL:", p.url)
                txt = await p.inner_text("body")
                print("---TEXTE---")
                print(txt[:3000])
                print("---BOUTONS---")
                for el in await p.query_selector_all("button, a, input[type=submit]"):
                    try:
                        t = (await el.inner_text()).strip() or await el.get_attribute("value") or ""
                        if t: print(repr(t[:60]), await el.get_attribute("class"))
                    except Exception: pass
                return
asyncio.run(main())
