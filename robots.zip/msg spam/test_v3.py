# -*- coding: utf-8 -*-
"""Test v3 : une requete, deux messages en dry-run, via le meme chemin que le moteur."""
import asyncio, sys, time
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

MOT = sys.argv[1] if len(sys.argv) > 1 else "plombier"
VILLE = sys.argv[2] if len(sys.argv) > 2 else "nancy"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:3]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, ligne in enumerate(px):
            p = L.normalise_proxy(ligne)
            ua, w, h, dpr = L.APPAREILS[n % len(L.APPAREILS)]
            ctx = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            t0 = time.time()
            await page.goto("https://www.google.fr/search?q=" + f"{MOT} {VILLE}".replace(" ", "+") + "&hl=fr&gl=fr",
                            wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(3500)
            await page.mouse.wheel(0, 500)
            await page.wait_for_timeout(900)
            ann = await page.evaluate(L.JS_ANNONCES)
            print(f"[{n}] chargement {time.time()-t0:.1f}s annonces={len(ann)}", [a["nom"][:28] for a in ann])
            if not ann:
                await ctx.close()
                continue
            ident = L.identite()
            ok = 0
            for a in ann[:2]:
                msg = L.texte_message(ident["prenom"], ident["nom"], VILLE, set())
                print("  TEXTE:", msg)
                try:
                    r = await L.envoyer(page, a["i"], ident, msg, dry=True)
                    print("  RESULTAT:", r)
                    ok += 1
                except Exception as e:
                    print("  ECHEC:", repr(e)[:180])
                    await page.screenshot(path="debug/v3_echec.png")
            print(f"  -> {ok}/2 formulaires remplis, onglets restants: {len(ctx.pages)}")
            await ctx.close()
            break
        await nav.close()

asyncio.run(main())
