import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "heleket" not in p.url: continue
                box = await p.get_by_text("Select currency", exact=True).last.bounding_box()
                print("box", box)
                await p.mouse.click(box["x"]+box["width"]/2, box["y"]+box["height"]/2)
                await p.wait_for_timeout(1800)
                await p.screenshot(path="C:/tmp/heleket_list2.png", full_page=False)
                # dump des elements cliquables visibles
                txts=[]
                for el in await p.query_selector_all("div, li, span"):
                    try:
                        t=(await el.inner_text()).strip()
                        if 0 < len(t) <= 14 and "\n" not in t: 
                            bb = await el.bounding_box()
                            if bb and bb["height"]>10 and bb["width"]>10: txts.append(t)
                    except Exception: pass
                print("VIS:", list(dict.fromkeys(txts))[:60])
                return
asyncio.run(main())
