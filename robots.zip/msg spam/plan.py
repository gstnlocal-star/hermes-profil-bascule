import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                await p.goto("https://proxya.co/dashboard/buy?type=residential", wait_until="domcontentloaded")
                await p.wait_for_timeout(3000)
                for onglet in ["Premium","Pro"]:
                    el = p.get_by_text(onglet, exact=True).first
                    try:
                        await el.click(); await p.wait_for_timeout(1200)
                        txt = await p.inner_text("body")
                        import re
                        i = txt.find("Residential balance")
                        print("=== PLAN", onglet, "===")
                        print(txt[i:i+400].replace("\n"," | ") if i>=0 else "pas de bloc balance")
                    except Exception as e: print(onglet,"ERR",str(e)[:100])
                return
asyncio.run(main())
