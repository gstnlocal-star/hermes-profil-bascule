# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

MAIL = "gstnlocal@gmail.com"

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        pop = [q for q in ctx.pages if "accounts.google.com" in q.url][0]
        await pop.bring_to_front()
        champ = pop.locator('input[type="email"]').first
        if await champ.count():
            await champ.fill(MAIL)
            await pop.wait_for_timeout(300)
            await pop.locator('#identifierNext').first.click()
            await pop.wait_for_timeout(4000)
        print("URL:", pop.url[:100])
        print("TXT:", (await pop.inner_text("body"))[:300].replace("\n", " | "))
        # mot de passe demande ?
        try:
            if await pop.locator('input[type="password"]').count():
                print("=> MOT DE PASSE DEMANDE")
        except Exception:
            pass
asyncio.run(main())
