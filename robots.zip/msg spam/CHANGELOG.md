# Journal des changements — robot LSA plomberie

Chaque ligne : date, métrique visée, hypothèse, changement, effet constaté.

## 2026-11-18 01:30 — mise sous boucle quotidienne
Base de départ, mesurée sur 24 h : 5999 tentatives, 5695 confirmés, taux 94,9 %, 100 doublons de mail, 263 villes.

### 2026-11-18 01:05 — frein sur les 429 en IP locale
Hypothèse : sans proxy, Google bloque l'IP et chaque 429 rapproché entretient le blocage.
Changement : frein global dans moteur.py, deux 429 consécutifs ferment le débit 240 s, puis 360, 480, 600 au maximum ; le chien de garde passe de 210 à 1200 s pour ne pas tuer le moteur pendant une pause.
Effet attendu : moins d'appels inutiles, reprise automatique dès que Google rouvre.

### 2026-11-18 01:20 — interface rendue honnête
La fenêtre affichait ses propres compteurs et ignorait le travail du moteur, lancé dans un autre process. Elle lit maintenant compteurs.json et etat.json, ouvre l'onglet Suivi par défaut et affiche les dernières annonces servies ainsi que le journal en direct.
