# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright

MAIL = "gstnlocal@gmail.com"

async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        ctx = b.contexts[0]
        pop = [q for q in ctx.pages if "accounts.google.com" in q.url][0]
        await pop.bring_to_front()
        box = pop.locator('input[name="identifier"], input[type="email"]').first
        await box.click(timeout=10000)
        await pop.keyboard.type(MAIL, delay=45)
        await pop.wait_for_timeout(400)
        await pop.keyboard.press("Enter")
        await pop.wait_for_timeout(5000)
        print("URL:", pop.url[:80])
        vis = await pop.evaluate("""() => {
            const pw = document.querySelector('input[type=password]');
            const box = pw ? pw.getBoundingClientRect() : null;
            return {pass: !!pw, visible: box ? (box.width>0 && box.height>0) : false};
        }""")
        print("etat:", vis)
        await pop.screenshot(path="debug/popup2.png")
asyncio.run(main())
