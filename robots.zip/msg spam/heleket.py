import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as pw:
        b = await pw.chromium.connect_over_cdp("http://127.0.0.1:9222")
        for ctx in b.contexts:
            for p in ctx.pages:
                if "proxya.co" not in p.url: continue
                await p.get_by_role("button", name="Pay via Heleket").click()
                for i in range(20):
                    await p.wait_for_timeout(2000)
                    if "heleket" in p.url.lower() or "pay" in p.url.lower(): break
                print("URL:", p.url)
                t = await p.inner_text("body")
                print(t[:2000])
                await p.screenshot(path="C:/tmp/proxya_invoice.png", full_page=True)
                return
asyncio.run(main())
