# Robot LSA plomberie

Sature les annonces locales Service de Google (plomberie) avec de fausses demandes de particuliers.
Chaque envoi part d'une IP residentielle differente, avec une identite et un email aleatoires et un
texte different.

## Lancer

Double-clic sur `Lancer le robot.bat` (ou `pythonw lsa_plomberie_v3.py`).

## Reglages

- **Ciblage** : departements 27, 76, 54, 57, 35, 44, 85. Le bouton `Construire la liste` filtre les
  communes selon la population mini. `Recharger depuis geo.api.gouv.fr` met a jour `communes.csv`.
  Les villes peuvent etre ajoutees ou retirees a la main dans la liste.
- **Exclusions** : noms d'annonces a ne jamais spammer. Comparaison partielle, insensible aux accents,
  a la casse et a la ponctuation. Deja rempli : Alves Express, Societe Plomberie Chauffage,
  Fibre & Power, Articompagnons.
- **Proxies** : un proxy residentiel FR par ligne (`hote:port:user:pass`). 500 proxies Proxya dans
  `proxies_fr.txt`, regenerables depuis le dashboard Proxya (profil GSTN, onglet Buy Proxy,
  Residential, France, rotation, Generate, puis .txt).
- **Reglages** : navigateurs en parallele (60 par defaut), messages par annonce (300 par defaut),
  pause, dry-run, navigateur visible, telephone.

## Fonctionnement

Le moteur construit toutes les paires mot-cle x ville, les melange, et les distribue a 60 navigateurs
qui tournent en continu. A chaque passage : nouveau contexte, nouveau proxy, nouvelle identite,
nouveau texte, envoi sur les annonces non saturees, fermeture du contexte. Quand la requete est saturee
ou ne renvoie pas d'annonce, elle est remise en file (3 tentatives) puis abandonnee jusqu'a la passe
suivante.

Les compteurs par annonce sont dans `etat.json`. Quand toutes les annonces connues atteignent la cible,
les compteurs sont remis a zero et une nouvelle vague demarre : le robot ne s'arrete jamais seul.
Bouton `Remettre les compteurs a zero` pour forcer une nouvelle vague.

Deux fichiers sont ecrits a cote : `lsa_<date>.csv` (journal des envois) et `debug/` (captures des echecs).

## Points de vigilance

- Google n'affiche pas le bloc d'annonces sur toutes les requetes : c'est normal, le moteur continue.
- Le formulaire demande une adresse email ; le telephone n'est pas rempli par defaut.
- Les emails etant fictifs, les reponses des artisans ne sont jamais lues.
- Le compte Proxya doit avoir du credit : 500 proxies residentiels FR consommes par generation.
