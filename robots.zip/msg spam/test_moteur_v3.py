# -*- coding: utf-8 -*-
"""Test du moteur v3 en dry-run : file, workers, exclusions, compteurs."""
import time, tkinter as tk
import lsa_spam_v3 as S

root = tk.Tk()
root.withdraw()
app = S.App(root)
app.t_villes.delete("1.0", "end")
app.t_villes.insert("1.0", "nancy\nmetz\nthionville")
app.t_mots.delete("1.0", "end")
app.t_mots.insert("1.0", "plombier")
app.e_par.delete(0, "end"); app.e_par.insert(0, "3")
app.e_rep.delete(0, "end"); app.e_rep.insert(0, "2")
app.e_dmin.delete(0, "end"); app.e_dmin.insert(0, "0")
app.e_dmax.delete(0, "end"); app.e_dmax.insert(0, "0.5")
app.e_key.delete(0, "end")
px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:12]
app.t_px.delete("1.0", "end")
app.t_px.insert("1.0", "\n".join(px))
app.v_dry.set(True)
app.v_vis.set(False)
app._start()

fin = time.time() + 75
while time.time() < fin and app.running and app.stats["ok"] < 12:
    root.update()
    time.sleep(0.3)
app._stop()
fin2 = time.time() + 40
while time.time() < fin2 and app.running:
    root.update()
    time.sleep(0.3)
print("STATS", app.stats, "debit", len(app.envois))
j = app.journal.get("1.0", "end")
print("lignes journal", len(j.splitlines()), "OK", j.count(" OK "), "KO", j.count(" KO "))
print(j[:1500])
print("...")
print(j[-1500:])
