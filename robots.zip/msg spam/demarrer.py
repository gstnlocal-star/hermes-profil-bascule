# -*- coding: utf-8 -*-
"""Lance l'interface LSA plomberie, demarre la saturation, et veille sur le moteur.

Si le moteur ne produit plus rien pendant plus de 3 minutes alors qu'il tourne,
le processus se termine et le .bat le relance : l'etat est repris sur disque.
"""
import os
import faulthandler
faulthandler.enable(open('debug_fatal2.txt','w'))
import threading
import time
import tkinter as tk

import lsa_plomberie_v3 as S

IMMOBILE = 1200
PAR_LOCAL = 1
root = tk.Tk()
app = S.App(root)


def chien():
    dernier = -1
    fige = 0
    while True:
        time.sleep(15)
        ok = app.stats.get("ok", 0)
        if app.running and ok == dernier:
            fige += 15
            if fige >= IMMOBILE:
                try:
                    app._log("Chien de garde : moteur fige, redemarrage")
                    app.etat.sauve()
                except Exception:
                    pass
                os._exit(3)
        else:
            fige = 0
        dernier = ok


threading.Thread(target=chien, daemon=True).start()
def verif_proxies():
    """Si le fournisseur ne repond plus (expiration, 402), bascule en IP locale."""
    lignes = [l.strip() for l in app.t_px.get("1.0", "end").splitlines() if l.strip()]
    if not lignes:
        app.v_sanspx.set(True)
        app.e_par.delete(0, "end")
        app.e_par.insert(0, str(PAR_LOCAL))
        return
    p = app.__class__.__module__
    from lsa_plomberie_v3 import normalise_proxy
    try:
        import requests
        px = normalise_proxy(lignes[0])
        r = requests.get("http://example.com", proxies={"http": px, "https": px}, timeout=12)
        if r.status_code != 200:
            app.v_sanspx.set(True)
            app.e_par.delete(0, "end")
            app.e_par.insert(0, str(PAR_LOCAL))
            app._log(f"Proxies indisponibles (HTTP {r.status_code}) : passage en IP locale, 20 en parallele")
    except Exception:
        app.v_sanspx.set(True)
        app.e_par.delete(0, "end")
        app.e_par.insert(0, str(PAR_LOCAL))
        app._log("Proxies injoignables : passage en IP locale, 20 en parallele")


verif_proxies()
root.after(1500, app._start)
root.mainloop()
