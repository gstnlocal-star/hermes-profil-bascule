# -*- coding: utf-8 -*-
"""Apres le clic Envoyer : y a-t-il vraiment un bandeau de confirmation ?"""
import asyncio, re
from playwright.async_api import async_playwright
import lsa_plomberie_v3 as L

URL = "https://www.google.fr/search?q=plombier+la+roche-sur-yon&hl=fr&gl=fr"


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][430:436]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for l in px:
            p = L.normalise_proxy(l)
            ua, w, h, dpr = L.APPAREILS[0]
            c = await nav.new_context(proxy=L.pw_proxy(p), user_agent=ua, locale="fr-FR",
                                      viewport={"width": w, "height": h}, device_scale_factor=dpr,
                                      is_mobile=True, has_touch=True)
            await c.add_init_script(L.HIDE); await c.add_cookies(L.CONSENT_COOKIES)
            g = await c.new_page()
            await g.goto(URL, wait_until="domcontentloaded", timeout=40000)
            await g.wait_for_timeout(2500); await g.mouse.wheel(0, 450); await g.wait_for_timeout(700)
            a = await g.evaluate(L.JS_ANNONCES)
            ann = next((x for x in a if "cp2s" in L.sigle(x["nom"])), None) or (a[0] if a else None)
            if not ann:
                await c.close(); continue
            print("cible:", ann["nom"])
            f = await c.new_page()
            await f.goto("https://www.google.fr" + ann["href"], wait_until="domcontentloaded", timeout=40000)
            await f.wait_for_timeout(1200)
            ident = L.identite(); msg = L.texte_message(ident["prenom"], ident["nom"], "La Roche-sur-Yon", set())
            await L.remplir(f, ident, msg, False)
            await f.wait_for_timeout(400)
            b = f.get_by_role("button", name=re.compile(r"^Envoyer$", re.I))
            await b.first.click(timeout=8000)
            for att in (2500, 4000, 6000):
                await f.wait_for_timeout(att)
                t = await f.inner_text("body")
                bas = L.sans_accents(t).lower()
                print(f"  +{att} bandeau={'message a ete envoye' in bas}"
                      f" envoyees_pied={'envoyees' in bas} textarea_existe={await f.locator('textarea').count()}")
            await f.screenshot(path="debug/preuve2.png", full_page=False)
            print("  HAUT:", (await f.inner_text("body"))[:90].replace("\n", " | "))
            await c.close(); break
        await nav.close()

asyncio.run(main())
