# -*- coding: utf-8 -*-
"""Test a blanc du moteur : detection des annonces + ouverture du formulaire, sans envoi."""
import asyncio, sys
from playwright.async_api import async_playwright
import lsa_mobile as L

MOT = sys.argv[1] if len(sys.argv) > 1 else "chauffagiste lyon"
NB = int(sys.argv[2]) if len(sys.argv) > 2 else 2


async def main():
    px = [l.strip() for l in open("proxies_fr.txt", encoding="utf-8") if l.strip()][:NB]
    async with async_playwright() as pw:
        nav = await pw.chromium.launch(headless=True, args=L.ARGS)
        for n, p in enumerate(px):
            proxy = L.normalise_proxy(p)
            ua, w, h, dpr, _ = L.APPAREILS[n % len(L.APPAREILS)]
            ctx = await nav.new_context(proxy=L.pw_proxy(proxy), user_agent=ua, locale="fr-FR",
                                        timezone_id="Europe/Paris", viewport={"width": w, "height": h},
                                        device_scale_factor=dpr, is_mobile=True, has_touch=True)
            await ctx.add_init_script(L.HIDE)
            await ctx.add_cookies(L.CONSENT_COOKIES)
            page = await ctx.new_page()
            await page.goto("https://www.google.fr/search?q=" + MOT.replace(" ", "+") + "&hl=fr&gl=fr",
                            wait_until="domcontentloaded", timeout=45000)
            await page.wait_for_timeout(4500)
            await page.mouse.wheel(0, 500)
            await page.wait_for_timeout(1200)
            ip = await page.evaluate("() => fetch('https://api.ipify.org').then(r=>r.text()).catch(()=>'?')")
            ann = await page.evaluate(L.JS_ANNONCES)
            print(f"[{n+1}] ip={ip} annonces={len(ann)}")
            for a in ann[:5]:
                print("   -", a["nom"][:50])
            if ann:
                try:
                    await page.locator('[data-lsa="0"]').first.click(timeout=8000)
                    cible = await L.page_formulaire(page.context, 15)
                    if cible:
                        ident = L.identite()
                        n_champs = await L.remplir(cible, ident, L.texte_message(ident["prenom"], ident["nom"], "lyon"))
                        print("   formulaire OK, champs remplis:", n_champs, "| url:", cible.url[:70])
                        await cible.screenshot(path=f"debug/form_{n}.png")
                    else:
                        print("   formulaire introuvable")
                        await page.screenshot(path=f"debug/nof_{n}.png")
                except Exception as e:
                    print("   clic KO:", repr(e)[:80])
            await ctx.close()
        await nav.close()

asyncio.run(main())
