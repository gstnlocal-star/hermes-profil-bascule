# -*- coding: utf-8 -*-
"""Briques partagees entre l'interface et le moteur."""
import base64
import csv
import http.client
import json
import random
import socket
import string
import threading
import time
import unicodedata
from pathlib import Path
from urllib.parse import urlparse

BASE = Path(__file__).resolve().parent
COMMUNES = BASE / "communes.csv"
ETAT = BASE / "etat.json"
CFG = BASE / "config.json"
STOP = BASE / "stop.flag"

PROXY_DEFAUT = {
    "hote": "premium.proxya.co:8888",
    "user": "pkg-private2-country-FR-session-{s}-ttl-10",
    "pass": "iz4pqn5gh1ryda3o",
}
PROXY_HOTE = PROXY_DEFAUT["hote"]
PROXY_USER = PROXY_DEFAUT["user"]
PROXY_PASS = PROXY_DEFAUT["pass"]

TIMEOUT = 45000
UA_LISTE = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
]
ECRANS = [(1366, 768), (1440, 900), (1536, 864), (1600, 900), (1920, 1080)]

HIDE = "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"

COOKIES = [
    {"name": "CONSENT", "value": "YES+cb.20240101-00-p0.fr+FX+410", "domain": ".google.fr", "path": "/"},
    {"name": "SOCS", "value": "CAESHAgBEhJnd3NfMjAyNDAxMDEtMF9SQzIaAmZyIAEaBgiA_LyaBg",
     "domain": ".google.fr", "path": "/"},
]

JS_ANNONCES = r"""() => {
  document.querySelectorAll('[data-bot]').forEach(e => e.removeAttribute('data-bot'));
  document.querySelectorAll('[data-botcard]').forEach(e => e.removeAttribute('data-botcard'));
  const out = [];
  document.querySelectorAll('#tads a[data-rw], #tadsb a[data-rw], #tads a[href^="/goto"], #tadsb a[href^="/goto"]')
    .forEach(a => {
      let carte = a, dom = '', prof = 0;
      while (carte && prof < 12) {
        if (carte.hasAttribute('data-botcard')) return;
        const d = carte.querySelector('[data-dtld]');
        if (d) { dom = d.dataset.dtld || ''; carte.setAttribute('data-botcard', '1'); break; }
        carte = carte.parentElement; prof++;
      }
      if (!dom) {
        const m = (a.getAttribute('data-rw') || a.getAttribute('href') || '').match(/[?&]adurl=([^&]+)/);
        if (m) { try { dom = new URL(decodeURIComponent(m[1])).hostname; } catch (e) {} }
      }
      const h = carte ? carte.querySelector('[role="heading"]') : null;
      a.setAttribute('data-bot', out.length);
      out.push({ i: out.length, dom: dom.replace(/^www\./, ''), titre: (h ? h.innerText : '').slice(0, 90) });
    });
  const t = document.body.innerText || '';
  return { ads: out, captcha: /trafic exceptionnel|unusual traffic/i.test(t),
           vide: !document.querySelector('#tads, #tadsb'), url: location.href };
}"""


def sans_accents(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def uule(ville):
    n = ville.encode()
    return "w+" + base64.b64encode(b"\x08\x02\x10\x02\x08" + bytes([len(n)]) + n).decode().rstrip("=")


_IPS = {"liste": [], "quand": 0.0, "hote": ""}
_ip_lock = threading.Lock()


SANS_PROXY = False


def proxy_cfg():
    """Bloc "proxy" de config.json, replie sur le fournisseur par defaut."""
    try:
        if CFG.exists():
            p = json.loads(CFG.read_text(encoding="utf-8")).get("proxy") or {}
            if p.get("hote") and p.get("user"):
                return {"hote": p["hote"], "user": p["user"], "pass": p.get("pass", "")}
    except Exception:
        pass
    return dict(PROXY_DEFAUT)


def _decoupe(hote):
    h, _, port = hote.partition(":")
    return h, int(port or 8888)


def _teste(ip, port, delai=3):
    try:
        c = socket.create_connection((ip, port), timeout=delai)
        c.close()
        return True
    except Exception:
        return False


def ip_proxy(hote=None):
    """Chrome pend sur le hostname et certaines IP du gateway sont mortes : on ne garde que les joignables."""
    nom, port = _decoupe(hote or proxy_cfg()["hote"])
    with _ip_lock:
        if _IPS["hote"] == nom and _IPS["liste"] and time.time() - _IPS["quand"] < 600:
            return random.choice(_IPS["liste"])
        candidates = set()
        for _ in range(8):
            try:
                candidates.add(socket.gethostbyname(nom))
            except Exception:
                pass
        bonnes = [ip for ip in candidates if _teste(ip, port)] or [socket.gethostbyname(nom)]
        _IPS["liste"], _IPS["quand"], _IPS["hote"] = bonnes, time.time(), nom
        return random.choice(bonnes)


def _connect(ip, port, cible="www.google.fr", delai=12):
    """Ouvre un tunnel CONNECT et renvoie le code de reponse du proxy (200, 402, 407...)."""
    cfg = proxy_cfg()
    try:
        c = socket.create_connection((ip, port), timeout=delai)
    except Exception:
        return 0
    try:
        c.settimeout(delai)
        ident = cfg["user"].replace("{s}", "test0000")
        auth = base64.b64encode(f"{ident}:{cfg['pass']}".encode()).decode()
        fin = chr(13) + chr(10)
        trame = (f"CONNECT {cible}:443 HTTP/1.1{fin}Host: {cible}:443{fin}"
                 f"Proxy-Authorization: Basic {auth}{fin}{fin}")
        c.sendall(trame.encode())
        rep = c.recv(200).decode("latin-1", "replace")
        morceau = rep.split(" ")[1].strip() if " " in rep else ""
        return int(morceau) if morceau.isdigit() else 0
    except Exception:
        return 0
    finally:
        try:
            c.close()
        except Exception:
            pass


def preflight():
    """Controle le fournisseur avant de lancer un run.
    Renvoie (etat, detail), etat parmi ok / credit / auth / mort."""
    nom, port = _decoupe(proxy_cfg()["hote"])
    codes = []
    for _ in range(6):
        try:
            ip = random.choice(socket.getaddrinfo(nom, port, type=socket.SOCK_STREAM))[4][0]
        except Exception:
            continue
        codes.append(_connect(ip, port))
        if codes[-1] in (200, 402, 407):
            break
    if 402 in codes:
        return "credit", "credit du fournisseur epuise (402 Payment Required)"
    if 407 in codes:
        return "auth", "identifiants proxies refuses (407)"
    if 200 in codes:
        return "ok", f"{nom}:{port}"
    return "mort", f"aucun tunnel possible vers {nom}:{port}"


def proxys(n=1):
    """Une session neuve par visite : le gabarit d'identifiant recoit {s}."""
    if SANS_PROXY:
        return [None] * n
    cfg = proxy_cfg()
    nom, port = _decoupe(cfg["hote"])
    ip = None
    for _ in range(3):
        essai = ip_proxy(cfg["hote"])
        if _teste(essai, port):
            ip = essai
            break
    ip = ip or ip_proxy(cfg["hote"])
    out = []
    for _ in range(n):
        s = "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
        out.append({"server": f"http://{ip}:{port}",
                    "username": cfg["user"].replace("{s}", s), "password": cfg["pass"]})
    return out


def test_sortie():
    """Requete de controle via une session proxy : renvoie (ok, texte lisible)."""
    conn = None
    try:
        p = proxys(1)[0]
        hote, port = _decoupe(p["server"].split("//")[1])
        conn = http.client.HTTPConnection(hote, port, timeout=25)
        jeton = base64.b64encode(f"{p['username']}:{p['password']}".encode()).decode()
        conn.set_tunnel("ip-api.com", 80, headers={"Proxy-Authorization": f"Basic {jeton}"})
        conn.request("GET", "/json/?fields=query,country,isp", headers={"Host": "ip-api.com"})
        rep = conn.getresponse()
        d = json.loads(rep.read().decode("utf-8", "replace") or "{}")
        return True, f"{d.get('query', '?')} | {d.get('country', '?')} | {d.get('isp', '?')}"
    except Exception as e:
        return False, repr(e)[:90]
    finally:
        try:
            conn.close()
        except Exception:
            pass


def host(url):
    try:
        return (urlparse(url).hostname or "").replace("www.", "").lower()
    except Exception:
        return ""


def exclu(dom, titre, exclus, mots):
    d = (dom or "").lower()
    t = sans_accents((titre or "").lower())
    return any(x in d for x in exclus) or any(sans_accents(m) in t for m in mots)


class Etat:
    """Avancement par ville, concurrents touches, villes steriles."""

    def __init__(self):
        self.lock = threading.Lock()
        self.d = {"villes": {}, "exclus": [], "stats": {"ok": 0, "ko": 0, "vus": 0},
                  "concurrents": {}, "steriles": {}}
        self.charge()

    def charge(self):
        try:
            if ETAT.exists():
                self.d.update(json.loads(ETAT.read_text(encoding="utf-8")))
        except Exception:
            pass

    def sauve(self):
        try:
            ETAT.write_text(json.dumps(self.d, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def faits(self, cle):
        with self.lock:
            return self.d["villes"].get(cle, 0)

    def plus(self, cle, concurrent=None, ok=True):
        with self.lock:
            self.d["villes"][cle] = self.d["villes"].get(cle, 0) + 1
            self.d["stats"]["vus"] += 1
            self.d["stats"]["ok" if ok else "ko"] += 1
            if concurrent and ok:
                self.d["concurrents"][concurrent] = self.d["concurrents"].get(concurrent, 0) + 1

    def sterile(self, cle):
        with self.lock:
            self.d["steriles"][cle] = self.d["steriles"].get(cle, 0) + 1

    def debloque(self, cle):
        with self.lock:
            self.d["steriles"].pop(cle, None)
