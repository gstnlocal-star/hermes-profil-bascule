#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Moteur du cliqueur Ads : tourne seul, pilote par config.json, journal sur stdout.

Une visite = un proxy residentiel FR neuf + un profil vierge + une recherche localisee
par uule, puis clic sur une annonce non exclue et lecture du site du concurrent.
"""
import asyncio
import csv
import json
import random
import sys
import time
from collections import deque
from datetime import datetime

import commun as C
from playwright.async_api import async_playwright


SANS_PROXY_PAR = 2


class Moteur:
    def __init__(self, cfg):
        self.cfg = cfg
        self.etat = C.Etat()
        self.csv = C.BASE / cfg["csv"]
        self.logf = C.BASE / cfg["log"]
        self.stop = False
        self.mort = False
        self.reseau_ko = 0
        self.capt = 0
        self.gate_until = 0.0

    # ---------------------------------------------------------------- sortie
    def log(self, m):
        try:
            with open(self.logf, "a", encoding="utf-8") as fh:
                fh.write(m + chr(10))
        except Exception:
            pass

    def ligne(self, statut, dep, ville, dom, url, duree, motif, titre=""):
        try:
            with open(self.csv, "a", newline="", encoding="utf-8-sig") as fh:
                csv.writer(fh, delimiter=";").writerow(
                    [datetime.now().strftime("%Y-%m-%d %H:%M:%S"), statut, dep, ville,
                     self.cfg["mot"], dom, url, duree, motif, titre])
        except Exception:
            pass

    # ---------------------------------------------------------------- taches
    def construire(self, bonus=0):
        villes = {}
        with open(C.COMMUNES, encoding="utf-8") as fh:
            for r in csv.DictReader(fh, delimiter=";"):
                if r["departement"] in self.cfg["deps"]:
                    villes.setdefault(r["departement"], []).append((int(r["population"] or 0), r["ville"]))
        taches = []
        cible = self.cfg["cible"] + bonus
        for dep in self.cfg["deps"]:
            for _, ville in sorted(villes.get(dep, []), reverse=True)[: self.cfg["vmax"]]:
                cle = f"{dep}|{ville}"
                if self.etat.d["steriles"].get(cle, 0) >= 2:
                    continue
                taches += [(dep, ville, cle)] * max(0, cible - self.etat.faits(cle))
        random.shuffle(taches)
        return taches

    # ---------------------------------------------------------------- visite
    async def contexte(self, nav, proxy):
        w, h = random.choice(C.ECRANS)
        ctx = await nav.new_context(proxy=proxy, user_agent=random.choice(C.UA_LISTE), locale="fr-FR",
                                    timezone_id="Europe/Paris",
                                    viewport={"width": w, "height": h - random.randint(60, 120)})
        await ctx.add_init_script(C.HIDE)
        await ctx.add_cookies(C.COOKIES)
        return ctx

    async def visite(self, nav, dep, ville, cle):
        if self.stop or self.mort:
            return
        debut = time.time()
        dom, titre, motif, statut, finale = "", "", "", "echec", ""
        for essai in range(1 if C.SANS_PROXY else 3):
            if self.stop or self.mort:
                break
            ctx = None
            proxy = C.proxys(1)[0]
            try:
                ctx = await self.contexte(nav, proxy)
                page = await ctx.new_page()
                page.set_default_timeout(C.TIMEOUT)
                url = (f"https://www.google.fr/search?q={self.cfg['mot'].replace(' ', '+')}+"
                       f"{ville.replace(' ', '+')}&hl=fr&gl=fr&uule={C.uule(ville)}")
                await page.goto(url, wait_until="domcontentloaded", timeout=20000)
                try:
                    await page.wait_for_selector("#tads, #tadsb", timeout=random.randint(2500, 4500))
                except Exception:
                    pass
                await page.wait_for_timeout(random.randint(900, 1800))
                r = await page.evaluate(C.JS_ANNONCES)
                if r["captcha"] and essai == 0:  # un reload passe souvent le captcha
                    await page.reload(wait_until="domcontentloaded", timeout=20000)
                    await page.wait_for_timeout(random.randint(1500, 2600))
                    r = await page.evaluate(C.JS_ANNONCES)
                if r["captcha"] or not r["ads"]:
                    motif = "captcha" if r["captcha"] else "aucune annonce"
                    await ctx.close()
                    await asyncio.sleep(random.uniform(2, 5))
                    continue
                libres = [a for a in r["ads"] if not C.exclu(a["dom"], a["titre"], self.cfg["exclus"], self.cfg["mots"])]
                if not libres:
                    statut, motif = "exclu", "que des exclus"
                    break
                poids = [5.0 if k == 0 else 3.0 if k == 1 else 2.0 if k == 2 else 1.0 for k in range(len(libres))]
                choix = random.choices(libres, weights=poids, k=1)[0]
                dom, titre = choix["dom"], choix["titre"]
                el = page.locator(f'[data-bot="{choix["i"]}"]').first
                box = await el.bounding_box()
                if box:
                    await page.mouse.move(box["x"] + random.uniform(5, max(6, box["width"] - 5)),
                                          box["y"] + random.uniform(3, max(4, box["height"] - 3)),
                                          steps=random.randint(8, 20))
                    await page.wait_for_timeout(random.randint(200, 700))
                avant = set(ctx.pages)
                try:
                    async with page.expect_navigation(wait_until="domcontentloaded", timeout=C.TIMEOUT):
                        await el.click()
                except Exception:
                    pass
                await page.wait_for_timeout(random.randint(1200, 2200))
                neuves = [x for x in ctx.pages if x not in avant and x is not page]
                page = neuves[-1] if neuves else page
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=15000)
                except Exception:
                    pass
                finale = page.url
                if "google." in C.host(finale) or "sorry" in finale:
                    statut, motif = "echec", "pas de sortie"
                    await ctx.close()
                    self.reseau_ko += 1
                    continue
                dom = C.host(finale) or dom
                if C.exclu(dom, "", self.cfg["exclus"], self.cfg["mots"]):
                    statut, motif = "exclu", f"redirige vers {dom}"
                    await ctx.close()
                    break
                fin = time.time() + random.uniform(self.cfg["vmin"], max(self.cfg["vmin"], self.cfg["vmax2"]))
                while time.time() < fin and not self.stop:
                    await page.mouse.wheel(0, random.randint(200, 700))
                    await page.wait_for_timeout(random.randint(1500, 4500))
                    if random.random() < 0.45:
                        liens = await page.evaluate(
                            """() => [...document.querySelectorAll('a[href]')]
                                 .filter(a => a.hostname === location.hostname && a.href.length < 160)
                                 .map(a => a.href).slice(0, 8)""")
                        if liens:
                            try:
                                await page.goto(random.choice(liens), wait_until="domcontentloaded", timeout=20000)
                            except Exception:
                                pass
                            await page.wait_for_timeout(random.randint(2000, 5000))
                statut, motif = "clic", ""
                await ctx.close()
                break
            except Exception as e:
                statut, motif = "echec", repr(e)[:70]
                self.reseau_ko += 1
                if ctx:
                    try:
                        await ctx.close()
                    except Exception:
                        pass
        duree = round(time.time() - debut, 1)
        ok = statut == "clic"
        if ok or statut == "exclu":
            self.reseau_ko = 0
        elif self.reseau_ko >= 12 and not self.mort:
            self.mort = True
            self.log(f"ARRET : {self.reseau_ko} echecs reseau consecutifs, proxies muets ou credit epuise")
        if motif == "captcha":
            self.capt += 1
            if self.capt >= 2:
                att = float(min(180 * self.capt, 600))
                self.gate_until = time.monotonic() + att
                self.log(f"captcha x{self.capt} : pause {int(att)}s")
                self.capt = 0
        elif ok:
            self.capt = 0
        self.etat.plus(cle, dom if ok else None, ok)
        if motif == "aucune annonce":
            self.etat.sterile(cle)
        elif ok:
            self.etat.debloque(cle)
        self.etat.sauve()
        self.ligne(statut, dep, ville, dom, finale, duree, motif, titre)
        self.log(f"{'OK ' if ok else '-- '}{dep} {ville} -> {dom or '(rien)'} {duree}s {motif}")

    # ---------------------------------------------------------------- boucle
    async def run(self):
        async with async_playwright() as p:
            nav = await p.chromium.launch(headless=not self.cfg["visible"],
                                          args=["--disable-blink-features=AutomationControlled",
                                                "--disable-quic", "--disable-http2",
                                                "--disable-dev-shm-usage"])

            async def worker(q):
                while not self.stop and not self.mort:
                    try:
                        dep, ville, cle = q.popleft()
                    except IndexError:
                        return
                    while self.gate_until > time.monotonic() and not self.stop:
                        await asyncio.sleep(2)
                    await self.visite(nav, dep, ville, cle)
                    await asyncio.sleep(random.uniform(0.5, 2.5))

            q = deque(self.construire())
            self.log(f"Demarrage : {len(q)} visites planifiees, {self.cfg['par']} en parallele")
            await asyncio.gather(*[worker(q) for _ in range(self.cfg["par"])])
            t0 = time.time()
            duree = float(self.cfg.get("duree_h", 0) or 0)
            bonus = 0
            while self.cfg["boucle"] and not self.stop and not self.mort:
                if duree and time.time() - t0 >= duree * 3600:
                    self.log(f"Duree de {duree:g} h atteinte : arret")
                    break
                reste = self.construire(bonus)
                if not reste:
                    if duree and self.cfg["cible"] + bonus < 60:
                        bonus += 5
                        self.log(f"Cibles atteintes, relance dans 120 s a {self.cfg['cible'] + bonus} clics par ville")
                        await asyncio.sleep(120)
                        continue
                    self.log("Toutes les cibles sont atteintes")
                    break
                if bonus:
                    self.log(f"Nouveau tour : {len(reste)} visites (objectif {self.cfg['cible'] + bonus} par ville)")
                else:
                    self.log(f"Nouveau tour : {len(reste)} visites")
                q = deque(reste)
                await asyncio.gather(*[worker(q) for _ in range(self.cfg["par"])])
            await nav.close()
        self.log("Moteur arrete")


def main():
    cfg = json.loads(C.CFG.read_text(encoding="utf-8"))
    if C.STOP.exists():
        C.STOP.unlink()
    m = Moteur(cfg)
    etat_proxy, detail = C.preflight()
    m.log(f"Controle des proxies : {etat_proxy} ({detail})")
    if etat_proxy != "ok":
        C.SANS_PROXY = True
        m.log(f"Proxies indisponibles ({detail}) : passage en IP locale, {SANS_PROXY_PAR} en parallele")
        cfg["par"] = max(1, min(int(cfg.get("par", 1)), SANS_PROXY_PAR))
    with open(m.csv, "w", newline="", encoding="utf-8-sig") as fh:
        csv.writer(fh, delimiter=";").writerow(
            ["horodatage", "statut", "dep", "ville", "mot", "domaine", "url", "secondes", "motif", "titre"])

    async def surveille():
        while True:
            await asyncio.sleep(1.5)
            if C.STOP.exists():
                m.stop = True
                m.log("Stop demande")

    async def go():
        t = asyncio.create_task(surveille())
        try:
            await m.run()
        finally:
            t.cancel()

    try:
        asyncio.run(go())
    except Exception as e:
        m.log(f"ARRET : {repr(e)[:160]}")
        sys.exit(1)


if __name__ == "__main__":
    main()
