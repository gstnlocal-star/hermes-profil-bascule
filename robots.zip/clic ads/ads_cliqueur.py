#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ads_cliqueur.py - interface du cliqueur Google Ads.

L'interface ne clique pas elle-meme : elle ecrit config.json et lance moteur.py
dans un processus separe (tkinter et Playwright se genent dans le meme processus).
"""
import json
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import ttk

import commun as C

BASE = Path(__file__).resolve().parent

DEPTS = {
    "01": "Ain", "02": "Aisne", "03": "Allier", "04": "Alpes-de-Haute-Provence", "05": "Hautes-Alpes",
    "06": "Alpes-Maritimes", "07": "Ardeche", "08": "Ardennes", "09": "Ariege", "10": "Aube",
    "11": "Aude", "12": "Aveyron", "13": "Bouches-du-Rhone", "14": "Calvados", "15": "Cantal",
    "16": "Charente", "17": "Charente-Maritime", "18": "Cher", "19": "Correze", "2A": "Corse-du-Sud",
    "2B": "Haute-Corse", "20": "Corse", "21": "Cote-d'Or", "22": "Cotes-d'Armor", "23": "Creuse",
    "24": "Dordogne", "25": "Doubs", "26": "Drome", "27": "Eure", "28": "Eure-et-Loir",
    "29": "Finistere", "30": "Gard", "31": "Haute-Garonne", "32": "Gers", "33": "Gironde",
    "34": "Herault", "35": "Ille-et-Vilaine", "36": "Indre", "37": "Indre-et-Loire", "38": "Isere",
    "39": "Jura", "40": "Landes", "41": "Loir-et-Cher", "42": "Loire", "43": "Haute-Loire",
    "44": "Loire-Atlantique", "45": "Loiret", "46": "Lot", "47": "Lot-et-Garonne", "48": "Lozere",
    "49": "Maine-et-Loire", "50": "Manche", "51": "Marne", "52": "Haute-Marne", "53": "Mayenne",
    "54": "Meurthe-et-Moselle", "55": "Meuse", "56": "Morbihan", "57": "Moselle", "58": "Nievre",
    "59": "Nord", "60": "Oise", "61": "Orne", "62": "Pas-de-Calais", "63": "Puy-de-Dome",
    "64": "Pyrenees-Atlantiques", "65": "Hautes-Pyrenees", "66": "Pyrenees-Orientales", "67": "Bas-Rhin",
    "68": "Haut-Rhin", "69": "Rhone", "70": "Haute-Saone", "71": "Saone-et-Loire", "72": "Sarthe",
    "73": "Savoie", "74": "Haute-Savoie", "75": "Paris", "76": "Seine-Maritime", "77": "Seine-et-Marne",
    "78": "Yvelines", "79": "Deux-Sevres", "80": "Somme", "81": "Tarn", "82": "Tarn-et-Garonne",
    "83": "Var", "84": "Vaucluse", "85": "Vendee", "86": "Vienne", "87": "Haute-Vienne",
    "88": "Vosges", "89": "Yonne", "90": "Territoire de Belfort", "91": "Essonne",
    "92": "Hauts-de-Seine", "93": "Seine-Saint-Denis", "94": "Val-de-Marne", "95": "Val-d'Oise",
    "971": "Guadeloupe", "972": "Martinique", "973": "Guyane", "974": "La Reunion", "976": "Mayotte",
}

MOT_CLE = "serrurier"
DEPTS_DEFAUT = "14;27;29;35;44;54;56;57;59;62;76;85"
MOTS_DEFAUT = """fibre & power
fibre and power
articompagnons
artisans compagnons"""
PARALLELE = 5
CIBLE = 8
VISITE_MIN = 25
VISITE_MAX = 80
VILLES_MAX = 20


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Cliqueur Google Ads - saturation concurrents")
        self.root.geometry("1120x760")
        self.etat = C.Etat()
        self.q = queue.Queue()
        self.proc = None
        self.running = False
        self.stats = {"ok": 0, "ko": 0, "vus": 0}
        self.csv = None
        self._build()
        self._prefill()
        self.root.after(400, self._drain)

    # ---------------------------------------------------------------- interface
    def _build(self):
        nb = ttk.Notebook(self.root)
        nb.pack(fill="both", expand=True, padx=8, pady=6)
        self._onglet_ciblage(nb)
        self._onglet_exclusions(nb)
        self._onglet_proxies(nb)
        self._onglet_reglages(nb)
        self._onglet_suivi(nb)
        bas = ttk.Frame(self.root)
        bas.pack(fill="x", padx=8, pady=(0, 8))
        self.b_start = ttk.Button(bas, text="DEMARRER", command=self._start)
        self.b_start.pack(side="left")
        self.b_stop = ttk.Button(bas, text="STOP", command=self._stop, state="disabled")
        self.b_stop.pack(side="left", padx=8)
        self.l_etat = ttk.Label(bas, text="arrete")
        self.l_etat.pack(side="left", padx=16)
        self.l_stats = ttk.Label(bas, text="0 clic | 0 echec | 0 essai")
        self.l_stats.pack(side="right")

    def _onglet_ciblage(self, nb):
        f = ttk.Frame(nb)
        nb.add(f, text="Ciblage")
        haut = ttk.Frame(f)
        haut.pack(fill="x", padx=10, pady=8)
        ttk.Label(haut, text="Mot-cle :").pack(side="left")
        self.v_mot = tk.StringVar(value=MOT_CLE)
        ttk.Entry(haut, textvariable=self.v_mot, width=22).pack(side="left", padx=6)
        ttk.Label(haut, text="Clics par ville :").pack(side="left", padx=(20, 4))
        self.v_cible = tk.StringVar(value=str(CIBLE))
        ttk.Spinbox(haut, from_=1, to=500, textvariable=self.v_cible, width=6).pack(side="left")
        ttk.Label(haut, text="Villes par departement :").pack(side="left", padx=(20, 4))
        self.v_vmax = tk.StringVar(value=str(VILLES_MAX))
        ttk.Spinbox(haut, from_=1, to=200, textvariable=self.v_vmax, width=6).pack(side="left")
        ttk.Button(haut, text="Tout cocher", command=lambda: self._cocher(True)).pack(side="left", padx=(24, 4))
        ttk.Button(haut, text="Tout decocher", command=lambda: self._cocher(False)).pack(side="left")

        corps = ttk.Frame(f)
        corps.pack(fill="both", expand=True, padx=10, pady=(0, 8))
        can = tk.Canvas(corps, highlightthickness=0)
        sb = ttk.Scrollbar(corps, orient="vertical", command=can.yview)
        can.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        can.pack(side="left", fill="both", expand=True)
        grille = ttk.Frame(can)
        can.create_window((0, 0), window=grille, anchor="nw")
        grille.bind("<Configure>", lambda e: can.configure(scrollregion=can.bbox("all")))
        self.dep_cases = {}
        for i, (code, nom) in enumerate(DEPTS.items()):
            v = tk.BooleanVar(value=False)
            ttk.Checkbutton(grille, text=f"{code} {nom}", variable=v).grid(
                row=i // 8, column=i % 8, sticky="w", padx=3, pady=1)
            self.dep_cases[code] = v

    def _onglet_exclusions(self, nb):
        f = ttk.Frame(nb)
        nb.add(f, text="Mes sites / exclusions")
        ttk.Label(f, text="Un domaine par ligne : le robot ne cliquera jamais dessus "
                          "(mes sites, partenaires, annuaires).").pack(anchor="w", padx=10, pady=(10, 4))
        self.t_excl = tk.Text(f, height=10, wrap="none")
        self.t_excl.pack(fill="x", padx=10)
        ttk.Label(f, text="Mots a exclure dans le titre ou le domaine (un par ligne) :").pack(
            anchor="w", padx=10, pady=(10, 4))
        self.t_mots = tk.Text(f, height=5, wrap="none")
        self.t_mots.insert("1.0", MOTS_DEFAUT)
        self.t_mots.pack(fill="x", padx=10)
        self.l_excl = ttk.Label(f, text="0 exclusion")
        self.l_excl.pack(anchor="w", padx=10, pady=6)
        ttk.Button(f, text="Compter", command=self._compter_excl).pack(anchor="w", padx=10)

    def _onglet_proxies(self, nb):
        f = ttk.Frame(nb)
        nb.add(f, text="Proxies")
        ttk.Label(f, justify="left",
                  text="Passerelle et identifiants du fournisseur residentiel.\n"
                       "Le gabarit d'identifiant recoit {s}, remplace par une session neuve a chaque visite.").pack(
            anchor="w", padx=10, pady=(10, 6))
        g = ttk.Frame(f)
        g.pack(anchor="w", padx=10)
        self.v_hote = tk.StringVar(value=C.PROXY_DEFAUT["hote"])
        self.v_user = tk.StringVar(value=C.PROXY_DEFAUT["user"])
        self.v_proxpass = tk.StringVar(value=C.PROXY_DEFAUT["pass"])
        for i, (lib, var, large) in enumerate([("Passerelle (hote:port)", self.v_hote, 42),
                                               ("Identifiant", self.v_user, 58),
                                               ("Mot de passe", self.v_proxpass, 42)]):
            ttk.Label(g, text=lib).grid(row=i, column=0, sticky="w", pady=3)
            ttk.Entry(g, textvariable=var, width=large).grid(row=i, column=1, padx=8, pady=3, sticky="w")
        b = ttk.Frame(f)
        b.pack(anchor="w", padx=10, pady=10)
        ttk.Button(b, text="Enregistrer", command=self._sauve_proxy).pack(side="left")
        ttk.Button(b, text="Tester la sortie", command=self._tester_proxy).pack(side="left", padx=8)
        self.l_proxy = ttk.Label(f, text="non teste", wraplength=900, justify="left")
        self.l_proxy.pack(anchor="w", padx=10, pady=(2, 10))
        ttk.Label(f, justify="left", foreground="#555",
                  text="Gabarits connus :\n"
                       "Proxya : premium.proxya.co:8888 / pkg-private2-country-FR-session-{s}-ttl-10\n"
                       "DataImpulse : gw.dataimpulse.com:823 / LOGIN__cr.fr;sessid.{s}\n"
                       "QuanticData : identifiant du dashboard, suffixe -country-fr").pack(
            anchor="w", padx=10, pady=(14, 4))

    def _sauve_proxy(self):
        try:
            cfg = json.loads(C.CFG.read_text(encoding="utf-8")) if C.CFG.exists() else {}
        except Exception:
            cfg = {}
        cfg["proxy"] = {"hote": self.v_hote.get().strip(), "user": self.v_user.get().strip(),
                        "pass": self.v_proxpass.get()}
        C.CFG.write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
        self.l_proxy.configure(text="enregistre")
        return cfg["proxy"]

    def _tester_proxy(self):
        p = self._sauve_proxy()
        self.l_proxy.configure(text=f"test de {p['hote']} en cours...")

        def tache():
            etat, detail = C.preflight()
            if etat == "ok":
                ok, info = C.test_sortie()
                txt = f"OK, sortie {info}" if ok else f"tunnel accepte mais requete KO : {info}"
            elif etat == "credit":
                txt = "CREDIT EPUISE chez le fournisseur : recharger avant de lancer."
            elif etat == "auth":
                txt = "Identifiants refuses : verifier l'identifiant et le mot de passe."
            else:
                txt = f"Passerelle injoignable : {detail}"
            self.q.put(("proxy", txt))

        threading.Thread(target=tache, daemon=True).start()

    def _onglet_reglages(self, nb):
        f = ttk.Frame(nb)
        nb.add(f, text="Reglages")
        g = ttk.Frame(f)
        g.pack(anchor="w", padx=10, pady=10)
        self.v_par = tk.StringVar(value=str(PARALLELE))
        self.v_vmin = tk.StringVar(value=str(VISITE_MIN))
        self.v_vmax2 = tk.StringVar(value=str(VISITE_MAX))
        self.v_duree = tk.StringVar(value="24")
        for i, lib in enumerate(["Visites simultanees", "Duree de visite mini (s)", "Duree de visite maxi (s)",
                                 "Duree du run (h, 0 = sans limite)"]):
            ttk.Label(g, text=lib).grid(row=i, column=0, sticky="w", pady=3)
        ttk.Spinbox(g, from_=1, to=60, textvariable=self.v_par, width=6).grid(row=0, column=1, padx=8)
        ttk.Spinbox(g, from_=0, to=600, textvariable=self.v_vmin, width=6).grid(row=1, column=1, padx=8)
        ttk.Spinbox(g, from_=0, to=900, textvariable=self.v_vmax2, width=6).grid(row=2, column=1, padx=8)
        ttk.Spinbox(g, from_=0, to=240, textvariable=self.v_duree, width=6).grid(row=3, column=1, padx=8)
        self.v_visible = tk.BooleanVar(value=False)
        ttk.Checkbutton(g, text="Afficher le navigateur", variable=self.v_visible).grid(
            row=4, column=0, columnspan=2, sticky="w", pady=8)
        self.v_boucle = tk.BooleanVar(value=True)
        ttk.Checkbutton(g, text="Boucle infinie (relance les villes a la fin)", variable=self.v_boucle).grid(
            row=5, column=0, columnspan=2, sticky="w")
        ttk.Label(f, text=f"Proxies : {C.PROXY_HOTE} (session residentielle FR neuve a chaque visite)").pack(
            anchor="w", padx=10, pady=(16, 2))

    def _onglet_suivi(self, nb):
        f = ttk.Frame(nb)
        nb.add(f, text="Suivi")
        self.t_log = tk.Text(f, height=18, state="disabled", wrap="none")
        self.t_log.pack(fill="both", expand=True, padx=10, pady=8)
        bas = ttk.Frame(f)
        bas.pack(fill="x", padx=10, pady=(0, 8))
        ttk.Button(bas, text="Ouvrir le dossier", command=lambda: __import__("os").startfile(BASE)).pack(side="left")
        ttk.Button(bas, text="Raz compteurs", command=self._raz).pack(side="left", padx=8)
        self.l_conc = ttk.Label(f, text="")
        self.l_conc.pack(anchor="w", padx=10, pady=(0, 8))

    def _prefill(self):
        try:
            cfgd = json.loads(C.CFG.read_text(encoding="utf-8")).get("deps") or []
        except Exception:
            cfgd = []
        for c in (cfgd or DEPTS_DEFAUT.split(";")):
            if c.strip() in self.dep_cases:
                self.dep_cases[c.strip()].set(True)
        excl = [e for e in (self.etat.d.get("exclus") or []) if e]
        try:
            cfg0 = json.loads(C.CFG.read_text(encoding="utf-8"))
        except Exception:
            cfg0 = {}
        excl += [e for e in (cfg0.get("exclus") or []) if e and e not in excl]
        self.t_excl.insert("1.0", "\n".join(excl))
        try:
            cfg = json.loads(C.CFG.read_text(encoding="utf-8"))
        except Exception:
            cfg = {}
        try:
            p = cfg.get("proxy") or {}
            if p.get("hote"):
                self.v_hote.set(p["hote"])
                self.v_user.set(p.get("user", ""))
                self.v_proxpass.set(p.get("pass", ""))
        except Exception:
            pass
        for cle, var in (("mot", self.v_mot), ("cible", self.v_cible), ("vmax", self.v_vmax),
                         ("par", self.v_par), ("vmin", self.v_vmin), ("vmax2", self.v_vmax2),
                         ("duree_h", self.v_duree)):
            if cfg.get(cle) not in (None, ""):
                var.set(str(cfg[cle]))
        if isinstance(cfg.get("visible"), bool):
            self.v_visible.set(cfg["visible"])
        if isinstance(cfg.get("boucle"), bool):
            self.v_boucle.set(cfg["boucle"])
        self._compter_excl()

    def _compter_excl(self):
        self.l_excl.configure(text=f"{len(self._lignes(self.t_excl)) + len(self._lignes(self.t_mots))} exclusion(s)")

    def _cocher(self, val):
        for v in self.dep_cases.values():
            v.set(val)

    def _lignes(self, txt):
        return [l.strip().lower() for l in txt.get("1.0", "end").splitlines() if l.strip()]

    # ---------------------------------------------------------------- outils
    def _log(self, m):
        self.q.put(("log", m))

    def _drain(self):
        try:
            while True:
                typ, data = self.q.get_nowait()
                if typ == "log":
                    self.t_log.configure(state="normal")
                    self.t_log.insert("end", data + "\n")
                    self.t_log.see("end")
                    self.t_log.configure(state="disabled")
                elif typ == "stats":
                    self.l_stats.configure(text=f"{data['ok']} clics | {data['ko']} echec | {data['vus']} essai")
                elif typ == "conc":
                    self.l_conc.configure(text=data)
                elif typ == "proxy":
                    self.l_proxy.configure(text=data)
                elif typ == "fin":
                    self.running = False
                    self.b_start.configure(state="normal")
                    self.b_stop.configure(state="disabled")
                    if data:
                        self.l_etat.configure(text=data[:120], foreground="red")
                    else:
                        self.l_etat.configure(text="arrete", foreground="black")
        except queue.Empty:
            pass
        self.root.after(400, self._drain)

    def _raz(self):
        self.etat.d["villes"] = {}
        self.etat.d["steriles"] = {}
        self.etat.d["concurrents"] = {}
        self.etat.d["stats"] = {"ok": 0, "ko": 0, "vus": 0}
        self.etat.sauve()
        self._log("Compteurs remis a zero")

    # ---------------------------------------------------------------- pilotage
    def _start(self):
        if self.running:
            return
        deps = [c for c, v in self.dep_cases.items() if v.get()]
        if not deps:
            self._log("Coche au moins un departement.")
            return
        exclus = self._lignes(self.t_excl)
        self.etat.d["exclus"] = exclus
        self.etat.sauve()
        cfg = {"deps": deps, "mot": self.v_mot.get().strip() or MOT_CLE,
               "cible": max(1, int(self.v_cible.get())), "vmax": max(1, int(self.v_vmax.get())),
               "par": max(1, int(self.v_par.get())),
               "vmin": float(self.v_vmin.get()), "vmax2": float(self.v_vmax2.get()),
               "duree_h": float(self.v_duree.get() or 0),
               "visible": self.v_visible.get(), "boucle": self.v_boucle.get(),
               "exclus": exclus, "mots": self._lignes(self.t_mots),
               "proxy": {"hote": self.v_hote.get().strip(), "user": self.v_user.get().strip(),
                         "pass": self.v_proxpass.get()}}
        horo = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.csv = f"clics_{horo}.csv"
        self.logf = f"journal_{horo}.txt"
        cfg["csv"] = self.csv
        cfg["log"] = self.logf
        C.CFG.write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
        if C.STOP.exists():
            C.STOP.unlink()
        sortie = open(BASE / self.logf, "a", encoding="utf-8")
        self.proc = subprocess.Popen([sys.executable, str(BASE / "moteur.py")], cwd=str(BASE),
                                     stdout=sortie, stderr=subprocess.STDOUT)
        self.running = True
        self.stats = {"ok": 0, "ko": 0, "vus": 0}
        self.b_start.configure(state="disabled")
        self.b_stop.configure(state="normal")
        self.l_etat.configure(text="en cours")
        self._log(f"Demarrage sur {len(deps)} departement(s), "
                  f"{len(self._lignes(self.t_mots)) + len(exclus)} exclusion(s), fichier {self.csv}")
        threading.Thread(target=self._lire, daemon=True).start()
        threading.Thread(target=self._compter, daemon=True).start()

    def _lire(self):
        """Recopie le journal du moteur dans l'onglet Suivi."""
        f = BASE / self.logf
        vus = 0
        while self.running:
            time.sleep(1)
            try:
                lignes = f.read_text(encoding="utf-8", errors="replace").splitlines()
            except Exception:
                continue
            for l in lignes[vus:]:
                self.q.put(("log", l))
                if l.startswith("ARRET"):
                    self.q.put(("fin", l[8:].strip()))
                    return
                if l.startswith("Moteur arrete"):
                    self.q.put(("fin", None))
                    return
            vus = len(lignes)
            if self.proc.poll() is not None:
                self.q.put(("log", "Moteur termine"))
                self.q.put(("fin", None))
                return

    def _compter(self):
        """Suit le CSV de la session pour les compteurs et le top concurrents."""
        f = BASE / self.csv
        vues = 0
        while self.running:
            time.sleep(2)
            try:
                with open(f, encoding="utf-8-sig") as fh:
                    lignes = fh.readlines()
            except Exception:
                continue
            for l in lignes[1 + vues:]:
                p = l.rstrip("\n").split(";")
                if len(p) < 8:
                    continue
                self.stats["vus"] += 1
                if p[1] == "clic":
                    self.stats["ok"] += 1
                    d = p[5]
                    self.etat.d["concurrents"][d] = self.etat.d["concurrents"].get(d, 0) + 1
                else:
                    self.stats["ko"] += 1
            vues = max(0, len(lignes) - 1)
            self.q.put(("stats", dict(self.stats)))
            conc = sorted(self.etat.d["concurrents"].items(), key=lambda x: -x[1])[:8]
            self.q.put(("conc", "Concurrents : " + ", ".join(f"{d} ({n})" for d, n in conc) if conc else ""))

    def _stop(self):
        C.STOP.write_text("stop", encoding="utf-8")
        self.l_etat.configure(text="arret en cours")
        self.b_stop.configure(state="disabled")

    def _close(self):
        if self.running:
            C.STOP.write_text("stop", encoding="utf-8")
            time.sleep(0.5)
        self.etat.sauve()
        self.root.destroy()


def main():
    root = tk.Tk()
    app = App(root)
    root.protocol("WM_DELETE_WINDOW", app._close)
    root.mainloop()


if __name__ == "__main__":
    main()
