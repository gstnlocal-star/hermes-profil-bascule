# Boucle d'amélioration quotidienne — cliqueur Ads

Objectif : faire monter le **taux de clic** et baisser le **taux de captcha**, sans tricher sur la durée de visite.
Une seule modification par jour, jugée sur les chiffres, et annulée si elle n'aide pas.

## Étape 1 — mesurer
```
cd "C:\Users\googl\Desktop\clic ads"
"C:\Users\googl\Desktop\msg spam\.venv\Scripts\python.exe" bilan.py 24
```
Lire `bilan.txt` et `historique.csv` (la veille est la dernière ligne avant aujourd'hui).
Métriques de référence : `captcha_pct` (à faire baisser), `taux_clic_pct` (à faire monter), `duree_moy_s`.

## Étape 2 — diagnostiquer
Classer les motifs d'échec par volume. Un captcha massif = débit trop élevé ou IP/UA trop répétitifs.
Beaucoup de « aucune annonce » = ciblage ou uule à revoir. Des délais courts = visite peu crédible.
Regarder aussi si les proxies répondent : `python -c` avec un CONNECT sur premium.proxya.co:8888, code 402 = crédit épuisé.

## Étape 3 — une seule amélioration
Choisir le levier le plus rentable, par ordre de préférence :
1. débit : `par`, `vmin`/`vmax2` de config.json (jamais par < 1, ni vmax2 > 45)
2. anti-détection : rotation des UA/écrans dans commun.py (`UA_LISTE`, `ECRANS`), `HIDE`, cookies
3. sélection : poids des positions, gestion des villes stériles, timeouts de `wait_for_selector`
4. reprise : seuils d'arrêt, backoff captcha, politesse entre deux visites

Interdits : toucher `.venv`, changer les colonnes du CSV, supprimer `etat.json`, modifier les listes d'exclusions sans raison mesurée.

## Étape 4 — appliquer proprement
```
cp moteur.py moteur.py.bak_JJHH   (ou commun.py / config.json)
```
Patch minimal, puis :
```
"C:\Users\googl\Desktop\msg spam\.venv\Scripts\python.exe" -c "import ast;ast.parse(open('moteur.py',encoding='utf-8').read())"
```

## Étape 5 — redémarrer
```
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'cmd.exe' -and $_.CommandLine -like '*Lancer en auto*'} | Select -ExpandProperty ProcessId"
```
Tuer ces cmd avec `taskkill /F /T /PID <pid>`, puis tuer les `pythonw` dont la ligne contient `demarrer.py --auto` et les `python.exe` dont la ligne contient `moteur.py` (attention : ne pas toucher ceux de « msg spam »).
```
powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c','\"\"C:\Users\googl\Desktop\clic ads\Lancer en auto.bat\"\"' -WorkingDirectory 'C:\Users\googl\Desktop\clic ads'"
```

## Étape 6 — vérifier
Attendre 5 à 8 minutes : le journal du jour doit contenir des lignes `OK` ou au moins des tentatives sans erreur nouvelle.
Aucune ligne, ou plantage, ou taux de captcha qui explose : restauration du `.bak`, redémarrage, et on note l'échec.

## Étape 7 — consigner
Ajouter dans `CHANGELOG.md` : date, métrique visée, hypothèse, changement exact, effet constaté.
Le rapprochement se fait le lendemain via `historique.csv`.

## Étape 8 — rendre compte
6 lignes maximum : chiffres de la veille, diagnostic, changement, effet attendu, état du robot, prochain levier.

## Cas particulier proxies
Si le test proxy renvoie 200 : crédit revenu, remettre `par` à 10 et prévenir Eric en tête de compte rendu.
Si 402 : rester en IP locale, ne pas dépasser 2 en parallèle.
