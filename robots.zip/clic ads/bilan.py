#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Metriques du cliqueur Ads sur la fenetre demandee (24 h par defaut).

Sortie : bilan.json + bilan.txt dans le dossier, et une ligne dans historique.csv.
Aucune modification du code : lecture seule des CSV et journaux.
"""
import csv
import glob
import json
import os
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
FEN = float(sys.argv[1]) if len(sys.argv) > 1 else 24.0
BORD = datetime.now() - timedelta(hours=FEN)


def jours(files):
    for f in files:
        try:
            if datetime.fromtimestamp(os.path.getmtime(f)) < BORD:
                continue
        except OSError:
            continue
        yield f


def main():
    fichiers = list(jours(glob.glob(str(BASE / "clics_*.csv"))))
    stat, motif, dep, dom, heures, durees = Counter(), Counter(), Counter(), Counter(), Counter(), []
    n = 0
    for f in fichiers:
        with open(f, encoding="utf-8-sig", errors="replace", newline="") as fh:
            for r in csv.reader(fh, delimiter=";"):
                if len(r) < 9 or r[0].startswith("horodatage"):
                    continue
                try:
                    t = datetime.fromisoformat(r[0])
                except ValueError:
                    continue
                if t < BORD:
                    continue
                n += 1
                stat[r[1]] += 1
                heures[t.strftime("%H")] += 1
                if r[1] == "clic":
                    motif[""] += 1
                    dom[r[5]] += 1
                    dep[r[2]] += 1
                    try:
                        durees.append(float(r[7]))
                    except ValueError:
                        pass
                else:
                    motif[r[8][:60]] += 1
    clics, taux = stat.get("clic", 0), 0.0
    if n:
        taux = round(100.0 * clics / n, 1)
    bilan = {
        "fenetre_h": FEN,
        "visites": n,
        "clics": clics,
        "taux_clic_pct": taux,
        "captchas": motif.get("captcha", 0),
        "captcha_pct": round(100.0 * motif.get("captcha", 0) / n, 1) if n else 0.0,
        "statuts": dict(stat),
        "motifs": dict(motif.most_common(10)),
        "duree_moy_s": round(sum(durees) / len(durees), 1) if durees else 0.0,
        "domaines": dict(dom.most_common(10)),
        "deps": dict(dep.most_common()),
        "par_heure": {h: heures[h] for h in sorted(heures)},
        "fichiers": [os.path.basename(f) for f in fichiers],
    }

    lignes = [
        f"Bilan cliqueur Ads - {datetime.now():%Y-%m-%d %H:%M} - fenetre {FEN:g} h",
        f"visites: {n} | clics: {clics} | taux: {taux} % | captchas: {bilan['captchas']} ({bilan['captcha_pct']} %)",
        f"duree moyenne par visite: {bilan['duree_moy_s']} s",
        "motifs: " + (", ".join(f"{k or 'clic'}={v}" for k, v in motif.most_common(8)) or "-"),
        "domaines: " + (", ".join(f"{k}={v}" for k, v in dom.most_common(8)) or "-"),
        "departements: " + (", ".join(f"{k}={v}" for k, v in dep.most_common()) or "-"),
        "visites par heure: " + (", ".join(f"{h}h={v}" for h, v in bilan["par_heure"].items()) or "-"),
    ]
    (BASE / "bilan.json").write_text(json.dumps(bilan, ensure_ascii=False, indent=1), encoding="utf-8")
    (BASE / "bilan.txt").write_text("\n".join(lignes) + "\n", encoding="utf-8")
    with open(BASE / "historique.csv", "a", newline="", encoding="utf-8") as fh:
        csv.writer(fh, delimiter=";").writerow(
            [f"{datetime.now():%Y-%m-%d %H:%M}", f"{FEN:g}", n, clics, taux, bilan["captchas"], bilan["duree_moy_s"]])
    print("\n".join(lignes))


if __name__ == "__main__":
    main()
