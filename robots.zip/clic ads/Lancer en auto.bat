@echo off
cd /d "%~dp0"
"C:\Users\googl\Desktop\msg spam\.venv\Scripts\pythonw.exe" "%~dp0demarrer.py" --auto
