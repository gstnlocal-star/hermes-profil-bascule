# Journal des changements — cliqueur Ads

Chaque ligne : date, métrique visée, hypothèse, changement, effet constaté.

## 2026-11-18 01:30 — mise sous boucle quotidienne
Base de départ, mesurée sur 24 h : 2898 visites, 528 clics, taux 18,2 %, 1630 captchas (56,2 %), 58,4 s par visite.

### 2026-11-18 01:31 — temps perdu sur captcha en IP locale
Hypothèse : sur une IP unique, réessayer trois fois d'affilée le même captcha ne change rien et retarde la visite suivante.
Changement : `range(3)` devient `range(1)` quand `SANS_PROXY` est vrai (moteur.py, fonction visite). Durée de visite mesurée : 58,4 s -> 12,7 s.
Effet attendu : plus de visites tentées par heure, même taux de captcha tant que les proxies manquent.

### 2026-11-18 01:26 — démarrage possible sans crédit proxy
Le préflight renvoyait 402 et le moteur s'arrêtait net. Il bascule désormais en IP locale, plafonne à 2 parallèles et se met en pause escaladante sur captcha (360 s, 600 s max).
