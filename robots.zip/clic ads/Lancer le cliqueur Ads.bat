@echo off
cd /d "%~dp0"
:debut
"C:\Users\googl\Desktop\msg spam\.venv\Scripts\pythonw.exe" "%~dp0demarrer.py"
timeout /t 5 /nobreak >nul
goto debut
