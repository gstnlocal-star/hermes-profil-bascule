# -*- coding: utf-8 -*-
"""Lance l'interface. Le moteur tourne dans son propre processus (lance par l'interface)."""
import faulthandler
import sys
import threading
import time
import tkinter as tk

VIE = open("vie.log", "a", buffering=1)
faulthandler.enable(file=VIE)


def note(m):
    VIE.write(f"{time.strftime('%H:%M:%S')} {m}\n")


note("demarrage")
import ads_cliqueur as S

note("module charge")
root = tk.Tk()
note("tk cree")
app = S.App(root)
note("app creee")
if "--auto" in sys.argv:
    root.after(1200, app._start)
    note("auto planifie")


def battement():
    while True:
        time.sleep(3)
        etat = "oui" if app.proc and app.proc.poll() is None else "non"
        note(f"vivant running={app.running} moteur={etat}")


threading.Thread(target=battement, daemon=True).start()
root.protocol("WM_DELETE_WINDOW", app._close)
note("boucle")
while root.winfo_exists():
    try:
        root.update()
    except tk.TclError:
        break
    time.sleep(0.03)
note("sortie boucle")
