# Windows: capturing and clicking windows the UIA tree refuses

Some native windows never answer the accessibility layer. The tell is a capture
that dies with `get_window_state timed out after 4s (UIA provider unresponsive
on hwnd …, class 'Tauri Window')` — Tauri/Electron apps and Chrome
(`Chrome_WidgetWin_1`) do this. The window is fine; only the AX/UIA route is
blind. Do not retry the same capture more than twice, and do not conclude the
app is undrivable: drop to pixels.

## Capture

1. Whole screen: `computer_use(action="capture", app="screen", mode="vision")`
   returns a PNG path. Read it with `vision_analyze`, which also gives you the
   coordinates to act on.
2. One window only (screen capture would bury it under other windows):
   PowerShell `PrintWindow` against the hwnd into a PNG under the scratch dir,
   then `vision_analyze` that file. `System.Drawing` + `PrintWindow(hwnd, hdc, 2)`
   in an `Add-Type` block is enough; no extra install.

Enumerate windows first with your own P/Invoke `EnumWindows` dump (hwnd, class,
title, rect, visible) — `list_windows` can report the app without the hwnd you
need, and `SetForegroundWindow` silently no-ops from a background process.

## Click

When no capture succeeds, `computer_use(action="click", app=…, coordinate=[x,y])`
answers `No active window — call capture() first`. Fall back to a short
PowerShell script doing `SetCursorPos` + `mouse_event(LEFTDOWN/LEFTUP)` at
screen coordinates, then capture again to verify. Window rects come back in
screen coordinates, so a client coordinate is `rect.x + x`, `rect.y + y`.

A 14×14 window rect or an off-screen origin means you grabbed a hidden helper
window; pick the visible one with a plausible size before clicking.

## Relaunching the user's Chrome on the debug port

Needed when you must read a page in *his* session instead of a fresh headless
browser. He keeps dozens of tabs open, so never kill Chrome casually, and
always pass `--restore-last-session` and the right `--profile-directory`.

Find the profile id from `%LOCALAPPDATA%\Google\Chrome\User Data\Local State`,
key `profile.info_cache`: each entry carries `name`, `user_name`, `gaia_name`.
Match the account he named, never `Default` by habit — he runs many brand
profiles and will correct a wrong one.

```
Start-Process chrome.exe -ArgumentList "--remote-debugging-port=9222 --profile-directory=Profile NN --restore-last-session"
```

Then attach Playwright over CDP (`connect_over_cdp("http://127.0.0.1:9222")`,
`ctx.pages` to list real tabs, skip `chrome://` and `chrome-error://`) rather
than relaunching and re-authenticating Google/Stripe-style logins. Google
sign-in flows open a popup and can hang `wait_for_selector`: drive the popup
page directly and only type the email, leaving the password to the user.

## git-bash ↔ Windows quoting

- `taskkill //IM chrome.exe` fails ("argument ou option non valide"): MSYS
  doubles the slash only for some programs. Use
  `MSYS_NO_PATHCONV=1 taskkill /IM chrome.exe`.
- `Get-CimInstance Win32_Process -Filter 'name="chrome.exe"'` loses its
  quoting through bash → PowerShell. Use
  `Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "chrome.exe" }`.
- Filter by `$_.Path` to separate real Chrome from Hermes' bundled Chromium,
  which also runs `chrome.exe` and owns the debug port when it is up.
