# Recovering a past session and resuming it

When the user says "where is my conversation about X", "reprends le sujet X", or
arrives in a different chat/thread and wants work continued, the job is: locate
the session, tell him exactly where it lives, then rebuild enough context to
carry on **in the current chat**.

## 1. Locate

`session_search(query="<keywords>")` = discovery. It returns
`session_id`, `when`, `source`, `title`, plus a `link` of the form
`@session:<profile>/<id>`. Give that link verbatim, inline mid-sentence —
Telegram renders it as a tappable titled link. Never as markdown, never in
backticks, never on its own line.

Other shapes of the same tool: `session_id=<id>` reads a whole session;
`session_id=<id>, around_message_id=<mid>` scrolls a window. For a session of
a few dozen messages, scroll is enough. For hundreds, go to step 2.

## 2. Where it lives (state.db)

`~/.hermes/state.db` (Windows: `%LOCALAPPDATA%\hermes\state.db`) is the
canonical store. Table `sessions` carries `chat_id`, `chat_type`, `thread_id`,
`origin_json`, `title`, `message_count`, `last_activity_at`, `archived`.
`thread_id` non-null = a topic/thread; null + `chat_type='dm'` = the user's
main DM. That is how you answer "where is it" precisely instead of guessing.

**Pitfall:** the primary-key column of `sessions` is `id`, not `session_id`.
`WHERE session_id=…` raises "no such column" and costs a round-trip. Only the
`messages` table uses `session_id` to reference it; message rows are keyed by
`id`.

Also read `archived` / `hidden`: a session can exist and be invisible in his
UI, which is exactly when he asks where it went.

## 3. Rebuild the context cheaply

Do not chain dozens of scroll calls for a long session. One SQLite pass writes
a compact digest to the scratch dir:

- keep `[id] ROLE: text` for `user` and `assistant` messages,
- for assistant rows, append the tool-call names and a ~180-char slice of
  arguments (that is where the real work shows: file paths, commands),
- for `tool` rows keep ~250 chars, single-line,
- write UTF-8, then `read_file` it in 120–220 line chunks.

Keeping the `[id]` markers lets you jump back to any exact message with a
scroll call if something needs the full payload. A 400-message session
flattens to ~100 KB, which is readable in two or three chunks.

## 4. Resume

1. Say in two or three factual lines what the thread was, where it stopped, and
   what is validated vs still untested. Pull the state from the files and test
   outputs, not from the assistant's own claims in the transcript.
2. Do not tell him to go back to the other chat. Work continues here.
3. Re-ask only the decisions that were still open when the old session broke
   off, numbered and in one message — he answers with a digit.
4. If the old session died mid-work, re-read the actual project files before
   proposing anything: the last assistant message is often empty or truncated.

## Cross-chat confusion

A session bound to the DM keeps running there; a command sent from a topic
thread opens a *different* session. If the user reports that the agent "can't
be given orders from here", that is a session-routing artefact, not a
limitation — restate which chat holds the work and continue in the one you are
in.
