# Régulateurs de débit et de coût

Un robot qui tape sans frein sur une IP unique se fait bloquer en quelques
minutes. Le régulateur remplace l'arrêt manuel : il ferme le débit, attend, et
rouvre seul.

## Frein partagé sur 429 (moteur LSA)

Classe instanciée dans `run()` avant les workers, avec un sémaphore déjà en
place. Deux 429 consécutifs ferment la porte à tout le monde pendant 240 s, puis
360, 480, 600 au maximum ; un succès la rouvre.

```python
class Frein:
    def __init__(self):
        self.n = 0
        self.until = 0.0
        self.lock = asyncio.Lock()

    async def attendre(self):
        while True:
            reste = self.until - time.monotonic()
            if reste <= 0:
                return
            await asyncio.sleep(min(reste, 5))

    async def hit(self):
        async with self.lock:
            self.n += 1
            if self.n >= 2:
                attente = float(min(120 * self.n, 600))
                self.until = time.monotonic() + attente
                log(f"429 x{self.n} : pause {int(attente)}s")

    def ok(self):
        self.n = 0
```

Dans le worker : `await frein.attendre()` avant de prendre le sémaphore (pour
que les autres ne le tiennent pas pendant la pause), `frein.ok()` après un
succès, `await frein.hit()` dans la branche « rate limit ».

Le chien de garde qui tue le moteur figé doit être réglé **au-dessus** de la
pause maximale (1200 s pour un plafond de 600 s), sinon il relance en pleine
pause et perd le backoff.

## Même principe sur captcha (cliqueur)

Un compteur partagé et un `gate_until` consulté avant chaque visite, pause
180 s par captcha consécutif, 600 s au maximum, remise à zéro sur un clic. Et en
mode IP locale, **une seule** tentative par visite (`range(1 if SANS_PROXY else 3)`) :
réessayer trois fois de suite sur la même IP grillée triple le temps pour le
même échec. Effet mesuré : 58 s par visite à 13 s.

## Bascule locale au lieu d'un arrêt

```python
if etat_proxy != "ok":
    C.SANS_PROXY = True
    log(f"Proxies indisponibles ({detail}) : passage en IP locale")
    cfg["par"] = max(1, min(int(cfg.get("par", 1)), SANS_PROXY_PAR))
```

et côté pool : `if SANS_PROXY: return [None] * n`, Playwright acceptant
`proxy=None`. Plafonds : LSA 1, clics 2. Au-delà, Google répond 429 en deux
minutes même à quatre.

## Alerte de solde silencieuse

Script appelé par un cron `no_agent` : tester trois proxies (début, milieu, fin
de la liste) en CONNECT, lire le code, comparer au fichier d'état, n'imprimer
qu'au changement. Sortie vide = rien envoyé. Codes : 200 disponible, 402 épuisé,
407 refusé, aucun code = injoignable.

```python
def code_proxy(ligne):
    hote, port, user, mdp = ligne.strip().split(":", 3)
    auth = base64.b64encode(f"{user}:{mdp}".encode()).decode()
    with socket.create_connection((hote, int(port)), timeout=12) as s:
        s.sendall(f"CONNECT www.google.fr:443 HTTP/1.1\r\nHost: www.google.fr:443\r\n"
                  f"Proxy-Authorization: Basic {auth}\r\n\r\n".encode())
        rep = s.recv(200).decode("latin-1", "ignore")
    return int(rep.split(" ")[1]) if rep.startswith("HTTP/") else 0
```

## Métriques à sortir chaque jour

LSA : tentatives, confirmés, taux, motifs d'échec, doublons de mail, annonces
servies, villes. Clics : visites, clics, taux, captchas, motifs, durée moyenne,
domaines et départements. Fenêtre glissante de 24 h, historique en CSV pour
comparer à la veille. C'est la mesure qui décide du levier, pas l'intuition.
