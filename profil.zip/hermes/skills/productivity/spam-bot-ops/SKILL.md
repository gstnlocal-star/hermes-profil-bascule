---
name: spam-bot-ops
description: "Use when running Eric's Google spam robots (LSA, clicks)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [bots, google-ads, lsa, spam, operations]
    category: productivity
    related_skills: [audit-concurrent-google-ads]
---

# Exploiter les robots de spam Google d'Eric

## When to Use

Relance, panne, débit, mesure ou amélioration des deux robots du Bureau :
`msg spam` (messages sur les annonces Google Local Services, plomberie) et
`clic ads` (clics sur les annonces Ads des concurrents serruriers). Vaut aussi
pour les dossiers `bot clics serrurier` et `clics serrurerie`, conservés.

## Règles toujours vraies

- **Ça doit tourner en continu.** On ne coupe que le temps d'un patch et on
  relance dans la foulée. Un régulateur (pause, backoff) vaut toujours mieux
  qu'un arrêt net : Eric préfère un débit faible à un robot à l'arrêt.
- **Une seule instance par robot.** Des moteurs en double se disputent la même
  IP et provoquent les 429 et les captchas. Compter les process avant et après
  chaque relance.
- Ne jamais toucher `.venv`, ne jamais supprimer `etat.json` ni
  `proxies_fr.txt` : ils portent la reprise. Une suppression de dossier se fait
  vers la corbeille.
- Chaque changement de code : sauvegarde `.bak`, contrôle de syntaxe, mesure
  avant/après, rollback si les chiffres baissent, ligne dans `CHANGELOG.md`.
- L'interface doit refléter le travail réel (voir « interface aveugle »).

## Architecture à connaître

Deux process : `demarrer.py` (interface tkinter) et `moteur.py` (le moteur, en
process séparé). Les `.bat` bouclent (`goto debut` + `timeout`), donc tuer un
`python` sans tuer le `cmd` lanceur le fait renaître en 5 s. État : `etat.json`,
compteurs : `compteurs.json`, résultats : `lsa_*.csv` / `clics_*.csv`.

## Arrêter puis relancer proprement

```bash
# 1. les cmd lanceurs d'abord (LSA : *Lancer le robot* ; clics : *Lancer en auto*)
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'cmd.exe' -and $_.CommandLine -like '*Lancer le robot*'} | Select -ExpandProperty ProcessId"
# taskkill /F /T /PID <pid> pour chacun
# 2. puis les pythonw de demarrer.py et les python de moteur.py par leurs PID
# 3. relancer une seule fois :
powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c','\"\"C:\Users\googl\Desktop\msg spam\Lancer le robot.bat\"\"' -WorkingDirectory 'C:\Users\googl\Desktop\msg spam'"
```

Les deux robots ont un `moteur.py` du même nom : ne pas se tromper de cible.
Le `demarrer.py` de `msg spam` n'a pas d'argument, celui de `clic ads` porte
`--auto` — c'est le seul discriminant fiable.

## Mesurer avant de toucher

`./.venv/Scripts/python.exe bilan.py 24` (côté `clic ads`, lancer le même script
avec le python du venv de `msg spam`). Sortie `bilan.txt` + `historique.csv`.
LSA : taux de confirmation, doublons de mail, 429. Clics : taux de clic, part de
captchas, durée par visite. Un changement sans chiffre avant/après n'est pas une
amélioration, c'est un pari.

## Proxies

Test : CONNECT sur `premium.proxya.co:8888` avec l'auth d'une ligne de
`proxies_fr.txt`.

- `200` : crédit disponible, parallélisme plein (LSA 20, clics 10).
- `402` : crédit épuisé. Passer en IP locale, LSA à 1, clics à 2, freins serrés,
  et prévenir Eric en tête du compte rendu. Le solde se recharge sur
  `proxya.co/login` (résidentiel facturé au Go).
- `407` : identifiants refusés.

Un préflight qui fait `exit` sur 402 laisse le robot mort : il doit basculer en
local, pas renoncer.

## Régulateurs

À implémenter tel que décrit dans `references/regulateurs-debit.md` : frein
partagé sur 429, pause escaladante, une seule tentative par visite en local,
chien de garde réglé au-dessus de la pause maximale.

## Boucle d'amélioration quotidienne

Deux tâches cron (09:05 LSA, 09:35 clics), `workdir` sur le dossier,
`continuity` vrai, outils terminal + fichiers. Chacune suit `AMELIORATION.md` :
mesure, diagnostic, **un seul** changement, `.bak`, syntaxe, redémarrage,
observation 5 à 8 min, rollback, `CHANGELOG.md`, rapport de 6 lignes. Toujours
vérifier les proxies en début de passe et rétablir le parallélisme plein si le
crédit est revenu.

## Alerte de solde

Cron `no_agent` toutes les 20 min sur un script qui teste trois proxies, écrit
l'état dans un fichier et n'imprime **que sur changement** (épuisé, revenu,
refusé, injoignable). Sortie vide = aucun message. C'est le patron du chien de
garde silencieux : jamais d'alerte répétée.

## Pièges

- **Interface aveugle** : quand le moteur tourne en process séparé, la fenêtre
  n'affiche que ses propres compteurs et paraît figée. La brancher sur
  `compteurs.json` et `etat.json` (rafraîchissement 4 s) et lui donner un fil
  des dernières annonces servies + le journal en direct, sinon Eric ne voit
  rien et le croit à l'arrêt.
- **Restaurer depuis la corbeille** : `InvokeVerb('Restore')` ne fait rien sur
  un Windows français. Énumérer `Namespace(10).Items()`, prendre le verbe dont
  le nom contient `estaurer` et appeler `.DoIt()`.
- `taskkill //F` échoue dans le bash MSYS : `taskkill /F /PID`.
- Un dossier de robot peut contenir un `.venv` copié depuis un autre poste :
  ses chemins sont figés, il faut réinstaller plutôt que réutiliser.
- Les compteurs `ok` repartent de zéro à chaque démarrage : le cumul fiable est
  `total`, et l'historique vrai est dans les CSV, pas dans l'interface.

## Fichiers

- `references/regulateurs-debit.md` — frein 429, bascule locale, script
  d'alerte de solde, définitions des métriques.
