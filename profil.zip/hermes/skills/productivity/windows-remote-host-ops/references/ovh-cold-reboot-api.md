# Redémarrage à froid d'un VPS OVH par API

Quand le bureau distant ne peint plus, le portail de gestion n'est pas une
option viable (SPA bloqué en « Chargement en cours… », état perdu au reload).
L'API OVH fait le travail en deux appels.

## 1. Obtenir un token sur la BONNE zone

Un compte appartient à une seule zone. `manager.ca.ovhcloud.com` renvoie
`invalid_account_or_password` pour un compte Europe : passer par
`https://www.ovh.com/manager/`, qui redirige vers `auth.eu.ovhcloud.com` (2FA
e-mail, demander le code au moment de la connexion).

Puis, en étant connecté, ouvrir :

```
https://eu.api.ovh.com/createToken/?GET=/vps&GET=/vps/*&POST=/vps/*&PUT=/vps/*
```

Remplir nom + description, cliquer « Create », relever `application-key`,
`application-secret`, `consumer-key`. **Déclarer `/vps` ET `/vps/*`** : avec
`/vps/*` seul, `GET /vps` sort `403 NOT_GRANTED_CALL`.

## 2. Signer et appeler

Signature = `$1$` + sha1(`AS` + `+` + `CK` + `+` + `METHOD` + `+` + URL complète +
`+` + body + `+` + timestamp), timestamp synchronisé sur `GET /auth/time`.
En-têtes `X-Ovh-Application`, `X-Ovh-Consumer`, `X-Ovh-Timestamp`,
`X-Ovh-Signature`. Base : `https://eu.api.ovh.com/1.0`.

```python
import hashlib, json, time, urllib.request
AK, AS_, CK = "...", "...", "..."   # application-key / secret / consumer-key
BASE = "https://eu.api.ovh.com/1.0"
DRIFT = int(urllib.request.urlopen(BASE + "/auth/time").read()) - int(time.time())

def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    ts = str(int(time.time()) + DRIFT)
    sig = "$1$" + hashlib.sha1("+".join([AS_, CK, method, BASE + path,
                                          data.decode() if data else "", ts]).encode()).hexdigest()
    req = urllib.request.Request(BASE + path, data=data, method=method)
    for k, v in (("X-Ovh-Application", AK), ("X-Ovh-Consumer", CK),
                 ("X-Ovh-Timestamp", ts), ("X-Ovh-Signature", sig),
                 ("Content-Type", "application/json")):
        req.add_header(k, v)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())

svc = call("GET", "/vps")[0]                   # vps-xxxxxxxx.vps.ovh.ca
print(call("GET", f"/vps/{svc}")["state"])     # "running" avant d'agir
print(call("POST", f"/vps/{svc}/reboot", {}))  # {"type":"rebootVm","id":N,"state":"todo"}
```

## 3. Vérifier

- `GET /vps/{svc}/tasks/{id}` jusqu'à `state=done` (quelques secondes).
- La session RDP cliente tombe avec « Votre session Services Bureau à distance
  est terminée / L'ordinateur distant est en train de s'éteindre » : c'est la
  confirmation que la tâche est passée.
- Attendre `state=running` + 3389 qui répond, puis ~1 min de plus avant de se
  reconnecter : le service RDP accepte avant que le bureau soit peint et une
  connexion trop précoce redonne l'écran noir qu'on voulait corriger.

## Pièges

- Ne pas conclure « identifiants faux » sur `invalid_account_or_password` sans
  avoir essayé l'autre zone.
- `reboot` est une coupure à froid : relever ce qui tourne avant (robots,
  services) et le relancer après.
- La clé API a une durée de vie ; la recréer plutôt que réutiliser une clé qui
  traîne.
