# Identifiants Windows et Chrome : ce qui est extractible

## Identifiants RDP

`cmdkey /list` montre la cible (`Domain:target=TERMSRV/<ip>`) et le nom
d'utilisateur. C'est suffisant pour que `mstsc` se connecte seul.

En revanche `CredReadW` / `CredReadDomainCredentialsW` renvoient bien
l'utilisateur mais `CredentialBlobSize = 0` : le secret n'est pas dans le blob.
Ne pas espérer en tirer un mot de passe (inutile pour un client tiers comme
FreeRDP).

## Fichiers du magasin d'identifiants

`%LOCALAPPDATA%\Microsoft\Credentials\*` : en-tête `01 00 00 00` + taille en
clairs, puis un blob commençant par `01000000D08C9DDF0115D1118C7A00C04FC297EB`.
Ces blobs ne sont PAS du DPAPI nu : `CryptUnprotectData` échoue en erreur 13
(`ERROR_INVALID_DATA`) même avec le bon GUID et la bonne longueur. Le format
complet passe par l'API Vault (`vaultcli` : `VaultEnumerateVaults`, puis
`VaultEnumerateItems` qui rend les blobs déchiffrés). Non implémenté à ce
jour : le tenter seulement si le mot de passe devient indispensable.

## Pièges DPAPI / ctypes (si on y touche)

- Magic DPAPI correct : `01000000D08C9DDF0115D1118C7A00C04FC297EB`.
  Le GUID `...0115D1118A3900C0...` circule souvent et il est faux.
- Toujours définir `argtypes`/`restype` : sans eux ctypes passe les `str` en
  ANSI et `CryptUnprotectData` répond 87 (paramètre invalide).
- `CredReadDomainCredentialsW` rend un tableau de POINTEURS : déclarer
  `POINTER(POINTER(CREDENTIAL))`, sinon on lit `UserName` à `None` et une
taille absurde.
- Valider le code sur un aller-retour `CryptProtectData`/`CryptUnprotectData`
  d'une chaîne témoin avant de conclure quoi que ce soit sur un fichier.

## Mots de passe du navigateur

`<profil>\Login Data` est une base SQLite verrouillée par Chrome : copier le
fichier avant lecture. Plusieurs profils existent sous `User Data\` (`Default`
en concentre la plupart) : les balayer tous.

Commencez par vérifier la présence de l'origine avant de tenter un
déchiffrement :

```sql
select origin_url, username_value from logins where origin_url like '%<domaine>%';
```

Beaucoup de services courants n'y sont pas enregistrés (aucune entrée OVH sur
ce poste) : constater l'absence coûte 30 s, contre plusieurs minutes de
déchiffrement AES-GCM (v10/v11, clé DPAPI de `Local State`) pour rien.
