# Livrer et exécuter un script dans une session invitée

Le presse-papiers redirigé et `drivestoredirect:s:C:\` ne sont pas fiables
(cases du dialogue décochées, `\\tsclient\C` inexistant alors que la ligne est
dans le `.rdp`). Construire le transfert sur autre chose.

## Voie qui marche : URL directe + curl

1. Déposer le script dans un gist secret (`gh gist create script.ps1`) —
   immédiat et versionné. **Les gists refusent les binaires** : pour un zip ou
   un `.exe`, pousser dans un dépôt public et servir l'URL raw, ou réhéberger
   (catbox/file.io/bashupload répondent souvent `Invalid uploader` depuis une
   IP résidentielle).
2. Taper une ligne courte dans la session :
   `curl.exe -L -s -o C:/x.ps1 <raw>` puis
   `powershell -ExecutionPolicy Bypass -File C:/x.ps1`.
3. Le script fait tout ce qui est long ou ponctué (`|`, `\`, accolades).

**Ne pas passer par un raccourcisseur** (`is.gd`, `tinyurl`) : `irm` reçoit une
page de challenge Cloudflare au lieu du script. L'URL raw du gist répond 200 et
reste tapable (~95 caractères). Un `curl` sur le raccourcisseur suit la
redirection mais ramène aussi le challenge.

## Ce que `SendKeys` mange

AltGr du clavier FR : `\` et `|` disparaissent (`C:\hp\x` → `C:hpx`, pipeline
avalé). Donc :

- chemins en `/` — PowerShell les normalise, `Copy-Item C:/hp/a "$h/a"` passe ;
- les pipes vivent dans le `.ps1`, jamais dans la ligne tapée ;
- `[ ] { } + ^ % ~ ( )` sont des touches : `iex {(}irm url{)}` pour des
  parenthèses littérales ;
- chaque ligne de séquence finit par `{ENTER}`, sinon la suivante se concatène
  à la précédente.

## Console réelle, pas ISE

`start powershell` depuis ISE ouvre une vraie console. ISE seul ne suffit pas :
les TUI (assistant de configuration, chat Hermes) meurent en
`prompt_toolkit.output.win32.NoConsoleScreenBufferError: No Windows console
found`. Un installeur qui échoue en fin de course sur cette erreur a toutefois
posé les fichiers : relancer la configuration dans la console, pas réinstaller.

## Vérifier le focus avant chaque envoi

Voir `scripts/rdp_client_ctl.ps1 -Action send` : il refait le focus et le
contrôle à chaque ligne. Un clic au centre de la fenêtre avant la frappe remet
le curseur dans la console invitée. Compter les répétitions du texte pour
repérer un envoi doublé.
