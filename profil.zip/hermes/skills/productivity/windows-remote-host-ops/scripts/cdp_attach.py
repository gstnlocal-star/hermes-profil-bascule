"""Piloter l'onglet Chrome de l'utilisateur via CDP (debug port 9222).

Ouvre un onglet dedie et laisse les siens tranquilles. Usage depuis un
kernel Python qui a `requests` et `websockets` :

    import cdp_attach as cdp
    t = cdp.new_tab("https://exemple/")
    print(cdp.text(t))
    cdp.click_xy(t, 300, 292)      # clic evenementiel (declenche l'autofill)
    cdp.fill(t, "#champ", "valeur")

Attendre apres une navigation : le SPA met plusieurs secondes ; relire
`cdp.js(t, "location.href")` jusqu'a obtenir l'URL attendue plutot que de
supposer que la page est prete.
"""
import asyncio
import json
import time

import requests
import websockets

BASE = "http://127.0.0.1:9222"


def tabs():
    return [t for t in requests.get(BASE + "/json/list", timeout=10).json() if t.get("type") == "page"]


def find_tab(substr):
    for t in tabs():
        if substr in t["url"]:
            return t
    return None


def new_tab(url="about:blank"):
    r = requests.put(f"{BASE}/json/new?{url}", timeout=10)
    if r.status_code == 405:
        r = requests.get(f"{BASE}/json/new?{url}", timeout=10)
    return r.json()


async def _call(ws_url, method, params, timeout):
    async with websockets.connect(ws_url, max_size=None) as ws:
        await ws.send(json.dumps({"id": 1, "method": method, "params": params or {}}))
        while True:
            msg = json.loads(await asyncio.wait_for(ws.recv(), timeout))
            if msg.get("id") == 1:
                return msg


def call(tab, method, params=None, timeout=30):
    return asyncio.run(_call(tab["webSocketDebuggerUrl"], method, params, timeout))


def goto(tab, url, wait=8):
    call(tab, "Page.enable")
    call(tab, "Page.navigate", {"url": url})
    time.sleep(wait)


def js(tab, expr, timeout=30):
    r = call(tab, "Runtime.evaluate",
             {"expression": expr, "returnByValue": True, "awaitPromise": True}, timeout)
    res = r.get("result", {})
    if "exceptionDetails" in res:
        return {"error": res["exceptionDetails"].get("text")}
    return res.get("result", {}).get("value")


def text(tab, limit=3000):
    return js(tab, "document.body ? document.body.innerText.slice(0,%d) : ''" % limit)


def click_xy(tab, x, y):
    """Clic "trusted" : necessaire pour les menus natifs (autofill, select)."""
    js(tab, "document.elementFromPoint(%d,%d)?.focus()" % (x, y))
    for kind in ("mouseMoved", "mousePressed", "mouseReleased"):
        p = {"type": kind, "x": x, "y": y, "button": "left", "clickCount": 1}
        if kind == "mouseMoved":
            p.pop("button")
            p.pop("clickCount")
        call(tab, "Input.dispatchMouseEvent", p)


def fill(tab, selector, value):
    return js(tab, """(() => {const e=document.querySelector(%s); if(!e) return 'NOELEM';
        const s=Object.getOwnPropertyDescriptor(e.__proto__,'value').set;
        s.call(e, %s); e.dispatchEvent(new Event('input',{bubbles:true}));
        e.dispatchEvent(new Event('change',{bubbles:true})); return 'ok';})()"""
              % (json.dumps(selector), json.dumps(value)))


def click_text(tab, label):
    """Cliquer un element par son libelle visible (bouton, lien)."""
    return js(tab, """(() => {const el=[...document.querySelectorAll('button,a')]
        .find(e=>(e.innerText||'').trim().toLowerCase().includes(%s));
        if(!el) return 'NOELEM'; el.click(); return 'clic';})()""" % json.dumps(label.lower()))
