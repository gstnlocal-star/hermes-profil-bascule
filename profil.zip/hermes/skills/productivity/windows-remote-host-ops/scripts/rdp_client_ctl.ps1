<#
  Pilotage du client mstsc sans souris ni focus volé.
  Usage :
    powershell -NoProfile -ExecutionPolicy Bypass -File rdp_client_ctl.ps1 -Action focus
    powershell -NoProfile -ExecutionPolicy Bypass -File rdp_client_ctl.ps1 -Action accept
    powershell -NoProfile -ExecutionPolicy Bypass -File rdp_client_ctl.ps1 -Action send -File keys.txt

  -Action focus  : amène la dernière fenêtre mstsc au premier plan et vérifie
                   le résultat (AttachThreadInput, sans vol de focus durable).
  -Action accept : clique le bouton « Connexion » du dialogue d'avertissement
                   de sécurité, en coordonnées LOGIQUES calculées depuis le
                   rect de la fenêtre (jamais depuis la capture agrandie).
  -Action send   : envoie ligne par ligne un fichier de séquences SendKeys
                   ({ENTER} pour valider). Écrire ce .ps1 et les séquences en
                   UTF-8 avec BOM.
#> 
param(
  [Parameter(Mandatory=$true)][ValidateSet('focus','accept','send')]$Action,
  [string]$File
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class RdpCtl {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowTextW(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, int e);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool f);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }

  // Amène h au premier plan et renvoie true si le focus a réellement changé.
  public static bool ForceForeground(IntPtr h) {
    uint fgpid; uint tfg = GetWindowThreadProcessId(GetForegroundWindow(), out fgpid);
    uint tme = GetCurrentThreadId();
    AttachThreadInput(tfg, tme, true);
    ShowWindow(h, 9);   // SW_RESTORE, pas SW_MAXIMIZE : une fenêtre minimisée reste minimisée avec 3
    BringWindowToTop(h);
    SetForegroundWindow(h);
    AttachThreadInput(tfg, tme, false);
    System.Threading.Thread.Sleep(600);
    return GetForegroundWindow() == h;
  }

  public static string ClickAccept() {
    IntPtr target = IntPtr.Zero; RECT rr = new RECT();
    EnumWindows(delegate(IntPtr h, IntPtr l) {
      StringBuilder sb = new StringBuilder(512);
      GetWindowTextW(h, sb, 512);
      if (sb.ToString().StartsWith("Avertissement")) { RECT r; GetWindowRect(h, out r); target = h; rr = r; return false; }
      return true;
    }, IntPtr.Zero);
    if (target == IntPtr.Zero) return "dialogue introuvable";
    ForceForeground(target);
    int x = rr.R - 131, y = rr.B - 35;   // coordonnees logiques, cf. SKILL.md
    SetCursorPos(x, y);
    System.Threading.Thread.Sleep(300);
    mouse_event(2,0,0,0,0); mouse_event(4,0,0,0,0);
    return string.Format("clic {0},{1}", x, y);
  }
}
"@

function Get-NewestMstsc {
  $p = Get-Process mstsc -ErrorAction SilentlyContinue | Sort-Object StartTime -Descending | Select-Object -First 1
  if (-not $p) { throw "aucune fenetre mstsc" }
  return $p.MainWindowHandle
}

switch ($Action) {
  'focus'  { "fg=" + [RdpCtl]::ForceForeground((Get-NewestMstsc)) }
  'accept' { [RdpCtl]::ClickAccept() }
  'send'   {
    if (-not $File -or -not (Test-Path $File)) { throw "-File manquant" }
    if (-not [RdpCtl]::ForceForeground((Get-NewestMstsc))) { throw "focus non obtenu, frappes non envoyees" }
    foreach ($line in [System.IO.File]::ReadAllLines($File)) {
      # le focus est volé en continu par les outils locaux : le revérifier à CHAQUE ligne
      if (-not [RdpCtl]::ForceForeground((Get-NewestMstsc))) { throw "focus perdu, frappes interrompues" }
      [System.Windows.Forms.SendKeys]::SendWait($line)
      Start-Sleep -Milliseconds 900
    }
    "sequences envoyees"
  }
}
