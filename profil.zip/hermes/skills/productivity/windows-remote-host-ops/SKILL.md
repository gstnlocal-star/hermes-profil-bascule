---
name: windows-remote-host-ops
description: "Diagnostiquer et redémarrer un Windows distant (VPS)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [windows, rdp, vps, reboot, ops]
    category: productivity
    related_skills: [computer-use]
---

# Administrer un Windows distant (VPS, serveur, VM hors poste)

## When to Use

« Mon VPS est en bug, redémarre-le », « le serveur ne répond plus », accès à
un Windows qui n'est pas cette machine. La demande arrive en une ligne, sans
contexte : à toi de retrouver la cible et le moyen de la piloter.

Un redémarrage est réversible : on agit sans faire valider, mais on vérifie
avant ET après. On demande seulement ce qui tourne sur la machine (robots,
campagnes, services) pour pouvoir le relancer.

## 1. Identifier l'hébergement avant toute chose

La réponse détermine toute la suite : VM locale = redémarrage hyperviseur,
serveur distant = panneau fournisseur.

```bash
# hyperviseurs locaux
ls "/c/Program Files/Oracle/VirtualBox/VBoxManage.exe" \
   "/c/Program Files/VMware/VMware Workstation/vmrun.exe" 2>/dev/null
tasklist | grep -iE "vmware|virtualbox|vboxheadless|vmwp|vmms|qemu"

# cibles RDP déjà connues de la machine (search_files, puis lire la ligne
# "full address:s:<ip>")
find /c/Users/googl -maxdepth 5 -iname "*.rdp" 2>/dev/null
grep -o "full address:s:[^ ]*" "<fichier>.rdp"

# nom du service = fournisseur (vps-xxxxxxxx.vps.ovh.ca => OVH)
nslookup <ip>
```

Les identifiants RDP enregistrés se lisent avec `cmdkey /list` (chercher
`TERMSRV/<ip>`). Le nom d'utilisateur suffit : `mstsc` réutilise le secret
stocké sans jamais le demander.

## 2. Lire l'état réel, sans rien modifier

```bash
ping -n 3 <ip>
# scan de ports courts : 3389 RDP, 22 SSH, 5985/5986 WinRM, 135/445 RPC, 80/443
powershell -NoProfile -Command "\$t=@(3389,22,5985,135,445,80,443); foreach(\$p in \$t){ \$c=New-Object Net.Sockets.TcpClient; \$a=\$c.BeginConnect('<ip>',\$p,\$null,\$null); if(\$a.AsyncWaitHandle.WaitOne(1200) -and \$c.Connected){\"OUVERT \$p\"}; \$c.Close() }"
```

Lecture : 3389 seul ouvert = aucune voie de commande à distance (ni SSH, ni
WinRM, ni RPC), donc tout passera par la console graphique ou le panneau. Si
22 ou 5985 répond, y aller directement (`ssh`, `Enter-PSSession`) plutôt que
par RDP : plus court et scriptable.

## 3. Voie in-band (le bureau distant répond)

```bash
cmd /c start "" mstsc.exe "<chemin>.rdp"   # ou mstsc /v:<ip>
```

Le dialogue « Avertissement de sécurité » bloque chaque connexion. Le valider
par calcul de coordonnées, pas au hasard.

1. **Coordonnées en pixels logiques**, jamais ceux de la capture : la capture
   plein écran est agrandie (1920x1080 d'image pour un écran logique de
   1536x864, facteur 1,25). Un clic déduit de l'image tombe à quelques dizaines
   de pixels du bouton et le dialogue reste ouvert. `GetWindowRect`,
   `SetCursorPos` et `Cursor.Position` partagent l'espace logique : localiser
   la fenêtre du dialogue via `EnumWindows` + `GetWindowRect`, puis cliquer à
   `right-131, bottom-35` (bouton « Connexion »).
2. Preuve de connexion : le titre passe de « Connexion Bureau à distance » à
   « <nom du .rdp> - <ip> - Connexion… ». Le nom vient du fichier `.rdp`, pas
   de l'hôte : sa présence signifie bien session établie.
3. Écran noir côté bureau : relancer avec un `.rdp` contenant
   `alternate shell:s:cmd.exe` pour court-circuiter un explorateur mort.

Focus et frappes :

- `focus_app` de `cua` peut refuser (« this session has ended ») et
  `SetForegroundWindow` seul échoue quand un autre process vole le premier
  plan (cliqueur, boîte à outils, navigateur) : enchaîner `AttachThreadInput`
  + `BringWindowToTop` + `SetForegroundWindow`, puis **contrôler** le retour
  (`GetForegroundWindow() -eq $h`). Sans ce contrôle, les frappes partent
  ailleurs et tout le reste est faux.
- Frappes par `SendKeys` en mode foreground uniquement. `SendKeys` traite
  `[ ] { } + ^ % ~ ( )` comme des touches : `$l=[Net.Sockets.TcpListener]`
  arrive mutilé. Soit choisir des commandes sans crochets
  (`python -m http.server 9999`), soit échapper chaque caractère.
- Un test de saisie à l'aveugle doit avoir **une seule** dépendance
  observable. Ouvrir un port en écoute est le bon signal ; une redirection
  vers `\\tsclient\C` ou un `netsh`+`python` cumulés mélangent deux causes
  possibles et n'apprennent rien quand ça échoue.
- Écrire les `.ps1` en UTF-8 **avec BOM** : en ANSI, `powershell -File` casse
  les accents et les comparaisons de titres français ne matchent plus.
- `win+r` puis `shutdown /r /t 5 /f` en foreground. Vérification : boucler
  `ping` ~1 min ; la chute des réponses est la seule preuve côté client que le
  reboot a démarré. Sans chute, la commande n'est pas passée.

Transfert de fichiers : `drivestoredirect:s:C:\` dans le `.rdp` expose le
disque local en `\\tsclient\C` dans la session. C'est la voie de copie, et un
fichier écrit là sert de journal lisible depuis le poste.

Éviter `mstsc /public` sauf si le mot de passe est connu : il vide le cache
d'identifiants et ouvre une demande « Sécurité Windows » que le cache
`TERMSRV` évitait.

## 4. Voie hors-bande (bureau mort, panneau fournisseur)

Un bureau qui ne peint plus (noir en session normale, en shell direct, en
`/admin`, en basse résolution) ne se répare pas en RDP : redémarrage à froid
côté fournisseur. **L'API du fournisseur est plus fiable que son portail web** :
les SPA de gestion restent en « Chargement en cours… » sans rendre la main et
l'état est perdu au reload. Recette OVH complète (zone Europe, `createToken`,
signature, `POST /vps/{svc}/reboot`, suivi de tâche) dans
`references/ovh-cold-reboot-api.md`.

Le portail ne sert qu'à obtenir un token. Deux points de bascule qui font
perdre du temps :

- Un compte OVH appartient à UNE zone géographique. Le portail canadien
  (`manager.ca.ovhcloud.com`) rend `invalid_account_or_password` pour un compte
  Europe même quand l'IP est au Canada — basculer sur `www.ovh.com/manager`, qui
  redirige vers `auth.eu.ovhcloud.com`.
- Le code 2FA e-mail d'OVH expire vite : le demander au moment de la connexion.

Un redémarrage à froid tue la session RDP : le dialogue « Votre session
Services Bureau à distance est terminée / L'ordinateur distant est en train de
s'éteindre » côté client EST la confirmation que la tâche est passée. Attendre
`state=running` + 3389 qui répond, puis ~1 min de plus : le service RDP accepte
avant que le bureau soit peint, et se connecter trop tôt redonne une session
noire.

## 5. Clore

Dire ce qui est vérifié (telle variante a échoué, tel port est ouvert), ce qui
bloque et pourquoi, ce qui reste à faire après le reboot. Ne jamais annoncer
« c'est redémarré » tant que le ping n'a pas chuté puis repris.

## Pièges

- `taskkill //PID N` échoue dans le bash MSYS de ce poste : `taskkill /PID N /F`.
- Les `.rdp` sont en UTF-16LE : `sed`/`grep` n'y voient rien. Les réécrire avec
  `write_file` (contenu ASCII neuf) plutôt que les éditer sur place.
- Horodater les relevés de ping (`date +%H:%M:%S`) : la preuve devient lisible.
- Pour **lire** l'écran invité, `PrintWindow` sur le handle de la fenêtre
  `mstsc` avec le drapeau 2 rend une image nette, même recouverte par d'autres
  fenêtres : c'est la voie de lecture (statut, logs, résultats de commande). Le
  grab d'écran classique (`ImageGrab`), lui, rend la zone cliente en noir même
  session établie : une capture noire ne prouve donc rien sur l'état de la
  machine, trancher par un effet extérieur (port en écoute, chute du ping).
- Ne pas boucler sur les variantes RDP (résolutions, `/admin`, shadow) plus de
  deux essais : au-delà c'est le panneau. `mstsc /shadow:<id>` sort « Ce nom
  d'ordinateur n'est pas valide » même avec l'IP ou le FQDN : piste secondaire.
  Changer de client RDP ne règle rien en une minute : FreeRDP est absent de
  winget et `choco install` échoue sans élévation.
- `SendKeys` perd aussi `\` et `|` (AltGr sur clavier FR) : la commande arrive
  en `C:hpSOUL.md` ou sans son pipe. Chemins en `/` (PowerShell les normalise)
  et pipelines dans un `.ps1` téléchargé, jamais dans la ligne tapée : une
  ligne tapée porte UNE commande sans pipe, donc préférer les paramètres
  (`-Tail 12`, `-Name`) au lieu d'un `|`.
- Un argument de chemin commençant par `//` est lu comme un paramètre par
  PowerShell (`Get-ChildItem //tsclient/C` échoue) : écrire `-Path
  //tsclient/C`, ou mieux un chemin cité (`"C:/Users/..."`). `dir
  \\tsclient\C` n'arrive pas du tout, les `\` étant mangés.
- Le bas de la console invitée est coupé par le bord de la fenêtre :
  `cls{ENTER}` puis une commande courte (5 lignes max) pour lire un résultat,
  sinon il reste hors champ.
- Deux agents peuvent taper dans la même console invitée en même temps : les
  lignes s'entrelacent et la sortie lue ne correspond plus à la commande
  envoyée. Vérifier l'écran avant d'envoyer, garder des lignes courtes, relire
  après chaque envoi avant de conclure.
- Les robots tkinter locaux de l'utilisateur, lancés par des `.bat` en boucle,
  reprennent le premier plan en continu : `taskkill` le `cmd.exe` lanceur AVANT
  les `pythonw`, sinon le `.bat` les relance et le focus est repris. Les arrêter
  le temps du travail, les relancer ensuite, et le dire dans le compte rendu.
- Presse-papiers et `drivestoredirect` peuvent rester inactifs malgré les
  bonnes lignes dans le `.rdp` (cases du dialogue décochées, `\\tsclient\C`
  inexistant) : ne pas bâtir un transfert dessus, voir
  `references/guest-shell-and-transfers.md`.
- `powershell` lancé depuis ISE ouvre une vraie console ; ISE seul casse les
  TUI (`NoConsoleScreenBufferError: No Windows console found`).
- Le blob d'un identifiant `TERMSRV` lu via `CredRead` est vide : le mot de
  passe RDP n'est pas récupérable par cette voie, inutile d'insister.

## Fichiers

- `references/windows-credentials-dpapi.md` — ce qui est extractible (ou non)
  des identifiants Windows/Chrome, et les pièges DPAPI/ctypes.
- `references/ovh-cold-reboot-api.md` — redémarrage à froid OVH par API
  (createToken zone EU, signature, reboot, suivi), quand le portail ne rend pas.
- `references/guest-shell-and-transfers.md` — livrer et exécuter un script dans
  la session invitée : gist + curl, URL raw vs raccourcisseur, caractères que
  `SendKeys` mange, console réelle vs ISE.
- `scripts/cdp_attach.py` — piloter l'onglet Chrome de l'utilisateur en CDP
  (navigation, lecture DOM, clic, saisie) sans toucher à ses autres onglets.
- `scripts/rdp_client_ctl.ps1` — focus fiable d'une fenêtre `mstsc`, clic sur
  le dialogue de sécurité, envoi de frappes depuis un fichier de séquences.
