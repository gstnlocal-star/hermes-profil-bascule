#!/usr/bin/env python3
"""Chiffre les envois réels vers une annonce, à partir des exports CSV du robot.

Usage : python compter_envois.py <dossier> <sous-chaine annonce> [--detail]

Un envoi réel = statut 'ok' ET motif commençant par 'confirme'. Les lignes
'dry-run' sont des formulaires remplis mais non soumis ; les échecs sont comptés
à part. Déduplication sur (annonce, ville, email, message) : les runs parallèles
du même robot réécrivent des lignes qui se chevauchent.

Lecture seule, utilisable pendant un run (aucun navigateur ouvert).
"""
import argparse
import csv
import glob
import os
import unicodedata
from collections import Counter


def norm(value):
    value = unicodedata.normalize("NFKD", value or "")
    return " ".join(value.encode("ascii", "ignore").decode().lower().split())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dossier")
    parser.add_argument("filtre", help="sous-chaine du nom d'annonce, accents optionnels")
    parser.add_argument("--detail", action="store_true", help="repartition par commune")
    args = parser.parse_args()

    motif_recherche = norm(args.filtre)
    vus, reels = set(), []
    dry_run = echecs = 0

    for chemin in sorted(glob.glob(os.path.join(args.dossier, "*.csv"))):
        with open(chemin, encoding="utf-8-sig", errors="replace", newline="") as flux:
            for ligne in csv.DictReader(flux, delimiter=";"):
                if motif_recherche not in norm(ligne.get("annonce")):
                    continue
                cle = tuple(norm(ligne.get(colonne)) for colonne in ("annonce", "ville", "email", "message"))
                if cle in vus:
                    continue
                vus.add(cle)
                statut = norm(ligne.get("statut"))
                motif = norm(ligne.get("motif"))
                if statut != "ok":
                    echecs += 1
                elif motif.startswith("dry-run"):
                    dry_run += 1
                else:
                    reels.append(ligne)

    communes = Counter(norm(ligne.get("ville")) for ligne in reels)
    print(f"envois reels: {len(reels)} | dry-run: {dry_run} | echecs: {echecs} | communes: {len(communes)}")
    if reels:
        horodatages = sorted(ligne["horodatage"] for ligne in reels if ligne.get("horodatage"))
        if horodatages:
            print(f"periode: {horodatages[0]} -> {horodatages[-1]}")
        else:
            print("periode: horodatages absents")
    else:
        print("periode: aucune")
    if args.detail:
        for commune, nombre in communes.most_common():
            print(nombre, commune)


if __name__ == "__main__":
    main()
