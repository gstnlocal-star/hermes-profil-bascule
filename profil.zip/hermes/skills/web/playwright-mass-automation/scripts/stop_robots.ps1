<#
Arrête des robots Playwright sur un PC Windows, proprement et durablement.

Ordre appliqué : boucles .bat (cmd parents) d'abord, puis les processus
python/pythonw/node/timeout restants, en passes répétées, avec observation
pour prouver que rien ne revient. -GuardSeconds > 0 tient l'arrêt en tuant
toute réapparition pendant la durée demandée.

Les processus de Hermes lui-même (gateway, kernel, browser harness) sont
toujours épargnés : tout CommandLine contenant « hermes » est ignoré.

Exemples :
  powershell -NoProfile -ExecutionPolicy Bypass -File stop_robots.ps1 -Match demarrer.py,clicker.py -GuardSeconds 600
  powershell -NoProfile -ExecutionPolicy Bypass -File stop_robots.ps1 -Match "msg spam","clic ads" -Passes 20
#>
param(
  [Parameter(Mandatory = $true)][string[]]$Match,
  [int]$Passes = 12,
  [int]$IntervalSeconds = 4,
  [int]$ObservationSeconds = 60,
  [int]$GuardSeconds = 0
)

$ErrorActionPreference = "SilentlyContinue"

function Get-Cibles {
  Get-CimInstance Win32_Process | Where-Object {
    $cl = $_.CommandLine
    if (-not $cl) { return $false }
    if ($cl -like "*hermes*") { return $false }
    if ($_.Name -notmatch "python|node|cmd|timeout") { return $false }
    foreach ($m in $Match) { if ($cl -like "*$m*") { return $true } }
    return $false
  }
}

function Stop-Cible($p) {
  taskkill.exe /PID $p.ProcessId /T /F | Out-Null
}

# 1. passes de kill : les cmd parents partent en premier
$kills = 0
for ($i = 1; $i -le $Passes; $i++) {
  $cibles = Get-Cibles
  foreach ($p in ($cibles | Where-Object { $_.Name -eq "cmd.exe" })) {
    Write-Output ("pass $i > kill cmd $($p.ProcessId)")
    Stop-Cible $p
    $kills++
  }
  $cibles = Get-Cibles
  foreach ($p in $cibles) {
    Write-Output ("pass $i > kill $($p.Name) $($p.ProcessId)")
    Stop-Cible $p
    $kills++
  }
  Start-Sleep -Seconds $IntervalSeconds
}

# 2. observation : on ne tue que ce qui réapparaît, en le signalant
$t0 = Get-Date
while (((Get-Date) - $t0).TotalSeconds -lt $ObservationSeconds) {
  Start-Sleep -Seconds 5
  foreach ($p in (Get-Cibles)) {
    Write-Output ("REAPPARU $($p.Name) $($p.ProcessId) :: $($p.CommandLine)")
    Stop-Cible $p
    $kills++
  }
}

# 3. garde optionnelle
if ($GuardSeconds -gt 0) {
  Write-Output ("=== garde active $GuardSeconds s (fin vers " + (Get-Date).AddSeconds($GuardSeconds).ToString("HH:mm") + ")")
  $t1 = Get-Date
  while (((Get-Date) - $t1).TotalSeconds -lt $GuardSeconds) {
    foreach ($p in (Get-Cibles)) { Stop-Cible $p; $kills++ }
    Start-Sleep -Seconds 3
  }
}

Write-Output "=== total tues: $kills"
$fin = Get-Cibles
if ($fin) {
  Write-Output "=== RESTE"
  $fin | ForEach-Object { Write-Output ("$($_.ProcessId) $($_.Name) :: $($_.CommandLine)") }
} else {
  Write-Output "=== PROPRE"
}
