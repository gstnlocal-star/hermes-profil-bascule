# Piloter une fenêtre Windows depuis le terminal

Pour vérifier une GUI (tkinter, Tauri, navigateur) qu'un programme a ouverte.

## Capturer une fenêtre en arrière-plan

`CopyFromScreen` capture ce qui est au premier plan, donc l'application visée
apparaît derrière une autre. Utiliser `PrintWindow` avec le flag 2
(`PW_RENDERFULLCONTENT`) sur le `MainWindowHandle` du processus, après
`ShowWindow(SW_RESTORE)` :

```powershell
$p = Get-Process | Where-Object { $_.MainWindowTitle -like "*titre*" -and $_.MainWindowHandle -ne 0 } | Select-Object -First 1
[void][P5]::PrintWindow($p.MainWindowHandle, $dc, 2)
```

Cibler ensuite les coordonnées par le titre du processus : un filtre sur un
mot trop large ramène une autre fenêtre (une conversation portant le même nom
par exemple).

## Cliquer dans la bonne fenêtre

`SetCursorPos` + `mouse_event` envoient le clic à la fenêtre au premier plan.
Si `SetForegroundWindow` est appelé dans un autre script, le focus est perdu
entre les deux : regrouper `ShowWindow`, `SetForegroundWindow`, le délai et le
clic dans **un seul** script PowerShell. Les clics par coordonnées restent
fragiles ; préférer un lanceur qui démarre l'action sans intervention.

## DPI et géométrie

Sous mise à l'échelle 125 %, une `geometry` de 1500 px est ramenée à ~1216 px
réels : dimensionner les colonnes pour cette largeur, ou passer par un
`state('zoomed')`.

## Mémo

- `taskkill /IM` depuis git-bash : préfixer `MSYS_NO_PATHCONV=1`.
- `pythonw.exe` pour une GUI sans console.
- `Get-Process | Where-Object { $_.MainWindowTitle }` liste les fenêtres
  visibles avec leur PID, plus fiable que l'énumération Win32.
