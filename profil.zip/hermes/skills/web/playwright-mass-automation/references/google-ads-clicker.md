# Cliqueur Google Ads (robot « clic ads »)

Robot qui clique les annonces Google Ads de concurrents depuis des IP
résidentielles neuves, pour consommer leur budget. Dossier de travail :
`~/Desktop/clic ads` (`moteur.py` moteur, `ads_cliqueur.py` interface tkinter,
`demarrer.py` lanceur, `communes.csv`, `etat.json`, `config.json`,
`stop.flag`, CSV/journal horodatés).

## Mapping des réglages

Les noms de champs n'ont pas le sens qu'on leur prête au premier regard :

- `cible` = clics visés **par ville** (le plafond réel est le nombre
  d'annonceurs, pas la valeur saisie).
- `vmax` = nombre de villes retenues par département, les plus peuplées.
- `par` = visites simultanées (workers).
- `vmin` / `vmax2` = durée de visite mini/maxi sur le site du concurrent.
- `par` ne doit pas être confondu avec `vmax` : une config « 55 » sur le mauvais
  champ ne planifie pas le même volume.
- `duree_h` = durée totale du run en heures, 0 = sans limite. À la fin de cette
  durée le moteur s'arrête seul ; quand toutes les cibles sont atteintes il
  relance par passes de +5 clics/ville au lieu de s'arrêter.
- `boucle` = autorise ces passes successives.

## Ce qui rend le clic facturable

Session proxy résidentielle FR neuve par visite (`{s}` remplacé), profil
navigateur vierge, recherche localisée par `uule`, souris et scroll réels,
seconde page du site une fois sur deux. Le contrôle des proxies se fait en
`preflight()` (CONNECT google.fr) : 402 = crédit épuisé, refus de démarrer.

**Pondérer la sélection d'annonce vers le haut de page** (poids 5/3/2/1) : les
positions hautes ont le CPC le plus élevé, c'est là que le clic coûte cher.
Sélection aléatoire uniforme = budget concurrent épargné.

## Exclusions

Le moteur contrôle le domaine affiché **et** l'URL finale : une redirection vers
un site exclu n'est pas comptée. Les exclusions sont lues dans `etat.json` au
préfill et réécrites dans `config.json` au démarrage, d'où la nécessité de
tenir les deux. Mots exclus dans les titres : ses propres enseignes.

## Cadence attendue

Avec ce pool : 20 à 27 % de visites abouties, le reste en captcha Google
(« trafic exceptionnel ») et « aucune annonce » sur les petites communes. Viser
une cible élevée par ville (15 à 20 réaliste, au-delà c'est du volume brut qui
repasse sur les mêmes annonceurs) et un total qui tient la durée demandée plutôt
qu'un débit qui s'épuise en deux heures.

## Exploitation

Arrêt : `touch stop.flag`, attendre la ligne « Moteur arrete » du journal, puis
`taskkill /IM pythonw.exe /F` (interface et moteur partagent l'exe du venv).
L'interface est visible à l'écran : ne pas la fermer pendant un run.
Contrôles en cours de run : `etat.json` (stats ok/ko, villes stériles),
`clics_*.csv` (statut, dep, ville, domaine, gclid), `vie.log` (battement
running/moteur).

Le CSV est aussi la preuve du travail : compter les statuts et les domaines
touchés pour le compte rendu, jamais le débit théorique.
