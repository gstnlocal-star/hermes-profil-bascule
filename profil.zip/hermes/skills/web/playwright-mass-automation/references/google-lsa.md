# Google Local Services Ads — cibles et signaux

Google insère un bloc « Annonces locales Service » (parfois titré
« Plombiers sponsorisé(e)s ») dans les résultats mobiles. Le bloc n'apparaît
que sur certaines enchères : 2 à 3 annonces maximum, souvent une seule, et
parfois aucune selon l'IP et le moment. Le volume vient donc des villes
balayées et des passages répétés, jamais d'une requête unique.

## Détection des cartes

Viser d'abord les liens `a[href*="/localservices/messaging"]` : ils portent le
href à ouvrir et ne dépendent pas d'un libellé peint. Le nom se lit via le lien
voisin `a[href*="/localservices/profile"]`, en remontant jusqu'à la carte qui
contient la note, puis en coupant avant ` 4,9 (43)`. Un repérage par nœud feuille
`MESSAGE` reste utile en secours (carrousels où le lien est absent), avec filtre
de taille pour éliminer les doublons invisibles.

## Formulaire et confirmation

Le clic ouvre un nouvel onglet `google.fr/localservices/messaging` : chercher le
premier `textarea` visible dans les pages du contexte, remplir, puis fermer
l'onglet dans un `finally`.

Champs réellement présents : message (obligatoire, 600 caractères), e-mail
(facultatif), téléphone (facultatif). Le bouton reste actif sans téléphone.

La confirmation s'affiche après 3 à 6 secondes : « Google a envoyé votre
demande et vous a mis en relation avec … », suivie de « Vérifiez vos e-mails ».
Attendre jusqu'à 30 s et tester ces formulations ; ne jamais conclure sur
« Envoyé » présent dans le titre du formulaire.

## Quotas et exclusions

- Google limite le nombre de messages par annonce ; prévoir une cible réglable
  (300 est un ordre de grandeur acceptable) et un compteur persisté par
  annonce et par ville.
- **La saturation fait couper la messagerie.** Ennuyés, ou coupés par Google
  faute de réponse, les annonceurs désactivent le bouton Message : l'annonce
  reste affichée des heures, mais on ne peut plus lui écrire. C'est la limite
  réelle du robot, pas un quota de compte.
- La même entreprise ressort sur des dizaines de villes : un compteur global
  la saturerait avant les autres, un compteur par ville non.
- Liste noire par mots normalisés (`sigle()` retire la ponctuation, donc
  « fibre & power » s'écrit « fibre power ») : ses propres sociétés doivent être
  filtrées avant tout envoi, et la vérifier sur les noms réellement rencontrés.
- Sur les métiers autres que la plomberie (serrurerie, chauffage), le bloc sort
  beaucoup moins souvent : ne pas promettre la même couverture.

## Savoir qui a coupé la messagerie

Question récurrente après une journée de saturation. Procédure :

1. Balayer les villes où l'on a réellement envoyé (30 suffisent) et, pour
   chacune, relever les noms affichés et ceux encore présents dans la sortie de
   l'extracteur `messaging`. Une annonce affichée mais absente de la sortie = messagerie coupée.
2. Confirmer sur la fiche : la page ne montre plus que `APPELER / PARTAGER /
   APERÇU`, sans `MESSAGE` ni `textarea`.
3. Recouper avec le CSV : la dernière ligne `ok` de l'annonce et le nombre
   d'échecs à 100 % après. Donner volume envoyé et heure de coupure par annonce.
4. Une annonce coupée est absente dans **toutes** les villes où elle sort ; un
   résultat mitigé (présente dans certaines) veut dire encore active ou
   artefact d'affichage, donc à vérifier avant de la citer.
5. Ne pas lister les annonces qui n'ont jamais eu de messagerie : jamais de
   bouton Message et jamais de ligne `ok` dans le CSV.
6. Dire la réserve : corrélation forte, cause non prouvée, et chiffrer ce que ça
   coûte (cibles perdues) ; proposer de baisser la cible par annonce.

**Faux négatif à éviter** : la page de consentement et la page « trafic
exceptionnel » renvoient zéro lien et ressemblent à « aucune annonce ». Une
soixantaine de requêtes depuis la même IP locale déclenche la seconde. Lire le
texte de la page avant de conclure, écarter la ville et la refaire plus tard au
lieu de la compter comme vide.
