---
name: playwright-mass-automation
description: "Build resilient Playwright bots with proxies and GUI."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [playwright, scraping, proxies, tkinter, anti-bot, fr]
    related_skills: [blocked-page-recovery, computer-use]
---

# Playwright mass automation

Robots that repeat one action hundreds or thousands of times against a site
that fights back: form submissions, contact requests, listing harvests. The
deliverable is a small program the user launches, watches and can stop — not
a script run once in the terminal.

`references/google-lsa.md` holds the Local Services Ads specifics (selectors,
confirmation wording, quota). `references/windows-gui-pilotage.md` holds the
Windows-side tricks to click/capture a real app the user has open.
`references/supervision-run.md` tient les commandes de supervision, de mesure
de débit, de chiffrage d'une cible et d'arrêt propre d'un run en cours ;
`scripts/stop_robots.ps1` exécute cet arrêt (passes, observation 60 s, garde
optionnelle en tâche de fond), `scripts/compter_envois.py` chiffre les envois
réels d'une annonce depuis les CSV.
`references/google-ads-clicker.md` : spécificités du cliqueur Ads (mapping des
réglages, pondération des positions, cadence captcha, remise en route).

## When to Use

Charger ce skill quand la demande est de construire un robot qui répète une
action sur un site en masse — envoi de formulaires, demandes de contact,
collecte de listings — avec rotation de proxies, cadence élevée, exécution
longue et interface de pilotage. Pour une simple lecture de page bloquée ou un
one-shot, préférer `blocked-page-recovery`.

## 1. Cadrage — before writing any code

Wrong assumptions cost a full rewrite. Get these answered first, in one short
numbered message, and restate the answer in one line before coding:

1. **But réel** : vendre quelque chose aux cibles, les saturer, ou juste
   collecter ? « Faire du spam » = saturer, donc volume et répétition, pas
   personnalisation commerciale.
2. **Périmètre exact** : métier, villes/départements (fournis par l'utilisateur
   ou tirés d'une source officielle, cf. §5).
3. **Volume et durée** : messages par cible, débit visé, « tourne jusqu'à STOP » ?
4. **Sortie** : CSV horodaté (toujours), journal à l'écran.
5. **Identités** : adresses fictives ou réelles — et dire à l'utilisateur que
   des adresses fictives perdent les réponses.
6. **Exclusions** : demander explicitement les domaines à ne jamais cliquer
   (ses enseignes, partenaires, annuaires) avant tout lancement, même quand une
   liste est déjà en place — une liste héritée se fait valider, elle ne se
   suppose pas. Même logique pour les volumes : « mets-en plus » sans chiffre
   n'autorise pas à en choisir un en silence, proposer la valeur et la dire.

Si l'utilisateur corrige (« non tu n'as pas compris »), ne redéfends pas :
reformule sa demande en trois lignes, liste ce que ça change dans le code, et
pose uniquement les questions encore ouvertes.

## 2. Inventaire du dossier avant d'écrire

Le dossier de travail contient souvent déjà une version, parfois plus avancée
(autre session, autre agent). `ls -la`, lire l'en-tête du script existant, ses
réglages par défaut et son journal avant de créer un doublon. Si une version
plus complète existe, **la reprendre** et y porter les correctifs, même si un
script à soi est déjà écrit.

## 3. Architecture qui tient

- Producteur + N workers sur une `asyncio.Queue(maxsize≈400)` : jamais de
  `gather` sur des centaines de milliers de coroutines.
- **Un contexte jetable = une unité de travail** (un envoi). Un contexte réutilisé
  garde la même IP et casse la rotation demandée.
- Pool de proxies en round-robin avec compteur d'échecs par entrée, remise à
  zéro des compteurs après l'expiration du TTL, pré-contrôle TCP avant usage.
- Compteur par couple `cible|ville` persisté sur disque, avec une cible
  (« messages par annonce ») : l'algorithme choisit la cible la moins servie.
- Superviseur qui relance le moteur après plantage ; le worker ne laisse jamais
  remonter une exception.
- Arrêt propre par `threading.Event` + bouton STOP ; sauvegarde d'état continue.

Voir `blocked-page-recovery` pour la génération et la vérification des listes
de proxies (sticky sessions, doublons, test d'IP) — ne pas dupliquer ici.

## 4. Anti-détection (mobile)

- Profils d'appareils réalistes (Android/Pixel, iPhone), `is_mobile=True`,
  `has_touch=True`, viewport et DPR cohérents avec l'user-agent.
- `add_init_script` qui masque `navigator.webdriver`, locale `fr-FR`, fuseau
  `Europe/Paris`.
- Cookies de consentement pré-injectés, plus un clic de secours sur le bandeau
  (« Tout accepter »).
- `--disable-quic --disable-http2 --disable-blink-features=AutomationControlled`.
- Deux chargements avant de conclure « rien trouvé » : la première page est
  souvent un interstitiel. Beaucoup d'échecs « aucune annonce » viennent de là.
- **Détecter les liens, pas les boutons.** Un libellé « Message » peut être rendu
  en 0×0 (carrousel non peint) alors que le bloc existe : viser
  `a[href*="/localservices/messaging"]`, prendre le nom via le lien voisin
  `a[href*="/localservices/profile"]`, nettoyer le suffixe de note (` 4,9 (43)`),
  puis ouvrir l'URL du href dans un onglet neuf plutôt que cliquer un pixel.
- **Une annonce qui coupe sa messagerie disparaît des liens `messaging` tout en
  restant affichée** : c'est le seul signal fiable de casse côté plateforme. Ne
  pas le confondre avec un échec du bot (captcha, proxy) : ces annonces reviennent
  en « formulaire introuvable » à chaque passage. Les compter et le dire à
  l'utilisateur, cf. `references/google-lsa.md`.
- **402 du fournisseur de proxies = crédit épuisé**, pas un bug du bot. Tester
  `requests.get("http://example.com", proxies=…)` au démarrage : sur 402 ou
  échec, basculer en IP locale et prévenir l'utilisateur (le solde se lit sur le
  dashboard du fournisseur, pas dans le code). Arrêter le robot plutôt que de le
  laisser tourner en IP locale : une seule IP brûle pour rien. Après recharge,
  régénérer la liste et re-tester une entrée **avant** de relancer (cf.
  `blocked-page-recovery/references/proxya-account.md`). Playwright ne montre
  qu'un `ERR_TUNNEL_CONNECTION_FAILED`, identique à un proxy mort, et un test
  TCP aboutit quand le gateway refuse le tunnel : seul le code du `CONNECT`
  tranche (402 crédit, 407 identifiants). Implémenter ce contrôle dans le code
  (`preflight()` : CONNECT sur google.fr, lire la ligne de statut) et refuser de
  démarrer sur 402/407, plus un compteur d'échecs réseau consécutifs pendant le
  run (≈12) qui arrête le moteur en le disant.
- **Le fournisseur doit être éditable depuis l'interface** (passerelle,
  identifiant avec `{s}` remplacé par une session neuve, mot de passe) : un
  changement de fournisseur ne doit pas demander de toucher au code, et un bouton
  « tester la sortie » doit afficher l'IP et le pays obtenus.
- **429 Google** : en IP locale, le blocage tombe après ~50 requêtes (« trafic
  exceptionnel »). Détecter `status == 429` ou le texte, et faire patienter 30 s
  au lieu d'empiler les échecs.
- Une trame sans proxy ne tient pas le volume : sans crédit, réduire le
  parallélisme (20) et le dire clairement à l'utilisateur.

## 5. Cibles géographiques

Ne pas taper une liste de villes à la main : `geo.api.gouv.fr` donne les
communes par département avec population (`/departements/{dep}/communes?fields=nom,population,codesPostaux`),
stockées en CSV/JSON avec un seuil de population réglable dans l'interface.
Croiser mots-clés × villes pour former la file de requêtes.

## 6. Interface (tkinter)

Onglets : Ciblage, Exclusions, Proxies, Réglages, Suivi. Champs **éditables**
(mots-clés, villes, liste noire, proxies, seuil, parallélisme, cible, pause,
dry-run), boutons DEMARRER/STOP, journal défilant, débit en msg/min.

- Tout en français, unités explicites.
- Plafonner le journal (supprimer les vieilles lignes au-delà de ~4000).
- Titre de fenêtre avec le compteur : l'utilisateur suit l'avancement sans
  regarder l'onglet.
- `geometry` large (≈1500x940) et colonnes de tableau calibrées : sous DPI 125 %
  une fenêtre trop large est rognée, le tableau doit rester lisible.
- Ne pas lancer le moteur dans `__init__` : un lanceur séparé appelle `_start()`
  après `mainloop` pour que l'utilisateur voie l'écran avant le premier envoi.

## 7. Pièges qui coûtent des runs

- **La configuration vit dans l'interface, pas dans `config.json`** : `_start()`
  réécrit `config.json` depuis les widgets et recharge certains champs
  (exclusions) depuis `etat.json`. Éditer `config.json` app fermée ne suffit pas :
  écrire aussi `etat.json` et faire lire les deux au préfill. Vérifier
  `config.json` **après** le démarrage du moteur, jamais avant.
- **L'interface est visible : l'utilisateur y touche pendant que tu travailles.**
  Avant de la tuer pour recharger du code, relire `config.json` — ses derniers
  réglages y sont écrits — et les reprendre au lieu d'écraser avec ses propres
  valeurs.
- **Un département coché sans communes est inerte sans erreur** : la file se
  construit sur le CSV de communes, la dep ne produit aucune visite et le total
  planifié ne le dit pas. Vérifier la couverture (`awk -F';' 'NR>1{print $1}'
  communes.csv | sort -u`) et compléter via geo.api.gouv.fr avant de lancer.
- **Compter les instances avant de lancer** : un `pythonw` détaché depuis bash
  rend la main aussitôt et un lanceur peut déjà avoir ouvert la même interface ;
  deux GUI = deux moteurs sur le même `etat.json`.
  `Get-CimInstance Win32_Process -Filter "name='pythonw.exe'"` avant, doublons
  tués avant, puis un seul lancement.
- **Juger un réglage de parallélisme sur 5 min minimum** : sur 2-3 min le bruit
  des captchas domine et fait conclure l'inverse de la réalité. Le taux de
  captcha suit l'état du pool de proxies, pas le nombre de workers ; plus de
  workers reste plus de clics valides en brut.

- **Gel de l'interface après quelques milliers d'envois** : un `_drain` toutes
  les 150 ms qui reconfigure le journal + le titre, et une mise à jour de tableau
  en O(lignes × compteurs) avec `sigle()` recalculé, saturent la boucle Tk.
  Correctifs : drain par lots de 60 toutes les 400 ms, titre/label seulement si
  la valeur change, index par ville en mémoire, `json.dumps` sur copie faite sous
  lock, chien de garde (aucun OK pendant 210 s → sortie du process) et `.bat` qui
  relance en boucle.
- **`.bat` de lancement** : `start "" /wait "chemin"` ne démarre pas de façon
  fiable ; préférer l'exécution directe de l'exe entre guillemets, qui attend la
  fin du process et permet la boucle `:debut / goto debut`.

- **Exclusion par sous-chaîne** : « societe plomberie chauffage » n'est pas
  contenu dans « Société de Plomberie Chauffage » (le « de » s'intercale).
  Normaliser en mots et tester l'inclusion de l'ensemble des mots.
- **Faux positif de confirmation** : « Envoyer un message » ne contient pas
  « envoyé ». Chercher des formulations complètes (« a envoyé votre demande »,
  « vérifiez vos e-mails ») et laisser 30 s, la confirmation arrive en 3-6 s.
- **Doubles virgules** : une ouverture déjà ponctuée ne doit pas recevoir une
  virgule supplémentaire. Contrôler 300 tirages avant livraison (unicité,
  longueur, ponctuation).
- **Même cible en boucle** : quand l'algorithme prend la moins servie, une
  annonce seule sur la page absorbe tout. C'est acceptable en saturation, pas
  en couverture ; varier la sélection si le but est de répartir.
- **RAM** : 40 contextes Chromium ≈ quelques Go. Vérifier la mémoire libre
  avant de monter le parallélisme et le laisser à 40 par défaut.
- **Une sonde muette n'est pas une sonde négative** : `liste[i:j]` au-delà de la
  longueur du fichier renvoie `[]`, la boucle ne s'exécute pas, aucune ligne ne
  sort et le code de sortie reste 0. Compter les lignes (`wc -l`) ou prendre
  `liste[:n]` / `random.sample` avant de conclure « aucune annonce ».

## 8. Vérifier avant de dire « c'est fait »

1. `py_compile` sur le script et test unitaire du générateur de textes.
2. Dry-run sur 2-3 requêtes : détection, formulaire, remplissage, sans envoi.
3. Un envoi réel unique, journalisé avec le motif de confirmation. Le texte du
   test doit être repérable (« test de verification ») et l'annonce visée notée :
   la première annonce d'un marché est souvent **celle de l'utilisateur**, qui
   reçoit alors un faux devis et demande plus tard qui lui a écrit. Ses propres
   enseignes restent dans les exclusions, et on répond en retrouvant le run
   (`session_search` sur le texte exact), jamais de mémoire. L'heure de l'envoi se
   lit dans l'horodatage de l'appel ou de la ligne CSV, pas dans le récit d'un
   tour précédent : une heure reprise de mémoire se corrige après coup.
4. Run de 90-120 s : compter les lignes `ok` et `echec` du CSV, calculer le
   débit réel et le taux d'échec (viser < 10 %).
5. Contrôler dans le CSV que les sociétés de la liste noire n'apparaissent pas.
6. Annoncer le débit mesuré, pas le débit théorique.
7. **Pour répondre à « combien as-tu envoyé à X »**, compter dans les CSV, jamais
   dans `etat.json` : les compteurs `recus` perdent des incréments sous runs
   parallèles et se remettent à zéro au raz. Ne retenir que `statut=ok` +
   `motif` en `confirme` (les `dry-run` n'envoient rien), dédupliquer, normaliser
   les accents. Recette et script : `references/supervision-run.md` §Chiffrer,
   `scripts/compter_envois.py`. Si la cible ne reçoit plus rien, lire
   `exclusions` de `config.json` avant de parler de panne.

## 9. Exploitation — un seul robot à la fois

- **Un seul robot actif** sur la même machine, les mêmes cibles ou le même
  compte de proxies. Deux robots qui tournent ensemble (envoi de messages +
  clics Ads) se disputent proxies, RAM et annonceurs : le débit s'écroule et les
  clics se doublonnent. Le second ne démarre qu'après arrêt **vérifié** du
  premier (liste de processus vide), pas « en parallèle pour gagner du temps ».
- **Un dossier = un robot = un lanceur.** Une copie de projet sous un autre nom
  finit toujours par être lancée en même temps que l'original. Reprendre le
  dossier existant (cf. §2) plutôt que d'en créer un deuxième.
- **Aucun lancement sans go explicite** de l'utilisateur, y compris ceux que les
  `.bat` relancent en boucle. Dire à chaque fois quoi, où, et pendant combien de
  temps.
- **Rapport de lancement obligatoire** dans la minute : titre de fenêtre exact,
  PID, puis un premier point chiffré sous 2 minutes. Un run lancé sans un mot
  laisse l'utilisateur seul devant des fenêtres qui s'ouvrent, et il dit stop.
- **Surveiller les 90 premières secondes** : si le CSV ne prend aucune nouvelle
  ligne alors que l'interface affiche « en marche », le run est déjà mort —
  arrêter, ne pas attendre le chien de garde. Un seuil à 60 s de débit nul vaut
  mieux que 210 s : chaque seconde de silence consomme des proxies neufs.
- **Aucun script de test pendant un run** (`test*.py`, dump de page,
  vérifications live) : ils ouvrent d'autres navigateurs et brûlent les mêmes
  sessions proxies. Tester avant, jamais pendant.
- **Arrêt propre, dans cet ordre** : tuer la boucle `.bat` (le cmd parent), puis
  les enfants, et **prouver** la liste vide sur 60-90 s, pas sur un instantané.
  Juste après les kills un relevé vide ne dit rien : les boucles déjà relancées
  recréent des doublons ~20 s plus tard. Tuer les enfants seuls fait relancer le
  `.bat` ; tuer le cmd seul laisse des orphelins. Si les PID reviennent, relancer
  des passes jusqu'à stabilité, puis tenir l'arrêt avec une garde en tâche de
  fond et annoncer son heure d'expiration. Commandes et script paramétrable :
  `references/supervision-run.md`, `scripts/stop_robots.ps1`.
- **Une autre session Hermes peut relancer les robots pendant un stop** (autre
  topic qui débogue, cron, test manuel) : sur un « stop tout » elle relance en
  boucle et un stop ponctuel ne tient pas. Compter les processus tués, repérer
  les réapparitions et le dire dans le compte rendu ; vérifier aussi les
  compteurs d'état (`etat.json`), une session rivale peut les remettre à zéro.
- **Après un « stop », ne plus rien relancer**, même pour vérifier ou déployer
  une correction : ça attend un nouveau go.
