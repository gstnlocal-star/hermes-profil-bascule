---
name: blocked-page-recovery
description: "Use when a fetch fails: 403/429, paywall, WAF, bot wall."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Research, Archives, Wayback, Paywall, WAF, Fallback]
    related_skills: [grounded-citations]
---

# Blocked-Page Recovery

When a page won't fetch — 403/429, Cloudflare "Just a moment...", a paywall,
or a bot-detection interstitial — don't give up and don't loop on the same
URL. Third-party services often hold a **copy** of the page. Work down this
ladder, cheapest first.

## The ladder

```
1. Wayback Machine  — archive.org "available" API  (snapshot + timestamp)
2. archive.today    — domain rotation: archive.ph → .md → .li → .is
3. Jina Reader      — only if JINA_API_KEY is set  (live server-side render)
4. API-first pivot  — look for /api/, /graphql, .json, or RSS on the same host
5. Real browser     — browser tool as the last, most expensive resort
```

Run it in one shot with the bundled script:

```bash
python3 scripts/recover_page.py "https://example.com/blocked-article" --json
```

The script tries each route in order, validates every body (see "Fake
successes" below), and prints the first genuine hit with its provenance.

## Provenance discipline (non-negotiable)

Every recovered copy carries a provenance you MUST preserve when citing:

| Route | Provenance | How to cite |
|-------|-----------|-------------|
| Wayback / archive.today | `snapshot` | Cite WITH the snapshot date: "as archived 2026-08-06". Never present a snapshot as the live page — it may be stale. |
| Jina Reader | `live` | Server-side re-render of the live page; cite normally. |
| Live fetch / browser | `live` | Cite normally. |

If the user needs *current* data (prices, availability, breaking news), a
snapshot is context, not an answer — say so explicitly and note its age.

## Manual routes

### 1. Wayback Machine (best provenance, try first)

```bash
# Discovery: returns closest snapshot URL + timestamp as JSON
curl -sL "https://archive.org/wayback/available?url={URL}"
# Then fetch archived_snapshots.closest.url
```

For enumerating many snapshots (or recovering deleted pages), the CDX index:

```bash
curl -sL "https://web.archive.org/cdx/search/cdx?url={URL}&output=json&limit=10"
```

CDX intermittently returns 503 under load — if it does, fall back to the
`available` API; don't retry-hammer it.

Works for: any publicly crawled URL. Fails for: robots-blocked sites,
never-crawled URLs, JS-only SPAs (snapshots don't render).

### 2. archive.today (paywalls, deleted content)

User-submitted archives — often has paywalled news articles Wayback lacks.
Rate-limits aggressively (429) and rotates domains, so iterate:

```bash
for d in archive.ph archive.md archive.li archive.is; do
  curl -sL --max-time 20 "https://$d/newest/{URL}" -o ~/.hermes/cache/scratch/page.html \
    -w "%{http_code}" && break
done
```

**Validate the body, not the status code** — a 429 still ships several KB of
rate-limit HTML that looks like a success to a size check alone.

### 3. Jina Reader (requires JINA_API_KEY)

`r.jina.ai` re-renders the live page in a real browser server-side and
returns markdown. Anonymous access is dead (401 → Turnstile); a key is
required:

```bash
curl -s -H "Authorization: Bearer $JINA_API_KEY" "https://r.jina.ai/{URL}"
```

Handles JS SPAs that archives can't. Skip this route entirely when the env
var is unset.

### 4. API-first pivot

WAFs protect the HTML surface far more aggressively than the data endpoints
behind it. After 2-3 blocked attempts on a site, stop fighting the HTML and
look for:

- `/api/...`, `/graphql`, or `.json` variants of the page URL
- An RSS/Atom feed (`/feed`, `/rss`, `<link rel="alternate">` in any copy
  you did recover)
- A sitemap (`/sitemap.xml`) revealing canonical URLs that may not be gated

## Fake successes — routes that LIE

These return HTTP 200 with a plausible body that is NOT the page. The script
rejects them automatically; reject them manually too:

- **Google Cache is dead** (since mid-2024). `webcache.googleusercontent.com`
  returns 200 + tens of KB, but it's a Google Search interstitial with a JS
  redirect, not a cache. Never use it.
- **AMP caches** (`*.cdn.ampproject.org`) mostly return a ~300-byte
  `<title>Redirecting</title>` meta-refresh stub pointing back at the
  original (blocked) URL. Treating that as success creates a fetch loop.
- **Rate-limit bodies**: archive.today 429 pages are multi-KB HTML. Check for
  the target's actual content (title words, expected strings), not just size.

Detection heuristics the script applies: body under a per-route byte floor;
meta-refresh/JS-redirect stubs whose target is the original host; interstitial
titles ("Just a moment", "Redirecting", "Google Search", "Attention Required").

## Proxy relays, and country-restricted sites

Generic "web proxy" relays are man-in-the-middle by construction. Never send
cookies or Authorization headers through one, and don't use them for anything
the user will rely on — provenance is unverifiable. Prefer archives, which at
least timestamp their copies.

The exception: a proxy the user supplies on purpose (residential/datacenter
with credentials, often country-pinned) is the correct route for a site that
only answers from that country. Keep the credential out of the command line
when you can and strip `-x` from anything you paste back.

```bash
curl -sk -m 40 -x "http://USER:PASS@HOST:PORT" "https://site.fr/" -o out.html \
  -w '%{http_code} %{size_download}\n'
```

- `-k` is required: these proxies MITM TLS, so `curl` dies on the certificate
  before reaching the origin.
- Sanity-check the tunnel first (`https://api.ipify.org`) so a proxy failure and
  an origin failure don't look the same.
- Distinguish the failure codes: a proxy that rejects the credentials answers
  `407` or an auth page of its own; a `402` means the account is out of traffic —
  the proxies are valid, the quota is gone, so regenerating the list changes
  nothing until it is topped up; a `401` from the origin means the proxy
  worked and the site still refuses (bot wall, geo-allowlist, login).
- Read the provider's GB balance before re-issuing a list, and re-test one entry
  after a top-up: a `Generate` performed on an empty balance produces a full
  list of dead proxies that looks perfectly normal.
- `references/proxya-account.md`: solde, recharge crypto (Heleket), regeneration
  de liste et verification, pour le fournisseur residentiel d'Eric.
- A country proxy also proves nothing about the *current* state of a page that
  was archived earlier — cite it as live, never as a snapshot.
- If the origin 401s even through the country proxy, stop there and pivot to
  open data on the same regulator (`extranet.arcep.fr/uploads/*.csv` beats the
  consumer-facing lookup tool every time).

### Vendor dashboards that "generate" proxies

A generated list is not 500 different IPs. Rotation vendors encode the sticky
session in the username, e.g.
`user-country-FR-session-<id>-ttl-10:pass`, and emit the same
`host:port:user-pass` line hundreds of times until you scrape the per-session
list. Without the `-session-…-ttl-…` suffix every request exits a different IP,
which breaks a flow that must keep one identity for several minutes.

- Generate in the vendor dashboard with the country filter set, copy the list
  into a file, then `sort -u` and count before trusting it. A 500-line file
  that yields one unique line is a bug, not a pool.
- Verify a fresh batch by fetching `https://api.ipify.org` through the first
  entry and checking the country; do it before the first real run.
- Long `curl`/Playwright jobs: pre-check each proxy once (cheap HEAD), drop the
  dead ones, and use a new one per unit of work instead of retrying on a dead
  entry.
- Sticky sessions expire on their TTL — re-issue the credential rather than
  replaying one that has aged out since it was written.
