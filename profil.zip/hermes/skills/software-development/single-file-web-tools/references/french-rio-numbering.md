# RIO and French Numbering

Domain notes for building anything around portability (RIO) in France.

## RIO structure

12 characters, `OO Q RRRRRR CCC`, alphabet `A-Z 0-9 +`.

- `OO` — donor operator prefix. Mobile prefixes are two digits (Orange `01`,
  SFR `02`, Bouygues `03`, Free `04`, then one per MVNO). Fixed prefixes are
  `F0`–`ZZ` and `Q` is operator-specific instead of `P`/`E`.
- `Q` — `P` (particulier) or `E` (entreprise) on mobile.
- `RRRRRR` — contract reference chosen by the operator. Not derivable: this is
  the unknown in any reconstruction.
- `CCC` — check key, always computed, never guessed.

## Key algorithm (verified against three independent implementations)

Coding table, 37 symbols in this order:
`ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+`

Input = the first 9 characters of the RIO + the 10-digit national number (19 chars).

```
a = b = c = 0
for each char: p = index in table
  a = (a + p) % 37 ; b = (2*b + p) % 37 ; c = (4*c + p) % 37
key = table[a] + table[b] + table[c]
```

Sources: ARCEP decision 2021-0532 for the field structure; the public key
routine on the French Wikipedia article; cross-checked against the JS of
`kpym.github.io/verificateur-rio` and the igoflex RIO widget. All three agree
character for character.

## Numbering facts — authoritative, not guessed

- Operator of a block: `https://extranet.arcep.fr/uploads/MAJNUM.csv`
  (`EZABPQM;Tranche_Debut;Tranche_Fin;Mnemonic;Territoire;Date`), semicolon
  separated, latin-1. Grep the range containing the number; the mnemonic gives
  the operator (`FRMO` = Free Mobile, `FRTE` = Orange, `SFR0` = SFR…).
- RIO prefixes: `https://extranet.arcep.fr/uploads/MAJRIO.csv` — **fixed
  prefixes only**; mobile prefixes come from the ARCEP allocation decisions and
  the public operator table, not from this file.
- Portability register: `https://extranet.arcep.fr/uploads/MAJPORTA.csv`.
- `www.monreseaumobile.fr` (ARCEP consumer lookup) answers 401 to a bare `curl`
  even through a French proxy, and its cert warns in Chrome. Do not spend time
  on it: the extranet CSVs answer the same question and are citable.
- Cross-check of the operator (attribution, not current): bitcall.io's free
  checker takes the number in a `tel` input and prints the allocating operator.

## The oracle problem — say it out loud

Every reference yields a valid key, so a scan produces N well-formed candidates
and no way to tell which one exists. No public service confirms a reference
(igoflex, kpym and friends only re-run the key maths). Only the donor operator's
system does, at the portability request. So:

- deliver the candidate list (TXT, one RIO per line) plus the type variants;
- tell the user the prefix changes if the line was already ported;
- remind them the 3179 IVR or the invoice gives the RIO directly when the line
  is still reachable.

Reference spaces: numeric references are 10^6 (about a second of compute), the
full alphabet is 37^6 ≈ 2.5e9 and needs a mask on the known leading characters.

## Vocabulary

`OO Q RRRRRR CCC`, préfixe opérateur donneur, référence de contrat, clé de
contrôle, portabilité, relevé d'identité opérateur, opérateur receveur.
