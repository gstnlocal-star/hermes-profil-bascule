# Browser Verification Loop

How to prove a built page actually works, without breaking the user's session.

## Order

1. **Load once**, on a tab that already exists if the user opened one.
2. Exercise the smallest meaningful case first (a 300-row range, not the full
   million): fill fields, dispatch `input` events so listeners run, click run.
3. **Assert on data, not on screenshots.** Pull `state.results` and recompute
   every key with the naive function kept in the page:

```python
print(js("""(() => {const rs=state.results, num='06...'; let bad=0;
  for (const r of rs) if (calcKey(r.rio.slice(0,9), num) !== r.rio.slice(9)) bad++;
  return {n: rs.length, bad, uniq: new Set(rs.map(r=>r.rio)).size};})()"""))
```

Expect `bad: 0`, `uniq == n`, and lexicographic ordering from the first to the
last item. A count that matches the expected combination count is the third
signal.
4. **Cross-validate outside the app** for anything checksummed: an independent
   implementation (another site's JS, a Python rewrite) on the same inputs.
5. **Exports and copy**: click, then read the file back from the download
   folder and compare the first lines and line count. Only one download per page
   is auto-allowed.
6. **Scale test** last: full range, note the throughput, confirm the result cap
   and the stop button both hold.
7. **Screenshot + `vision_analyze`** for layout, then report.

## Resetting a run

`location.reload()` clears state; the page may also persist inputs in
`localStorage`, so clear it (`js("localStorage.clear()")`) when a stale mode or
value would skew a test, then reload once.

## Assertions before saying "done"

- one execution of every mode, not just the default
- zero key mismatches on a random sample of at least 2 000 rows
- exports open and hold the right line count
- the invalid path is rejected (wrong key, wrong length, bad prefix)
- `grep` shows no external URL in the delivered file
- no console error survived the run
