#!/usr/bin/env python3
"""Generate RIO candidates for a French number and verify their keys.

Usage:
  python3 gen_rio_candidates.py 04 P 0766366664 out.txt [--from 000000] [--to 999999]
  python3 gen_rio_candidates.py 04 E 0766366664 - --mask 'AB??EF'

The naive ``key`` function is the oracle: ``--check`` re-verifies a sample of
an existing file against it. Stdlib only, ASCII output, one RIO per line.
"""
import argparse
import random
import sys

ORDRE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+"
IDX = {c: i for i, c in enumerate(ORDRE)}


def key(base9: str, num: str) -> str:
    """Naive reference implementation of the RIO check key."""
    a = b = c = 0
    for ch in base9 + num:
        p = IDX[ch]
        a = (a + p) % 37
        b = (2 * b + p) % 37
        c = (4 * c + p) % 37
    return ORDRE[a] + ORDRE[b] + ORDRE[c]


def parts(s: str):
    a = b = c = 0
    for ch in s:
        p = IDX[ch]
        a = (a + p) % 37
        b = (2 * b + p) % 37
        c = (4 * c + p) % 37
    return a, b, c


def scan(prefix: str, q: str, num: str, lo: int, hi: int, alphabet: str, mask=None):
    """Yield (ref, rio) with the key already attached. Fast path: weight tables."""
    base9 = prefix + q
    a0, b0, c0 = parts(base9)
    aN, bN, cN = parts(num)
    b0 = b0 * pow(2, 16) % 37
    c0 = c0 * pow(4, 16) % 37
    WB = [[k * pow(2, 15 - s) % 37 for k in range(37)] for s in range(6)]
    WC = [[k * pow(4, 15 - s) % 37 for k in range(37)] for s in range(6)]

    if mask is None:
        for n in range(lo, hi + 1):
            v = [26 + (n // 10 ** (5 - s)) % 10 for s in range(6)]
            a = (a0 + aN + sum(v)) % 37
            b = (b0 + bN + sum(WB[s][v[s]] for s in range(6))) % 37
            c = (c0 + cN + sum(WC[s][v[s]] for s in range(6))) % 37
            ref = "".join(ORDRE[x] for x in v)
            yield ref, base9 + ref + ORDRE[a] + ORDRE[b] + ORDRE[c]
        return

    slots = [[IDX[ch]] if ch != "?" else [IDX[x] for x in alphabet] for ch in mask]
    cur = [0] * 6
    while True:
        v = [slots[s][cur[s]] for s in range(6)]
        a = (a0 + aN + sum(v)) % 37
        b = (b0 + bN + sum(WB[s][v[s]] for s in range(6))) % 37
        c = (c0 + cN + sum(WC[s][v[s]] for s in range(6))) % 37
        ref = "".join(ORDRE[x] for x in v)
        yield ref, base9 + ref + ORDRE[a] + ORDRE[b] + ORDRE[c]
        d = 5
        while d >= 0 and cur[d] == len(slots[d]) - 1:
            cur[d] = 0
            d -= 1
        if d < 0:
            return
        cur[d] += 1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("prefix")
    ap.add_argument("q", choices=["P", "E"])
    ap.add_argument("num")
    ap.add_argument("out", help="output file or - for stdout")
    ap.add_argument("--from", dest="lo", default="000000")
    ap.add_argument("--to", dest="hi", default="999999")
    ap.add_argument("--mask", help="6 chars, ? = any; forces --alpha")
    ap.add_argument("--alpha", choices=["num", "full"], default="num")
    ap.add_argument("--cap", type=int, default=0, help="0 = no cap")
    ap.add_argument("--check", metavar="FILE", help="verify an existing file instead")
    a = ap.parse_args()

    if a.check:
        rows = open(a.check, encoding="ascii").read().split("\n")
        bad = sum(1 for r in random.sample(rows, min(3000, len(rows))) if key(r[:9], a.num) != r[9:])
        print(f"{len(rows)} lignes, {len(set(rows))} uniques, {bad} cles fausses")
        return 0 if bad == 0 else 1

    alphabet = "0123456789" if a.alpha == "num" else ORDRE
    out = []
    for i, (_ref, rio) in enumerate(scan(a.prefix.upper(), a.q, a.num,
                                        int(a.lo), int(a.hi), alphabet, a.mask)):
        out.append(rio)
        if a.cap and len(out) >= a.cap:
            break
    text = "\n".join(out)
    if a.out == "-":
        print(text)
    else:
        open(a.out, "w", encoding="ascii").write(text)
        bad = sum(1 for r in random.sample(out, min(3000, len(out))) if key(r[:9], a.num) != r[9:])
        print(f"{len(out)} candidats, {len(set(out))} uniques, {bad} cles fausses -> {a.out}")
        print(f"premier {out[0]} dernier {out[-1]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
