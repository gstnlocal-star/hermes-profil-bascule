---
name: audit-concurrent-google-ads
description: Disséquer un concurrent ou auditer un compte Google Ads.
---

# Auditer la stratégie Ads d'un concurrent

Objectif : prouver où un concurrent achète du trafic, à quel coût, avec quels actifs, et où il est attaquable. Toujours séparer faits mesurés / estimations / recommandations.

## When to Use
- "Comment se fait-il qu'il soit en haut de page ?", "décortique sa stratégie", "pourquoi il paie si peu" : audit d'un concurrent.
- "Qu'est-ce que j'améliore dans mes campagnes", "où chasser" : audit du compte de l'utilisateur et analyse de trous de couverture.
- Avant de proposer une campagne miroir sur un concurrent ou une extension de zone.

## 1. Prouver ou écarter la piste payante
- Centre de transparence : `adstransparency.google.com/?region=FR&domain=<domaine>` puis cliquer l'annonceur.
  - Lire le nombre d'annonces, les dates de première et dernière diffusion, le format, les impressions par création.
  - Plusieurs comptes annonceurs pour un même domaine = portefeuille / comptes multiples.
- Le domaine ciblé par les annonces est souvent le site fil rouge : vérifier les autres domaines du même annonceur via une recherche du numéro de téléphone entre guillemets.
- Absence dans les 10 premiers résultats organiques sur 2-3 requêtes métier = SEO négligeable, donc tout le trafic visible est acheté.

## 2. Cartographier l'inventaire de pages
- `curl <domaine>/sitemap.xml` : compter les URL par motif (`/metier/dept/ville/`), repérer la profondeur, les deps couvertes, celles volontairement évitées (Paris, 92/93/94 = zones chères).
- `curl -o /dev/null -w "%{http_code}"` sur 5-6 URL : détecter les 404 sur des villes annoncées (landing cassée = argument commercial).
- Mesurer : nombre de mots, occurrences du nom de ville, nombre de CTA, présence/absence de formulaire.

## 3. Auditer la landing page et l'actif technique
- TTFB, en-têtes, CDN, cache : `curl -w "ttfb=%{time_starttransfer}"` + `curl -I`.
- Vitesse et sobriété de la page = expérience de page Google, donc CPC réel plus bas.
- Chercher GTM/GA4/AW-/appel de conversion : `grep -oE "GTM-[A-Z0-9]+|G-[A-Z0-9]{8,}|AW-[0-9]+"`.
  - Aucun tag de conversion = pilotage aveugle, pas d'enchères intelligentes, donc CPC qui restent bas.
- JSON-LD : LocalBusiness sans adresse, AggregateRating en dur non rattaché à une fiche = preuve de théâtre.
- Mentions légales vides, pas de fiche Google Business = faiblesses de confiance exploitables.

## 4. Dater et attribuer
- RDAP (pas whois) : `curl -H "Accept: application/rdap+json" https://rdap.nic.fr/domain/<domaine>` (.fr) ou `rdap.verisign.com/com/v1/domain/<domaine>` (.com).
- Société : rechercher le nom d'annonceur du centre de transparence sur societe.com / pappers pour le parcours (sociétés ouvertes puis fermées, âge du dirigeant).

## 5. Chiffrer
- Partir des impressions par création et du nombre d'annonces lues, diviser par le nombre de mois, appliquer un CTR 4-8 % et un CPC 0,25-0,45 € sur de la longue traîne. Toujours donner une fourchette et l'étiqueter comme estimation.
- Calculer le coût par département et par mois, pas seulement le total.

## 6. Auditer un compte à soi (exports Google Ads Editor)
- Les exports Editor sont la seule vérité de couverture. Un fichier de communes cibles liste des intentions : un département peut y figurer sans une seule campagne. Compter les campagnes par département avant d'annoncer un trou, sinon la liste de villes livrée est fausse.
- Dresser d'abord la carte : campagnes par marque, statuts, budgets, stratégies d'enchère, réseaux, groupes par ville, mots-clés par groupe, titres.
- Chiffrer les fuites dans cet ordre d'impact : CPC max contre le coût réel du palier visé, budgets par campagne contre la dépense possible, redirections sur les Final URL, mots-clés achetés par plusieurs comptes (auto-concurrence), ville absente des titres, groupes génériques doublonnant les groupes villes, extensions absentes, négatifs manquants.
- Mesurer les Final URL avec `curl -o /dev/null -w "%{http_code} %{time_total}"` : une 301 systématique sur chaque annonce est une fuite, un aller-retour complet par clic.
- Population d'une commune pour hiérarchiser : `geo.api.gouv.fr/communes?nom=<nom>&codeDepartement=<dep>&fields=nom,population&boost=population`, ou `codePostal=` quand le nom est composé.
- Comparer les noms de communes sous forme normalisée, mais vérifier les faux trous : accents, ligature œ et apostrophes cassent la normalisation. Un `search_files` sur le nom avant de publier la liste.
- Priorité par adjacence aux bases de l'utilisateur, pas seulement par taille : une commune de 8 000 habitants à 20 minutes passe avant une agglomération à 4 heures.

## Pièges
- Google bloque les SERP depuis une IP de datacenter (`/sorry/index`) : Maps et le centre de transparence passent, la recherche non. Ne pas y passer du temps.
- Les SPA du centre de transparence pèsent 3 Mo : découper les appels `js()` et attendre ; les aperçus de créations restent souvent vides.
- `urllib` se fait 403 sur certains sites : passer par `curl` avec un User-Agent Chrome.
- DuckDuckGo HTML affiche un captcha. Bing renvoie parfois une page hors sujet.
- Ne jamais conclure "SEO" sans avoir vérifié le centre de transparence, ni "Ads" sans avoir vérifié l'organique.

## Restitution
Concurrent : ce qu'il fait (prouvé) / pourquoi c'est bon marché (leviers) / coût estimé / ses failles / ce qu'on copie / choix à trancher.

Compte de l'utilisateur : fuites chiffrées par ordre d'impact / ce qui marche et qu'il ne faut pas casser / correctifs numérotés / arbitrage final. Toujours lister ce qui marche avant les correctifs, sinon il désactive le bon avec le mauvais.

Listes de villes : CSV en utf-8-sig, trié par priorité puis population, colonnes priorité / département / ville / population / catégorie, envoyé en pièce jointe plutôt qu'en tableau dans le message.

## Notes de terrain
- Annonces Locales Service en France : plomberie, électricité, CVC et dégâts des eaux sont ouverts, la serrurerie ne l'est pas. Vérifier l'outil d'éligibilité au code postal avant d'en promettre, et proposer la fiche Google Business en repli.
- Un tag de conversion ne pèse pas sur l'enchère en CPC manuel ni en max de clics : Google ne le lit pas. Il ne fait grimper les prix qu'en enchère intelligente sans CPA cible. Donc tag toujours, pilotage manuel tant que le compte n'a pas 30 conversions par mois.
- Le "haut de page pas cher" n'existe que sur la longue traîne : sur une requête de tête, être 3e coûte déjà 40 à 60 % moins cher que la 1re et convertit presque autant en dépannage.
- Le coût se compte en clics, pas en mots-clés : 300 mots-clés ne coûtent pas 300 fois quelque chose, ils coûtent la somme des clics reçus. C'est le plafond CPC qui arbitre, pas la taille de la liste.

## Références
- `references/cas-nicolas-service.md` : cas d'école d'arbitrage de leads.
- `references/exports-ads-editor-csv.md` : lecture des exports Editor et pièges de parsing.
